(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(){chrome.runtime?.id&&chrome.runtime.sendMessage({type:`CHECK_PAIRING`},e=>{let t=e?.isPaired;chrome.runtime.sendMessage({type:`GET_STATS`},e=>{let n=e||{cookies_blocked:0,exif_stripped:0,otp_cleared:0,gpc_signals:0},r=document.querySelector(`#app`),i=e=>chrome.i18n.getMessage(e);r.innerHTML=`
        <div class="header">
          <div class="brand">
            <span class="brand-dot"></span>
            UID Link
          </div>
          <span style="font-size: 10px; font-weight: 500; color: var(--text-muted);">v1.2.0</span>
        </div>

        <div class="tab-content" style="flex: 1; display: flex; flex-direction: column; gap: 12px;">
          <div class="vault-card">
            <div class="vault-status-badge ${t?`connected`:`disconnected`}">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: currentColor;"></span>
              ${i(t?`vaultConnected`:`waitingForLogin`)}
            </div>
            <p style="margin: 0; color: var(--text-muted); font-size: 12px; line-height: 1.5; text-align: center;">
              ${i(t?`vaultConnectedDesc`:`waitingForLoginDesc`)}
            </p>
          </div>

          <div class="stats-grid">
            <div class="stat-box">
              <div class="stat-value">${n.cookies_blocked}</div>
              <div class="stat-label">${i(`cookiesGuard`)}</div>
            </div>
            <div class="stat-box">
              <div class="stat-value">${n.exif_stripped}</div>
              <div class="stat-label">${i(`exifStripped`)}</div>
            </div>
            <div class="stat-box">
              <div class="stat-value">${n.otp_cleared}</div>
              <div class="stat-label">${i(`inputsWiped`)}</div>
            </div>
          </div>

          <div class="toggles-section">
            <div class="section-title">${i(`engineControl`)}</div>
            <div class="toggle-row">
              <div class="toggle-info">
                <div class="toggle-label">${i(`activeDlpInterceptor`)}</div>
                <div class="toggle-desc">${i(`activeDlpInterceptorDesc`)}</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="toggle-dlp" checked>
                <span class="slider"></span>
              </label>
            </div>
          </div>
        </div>

        <div class="footer">
          <span>${i(`sovereignIdentityLayer`)}</span>
          <a href="https://uid.one" target="_blank" class="footer-link">uid.one</a>
        </div>
      `;let a=document.getElementById(`toggle-dlp`);a&&(chrome.storage.local.get(`settings_otp_shield`).then(e=>{a.checked=e.settings_otp_shield!==!1}),a.addEventListener(`change`,()=>{chrome.storage.local.set({settings_otp_shield:a.checked})}))})})}e();