(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(){chrome.runtime?.id&&chrome.runtime.sendMessage({type:`CHECK_PAIRING`},e=>{let t=e?.isPaired;chrome.runtime.sendMessage({type:`GET_STATS`},e=>{let n=e||{cookies_blocked:0,exif_stripped:0,otp_cleared:0,gpc_signals:0},r=document.querySelector(`#app`),i=e=>chrome.i18n.getMessage(e);r.innerHTML=`
        <div class="header">
          <div class="brand">
            <span class="brand-dot"></span>
            UID Link
          </div>
          <span style="font-size: 10px; font-weight: 500; color: var(--text-muted);">v${chrome.runtime.getManifest().version}</span>
        </div>

        <div style="flex: 1; display: flex; flex-direction: column; gap: 14px;">
          <!-- Vault Status Card -->
          <div class="premium-card">
            <div class="card-row">
              <div class="row-left">
                <div class="icon-wrapper ${t?`success`:`warning`}">
                  ${t?`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`}
                </div>
                <div class="row-content">
                  <div class="row-title" style="display: flex; align-items: center; gap: 6px;">
                    ${i(t?`vaultConnected`:`waitingForLogin`)}
                    <span style="display: inline-block; width: 6px; height: 6px; border-radius: 50%; background-color: ${t?`#10b981`:`#f59e0b`};"></span>
                  </div>
                  <div class="row-desc">
                    ${i(t?`vaultConnectedDesc`:`waitingForLoginDesc`)}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Protection Stats -->
          <div class="premium-card">
            <div class="section-title">
              ${i(`sovereignIdentityLayer`)}
            </div>
            <div class="stats-grid">
              <div class="stat-box">
                <div class="stat-value">${n.cookies_blocked}</div>
                <div class="stat-label">${i(`cookiesGuard`)}</div>
              </div>
              <div class="stat-box">
                <div class="stat-value">${n.exif_stripped}</div>
                <div class="stat-label">${i(`exifStripped`)}</div>
              </div>
              <div class="stat-box">
                <div class="stat-value">${n.otp_cleared}</div>
                <div class="stat-label">${i(`inputsWiped`)}</div>
              </div>
            </div>
          </div>

          <!-- Engine Control Section -->
          <div class="premium-card">
            <div class="section-title">
              ${i(`engineControl`)}
            </div>
            <div class="card-row">
              <div class="row-left">
                <div class="icon-wrapper purple">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                </div>
                <div class="row-content">
                  <div class="row-title">${i(`activeDlpInterceptor`)}</div>
                  <div class="row-desc">${i(`activeDlpInterceptorDesc`)}</div>
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" id="toggle-dlp" checked>
                <span class="slider"></span>
              </label>
            </div>
          </div>
        </div>

        <div class="footer">
          <a href="https://uid.one/profile" target="_blank" class="text-link">
            Xem chi tiết trên web →
          </a>
          <span style="font-size: 9px; color: var(--text-muted);">UID.one</span>
        </div>
      `;let a=document.getElementById(`toggle-dlp`);a&&(chrome.storage.local.get(`settings_otp_shield`).then(e=>{a.checked=e.settings_otp_shield!==!1}),a.addEventListener(`change`,()=>{chrome.storage.local.set({settings_otp_shield:a.checked})}))})})}e();