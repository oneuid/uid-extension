var _=(function(e){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var t=Object.create,n=Object.defineProperty,r=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,a=Object.getPrototypeOf,o=Object.prototype.hasOwnProperty,s=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),c=(e,t,a,s)=>{if(t&&typeof t==`object`||typeof t==`function`)for(var c=i(t),l=0,u=c.length,d;l<u;l++)d=c[l],!o.call(e,d)&&d!==a&&n(e,d,{get:(e=>t[e]).bind(null,d),enumerable:!(s=r(t,d))||s.enumerable});return e},l=(e,r,i)=>(i=e==null?{}:t(a(e)),c(r||!e||!e.__esModule?n(i,`default`,{value:e,enumerable:!0}):i,e));function u(){try{return typeof chrome>`u`||chrome.runtime===void 0||!chrome.runtime.id||chrome.i18n===void 0?!1:(chrome.i18n.getMessage(`extensionName`),!0)}catch{return!1}}function d(){try{return window.parent.location.hostname}catch{return``}}function f(e){try{if(window.parent!==window&&window.parent.document)return!!window.parent.document.querySelector(e)}catch{}return!1}function p(){let e=window.location.hostname||d();if(/mail\./.test(e)||/outlook\./.test(e)||/zoho\./.test(e)||/ymail\./.test(e)||/proton\./.test(e)||/roundcube/.test(e)||/zimbra/.test(e))return!0;let t=[`.a3s`,`.rps_code`,`.zmMailContent`,`.zmContent`,`.zmContentMain`,`.zmcContent`,`.message-body-container`,`.email-wrapped`,`.message_body`,`.msg-body`,`#messagebody`,`.v-Message-body`].join(`, `);return!!(document.querySelector(t)||f(t))}var m=class{isMatch(e){return e.includes(`mail.google.com`)}detectSender(e){let t=e.closest(`form, [role="dialog"], .composer, .M9, .compose-box, #compose-container`);if(!t)return null;let n=(t.textContent||``).match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(n)return n[1];let r=t.querySelector(`select[name="from"], select.agP, .compose-from select`);if(r){let e=r.value?.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}return null}detectLoggedInUser(){let e=document.querySelector(`a[href*="SignOutOptions"], a[aria-label*="Google Account" i], [aria-label*="@gmail.com" i]`);if(e){let t=(e.getAttribute(`aria-label`)||e.getAttribute(`title`)||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(t)return t[0]}let t=document.querySelector(`.gb_A, .gb_B, .gb_d`);if(t){let e=(t.getAttribute(`title`)||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}return null}},h=class{isMatch(e){return e.includes(`outlook.live.com`)||e.includes(`outlook.office.com`)||e.includes(`outlook.office365.com`)}detectSender(e){let t=e.closest(`form, [role="dialog"], .composer, .compose-box`);if(!t)return null;let n=(t.textContent||``).match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(n)return n[1];let r=t.querySelector(`[role="combobox"][aria-label*="From" i], .compose-sender, .sender-field`);if(r){let e=r.textContent?.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}return null}detectLoggedInUser(){let e=document.querySelector(`#O365_HeaderRightRegion, #meInitialsButton, #O365_MainLink_Me, button[aria-label*="Account manager" i]`);if(e){let t=(e.textContent||e.getAttribute(`aria-label`)||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(t)return t[0]}return null}},g=class{isMatch(e){return e.includes(`zoho.com`)}detectSender(e){let t=null;if(window.parent&&window.parent.document&&window.parent.document!==e.ownerDocument){let n=null;try{let t=window.parent.document.querySelectorAll(`iframe`);for(let r=0;r<t.length;r++)if(t[r].contentDocument===e.ownerDocument||t[r].contentWindow===e.ownerDocument.defaultView){n=t[r];break}}catch(e){console.warn(`[uid.one] Could not access parent document:`,e)}if(n){let e=n.parentElement;for(;e&&e!==window.parent.document.body;){let n=e.id||``,r=e.getAttribute(`role`)||``;if(e.classList.contains(`zm-composer`)||e.classList.contains(`zmail-composer`)||e.classList.contains(`zm-compose-tab`)||e.tagName===`FORM`||r===`tabpanel`||r===`dialog`||n.toLowerCase().includes(`compose`)){t=e;break}e=e.parentElement}}}t||=e.closest(`form, [role="dialog"], .composer, .zm-composer`)||e.ownerDocument.body;for(let e of[`.zm-c-from-email`,`.zm-composer-from`,`.zm-c-from`,`[data-fieldname="from"]`,`.compose-from`,`.zm-c-from-email-val`]){let n=t.querySelector(e);if(n){let e=n.textContent||``,t=e.match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(t)return t[1];let r=e.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(r)return r[0]}}try{let e=t.cloneNode(!0);e.querySelectorAll(`iframe, textarea, [contenteditable="true"]`).forEach(e=>e.remove());let n=e.textContent||``,r=n.match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(r)return r[1];let i=n.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(i)return i[0]}catch{let e=(t.textContent||``).match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(e)return e[1]}return null}detectLoggedInUser(){let e=document.querySelector(`.zm-user-email, .zmail-user-email, .zm-profile-email`);if(e){let t=(e.getAttribute(`title`)||e.textContent||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(t)return t[0]}let t=document.querySelector(`.zm-profile-icon, #top_profile_bubble, .zm-user-pic`);if(t){let e=(t.getAttribute(`title`)||t.textContent||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}for(let e of[`#top_profile_bubble`,`.zm-profile-card`,`#zm-profile`,`.zm-profile`]){let t=document.querySelector(e);if(t){let e=(t.getAttribute(`title`)||t.textContent||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}}return null}},v=class{isMatch(e){return e.includes(`mail.yahoo.com`)}detectSender(e){let t=e.closest(`form, .composer, .compose-box`);if(!t)return null;let n=t.textContent||``,r=n.match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(r)return r[1];let i=n.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);return i?i[0]:null}detectLoggedInUser(){let e=document.querySelector(`.ybar-menu-header-email, #ybarAccountMenuOpener, [data-redirect-url*="mail.yahoo.com"]`);if(e){let t=(e.textContent||e.getAttribute(`aria-label`)||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(t)return t[0]}return null}},y=[new m,new h,new g,new v];function b(){let e=window.location.hostname||d();return y.find(t=>t.isMatch(e))||null}function x(e){if(!e)return null;let t=b();if(t){let n=t.detectSender(e);if(n)return n}let n=e.closest(`form, [role="dialog"], .composer, .M9, .compose-box, #compose-container, .zm-composer, .zmail-composer`)||e.ownerDocument.body;try{let e=n.cloneNode(!0);e.querySelectorAll(`iframe, textarea, [contenteditable="true"]`).forEach(e=>e.remove());let t=e.textContent||``,r=t.match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(r)return r[1];let i=t.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(i)return i[0]}catch{}let r=n.textContent||``,i=r.match(/<([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})>/);if(i)return i[1];let a=r.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);return a?a[0]:null}function S(e){let t=e.toLowerCase().trim();return t.endsWith(`@gmail.com`)?`${t.split(`@`)[0].replace(/\./g,``)}@gmail.com`:t}function C(){let e=b();if(e){let t=e.detectLoggedInUser();if(t)return t}let t=`.username, .username-span, #username, #skin_container_username, .userName, .user-name`,n=document.querySelector(t);if(!n&&window.parent!==window)try{n=window.parent.document.querySelector(t)}catch{}if(n){let e=(n.textContent||``).trim().match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(e)return e[0]}let r=`header [title*="@"], .header [title*="@"], #header [title*="@"]`,i=Array.from(document.querySelectorAll(r));if(i.length===0&&window.parent!==window)try{i=Array.from(window.parent.document.querySelectorAll(r))}catch{}for(let e=0;e<i.length;e++){let t=(i[e].getAttribute(`title`)||``).match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);if(t)return t[0]}return null}var w={vnId:/\b\d{9}(\d{3})?\b/g,creditCard:/\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b/g,bankAccount:/\b\d{9,16}\b/g,emailBulk:/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g,phone:/(?:\+\d{1,4}[\s.-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{2,6}\b|(?:\+\d{1,4}[\s.-]?)?\d{7,14}\b/g,apiKey:/\b(sk-|pk-|api_key=|secret=)[A-Za-z0-9]{20,}\b/gi,jwt:/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,privateKey:/-----BEGIN (RSA |EC |)PRIVATE KEY-----/};function T(e){let t=[];for(let[n,r]of Object.entries(w)){let i=e.match(r);i&&i.length>0&&t.push({type:n,count:i.length,sample:te(i[0])})}if(t.length===0)return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``};let n=ee(t);return{blocked:n===`critical`||n===`high`,riskLevel:n,findings:t,recommendation:ne(t,n)}}function ee(e){let t=e.map(e=>e.type);return t.includes(`privateKey`)||t.includes(`jwt`)?`critical`:t.some(e=>[`creditCard`,`apiKey`,`vnId`].includes(e))?`high`:t.some(e=>[`phone`,`emailBulk`].includes(e))?`medium`:`low`}function te(e){return e.length<=8?`••••••••`:e.slice(0,4)+`••••`+e.slice(-4)}function ne(e,t){return t===`critical`?`This content contains credentials or tokens. Sending it could compromise your accounts.`:t===`high`?`This content may contain sensitive personal or financial data.`:`Review this content before sending.`}async function E(e){return new Promise(t=>{let n=document.createElement(`div`);n.style.cssText=`
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.6);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    `;let r={file_upload:`File upload`,clipboard_paste:`Clipboard paste`,form_submit:`Form submission`,drag_drop:`File drop`}[e.context];n.innerHTML=`
      <div style="
        background: white;
        border-radius: 12px;
        padding: 24px;
        max-width: 480px;
        width: 90%;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      ">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <div style="
            width:40px;height:40px;border-radius:8px;
            background:${{critical:`#dc2626`,high:`#ea580c`,medium:`#d97706`,low:`#2563eb`}[e.result.riskLevel]};display:flex;
            align-items:center;justify-content:center;
            color:white;font-size:20px;flex-shrink:0
          ">⚠</div>
          <div>
            <div style="font-weight:600;font-size:15px;color:#111827;">
              Sensitive data detected
            </div>
            <div style="color:#6b7280;font-size:13px">
              ${r}${e.filename?` — ${e.filename}`:``}
            </div>
          </div>
        </div>

        <p style="color:#374151;font-size:14px;line-height:1.5;margin:0 0 16px">
          ${e.result.recommendation}
        </p>

        <div style="
          background:#f9fafb;border-radius:8px;
          padding:12px;margin-bottom:20px;
          border:1px solid #e5e7eb
        ">
          ${e.result.findings.map(e=>`
            <div style="font-size:13px;color:#374151;padding:2px 0">
              <strong>${e.type}</strong>
              ${e.count>1?`× ${e.count}`:``}
              — <code style="color:#dc2626">${e.sample}</code>
            </div>
          `).join(``)}
        </div>

        <div style="display:flex;gap:8px;justify-content:flex-end">
          ${e.onAllow?`
            <button id="uid-dlp-allow" style="
              background:none;border:1px solid #d1d5db;
              color:#374151;padding:8px 16px;border-radius:6px;
              cursor:pointer;font-size:14px
            ">Send anyway</button>
          `:``}
          <button id="uid-dlp-block" style="
            background:#111827;color:white;
            border:none;padding:8px 20px;border-radius:6px;
            cursor:pointer;font-size:14px;font-weight:500
          ">Don't send</button>
        </div>
      </div>
    `,document.body.appendChild(n),n.querySelector(`#uid-dlp-block`)?.addEventListener(`click`,()=>{n.remove(),t()}),n.querySelector(`#uid-dlp-allow`)?.addEventListener(`click`,()=>{n.remove(),e.onAllow?.(),t()})})}function re(e){let t=new DataView(e);if(t.byteLength<4||t.getUint16(0)!==65496)return e;let n=2,r=t.byteLength,i=[],a=0;for(;n<r-1;){let r=t.getUint16(n);if(r===65505){let r=t.getUint16(n+2);n>a&&i.push(e.slice(a,n)),a=n+2+r,n=a}else if(r>=65488&&r<=65497)n+=2;else{let e=t.getUint16(n+2);n+=2+e}}if(a<r&&i.push(e.slice(a,r)),i.length===0)return e;let o=i.reduce((e,t)=>e+t.byteLength,0),s=new Uint8Array(o),c=0;for(let e of i)s.set(new Uint8Array(e),c),c+=e.byteLength;return s.buffer}async function D(e){if(e.type===`image/jpeg`||e.name.toLowerCase().endsWith(`.jpg`)||e.name.toLowerCase().endsWith(`.jpeg`))try{let t=await e.arrayBuffer(),n=re(t);if(n.byteLength!==t.byteLength){console.log(`[uid.one] CookieGuard / Privacy stripped EXIF metadata from: ${e.name}`);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`exif_stripped`})}catch{}return new File([n],e.name,{type:e.type,lastModified:Date.now()})}}catch(e){console.warn(`[uid.one] Failed to strip EXIF from image:`,e)}return e}var ie=class{observer=null;init(){chrome.storage.local.get(`settings_exif_stripper`).then(e=>{if(e.settings_exif_stripper===!1){console.log(`[uid.one] FileUploadInterceptor (EXIF Stripper) is disabled.`);return}this.scanFileInputs(document.querySelectorAll(`input[type="file"]`)),this.observer=new MutationObserver(e=>{for(let t of e)t.addedNodes.forEach(e=>{if(e instanceof Element){let t=e.querySelectorAll(`input[type="file"]`);this.scanFileInputs(t)}})}),this.observer.observe(document.body,{childList:!0,subtree:!0}),document.addEventListener(`drop`,this.handleDrop.bind(this),!0)})}scanFileInputs(e){e.forEach(e=>{e.getAttribute(`data-uid-scanned`)||(e.setAttribute(`data-uid-scanned`,`true`),e.addEventListener(`change`,async e=>{let t=e.target;if(t.getAttribute(`data-uid-metadata-cleaning`)===`true`)return;if(t.getAttribute(`data-uid-allowed`)===`true`){t.removeAttribute(`data-uid-allowed`);return}let n=t.files;if(!(!n||n.length===0)){t.setAttribute(`data-uid-metadata-cleaning`,`true`);try{let e=[],r=!1;for(let t=0;t<n.length;t++){let i=n[t],a=await D(i);a!==i&&(r=!0),e.push(a)}if(r){let n=new DataTransfer;e.forEach(e=>n.items.add(e)),t.files=n.files,t.dispatchEvent(new Event(`change`,{bubbles:!0}));return}}finally{t.removeAttribute(`data-uid-metadata-cleaning`)}await this.handleFiles(Array.from(t.files||[]),t)}}))})}async handleFiles(e,t){for(let n of e){let e=await this.scanFile(n);e.blocked&&(t.value=``,await E({context:`file_upload`,filename:n.name,result:e,onAllow:()=>{t.setAttribute(`data-uid-allowed`,`true`)}}))}}async scanFile(e){if(!([`text/`,`application/json`,`application/xml`,`application/csv`,`application/sql`].some(t=>e.type.startsWith(t))||e.name.endsWith(`.txt`)||e.name.endsWith(`.csv`)||e.name.endsWith(`.json`)||e.name.endsWith(`.sql`)||e.name.endsWith(`.env`)||e.name.endsWith(`.key`)||e.name.endsWith(`.pem`)))return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``};if(e.size>1024*1024)return{blocked:!1,riskLevel:`medium`,findings:[{type:`large_file`,count:1,sample:`${(e.size/1024/1024).toFixed(1)}MB`}],recommendation:`Large file — please verify it does not contain sensitive data.`};try{return T(await e.text())}catch{return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``}}}async handleDrop(e){if(!e.dataTransfer?.files?.length||e.defaultPrevented)return;let t=e.target;if(e.dataTransfer.types.includes(`Files`)&&t.getAttribute(`data-uid-dropped-clean`)===`true`){t.removeAttribute(`data-uid-dropped-clean`);return}let n=Array.from(e.dataTransfer.files);for(let t of n){let n=await this.scanFile(t);if(n.blocked){e.preventDefault(),e.stopPropagation(),await E({context:`drag_drop`,filename:t.name,result:n});return}}let r=!1,i=[];for(let e of n){let t=await D(e);t!==e&&(r=!0),i.push(t)}if(r){e.preventDefault(),e.stopPropagation(),t.setAttribute(`data-uid-dropped-clean`,`true`);let n=new DataTransfer;i.forEach(e=>n.items.add(e));let r=new DragEvent(`drop`,{bubbles:!0,cancelable:!0,dataTransfer:n});t.dispatchEvent(r)}}},ae=class{isDlpActive=!0;init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{this.isDlpActive=e.settings_otp_shield!==!1}),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.settings_otp_shield&&(this.isDlpActive=e.settings_otp_shield.newValue!==!1)}),document.addEventListener(`paste`,this.handlePaste.bind(this),!0),document.addEventListener(`copy`,this.handleCopy.bind(this),!0)}async handlePaste(e){if(!this.isDlpActive)return;let t=e.target;if(t.getAttribute(`data-uid-allowed`)===`true`){t.removeAttribute(`data-uid-allowed`);return}let n=e.clipboardData?.getData(`text/plain`);if(!n)return;let r=T(n);r.riskLevel===`critical`&&(e.preventDefault(),e.stopPropagation(),await E({context:`clipboard_paste`,result:r,onAllow:()=>{if(t.setAttribute(`data-uid-allowed`,`true`),t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){let e=t.selectionStart||0,r=t.selectionEnd||0,i=t.value;t.value=i.slice(0,e)+n+i.slice(r),t.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}))}handleCopy(e){if(!this.isDlpActive)return;let t=window.getSelection()?.toString();if(!t)return;let n=T(t),r=0,i=0,a=[],o=[`emailBulk`,`phone`,`creditCard`,`apiKey`,`vnId`,`privateKey`,`jwt`,`bankAccount`],s=[];for(let e of n.findings)if(o.includes(e.type)){a.push(e.type);let n=w[e.type];if(n){n.lastIndex=0;let r;if(n.global)for(;(r=n.exec(t))!==null;)r[0]&&s.push({start:r.index,end:r.index+r[0].length,type:e.type});else r=n.exec(t),r&&r[0]&&s.push({start:r.index,end:r.index+r[0].length,type:e.type})}}s.sort((e,t)=>e.start-t.start);let c=[];for(let e of s)if(c.length===0)c.push(e);else{let t=c[c.length-1];e.start<t.end?t.end=Math.max(t.end,e.end):c.push(e)}r=c.length;let l={};for(let e of c)l[e.type]=(l[e.type]||0)+1;for(let e of Object.values(l))e>i&&(i=e);r>0&&(r>=3||i>=3?(e.preventDefault(),e.clipboardData&&e.clipboardData.setData(`text/plain`,`[SECURE DATA BLOCKED BY UID.ONE]`),chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:`Bulk copying of sensitive customer data (email/phone/credentials) is disabled.`}),chrome.runtime.sendMessage({type:`AUDIT_COPY`,domain:window.location.hostname,sensitive_type:a.join(`,`),sample:`[BULK COPY BLOCKED]`,count:r,blocked:!0})):chrome.runtime.sendMessage({type:`AUDIT_COPY`,domain:window.location.hostname,sensitive_type:a.join(`,`),sample:t.slice(0,50)+(t.length>50?`...`:``),count:r,blocked:!1}))}},oe=class{init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{e.settings_otp_shield!==!1&&(document.addEventListener(`submit`,this.handleSubmit.bind(this),!0),document.addEventListener(`click`,e=>{let t=e.target.closest(`button, input[type="submit"]`);if(t&&(t.getAttribute(`type`)===`submit`||/submit|login|verify|confirm|pay/i.test(t.textContent||``)||/submit|login|verify|confirm|pay/i.test(t.value||``))){let e=t.closest(`form`);if(e)this.wipeSensitiveInputs(e);else{let e=t.parentElement;e&&e.querySelectorAll(`input[type="password"], input[name*="otp" i], input[name*="code" i], input[autocomplete*="one-time-code" i], input[name*="card" i], input[name*="cvv" i], input[name*="cvc" i]`).forEach(e=>{setTimeout(()=>{e.value&&(e.value=``,e.dispatchEvent(new Event(`input`,{bubbles:!0})))},300)})}}},!0))})}async handleSubmit(e){let t=e.target;if(t.getAttribute(`data-uid-owned`))return;if(t.getAttribute(`data-uid-allowed`)===`true`){this.wipeSensitiveInputs(t);return}let n=this.extractFormContent(t);if(!n){this.wipeSensitiveInputs(t);return}let r=T(n);r.blocked?(e.preventDefault(),e.stopPropagation(),await E({context:`form_submit`,result:r,onAllow:()=>{t.setAttribute(`data-uid-allowed`,`true`),t.requestSubmit()}})):this.wipeSensitiveInputs(t)}wipeSensitiveInputs(e){e.querySelectorAll(`input[type="password"], input[name*="otp" i], input[name*="code" i], input[autocomplete*="one-time-code" i], input[name*="card" i], input[name*="cvv" i], input[name*="cvc" i]`).forEach(e=>{setTimeout(()=>{if(e.value){console.log(`[uid.one] CookieGuard / Privacy wiped sensitive value from input: ${e.name||e.id}`),e.value=``,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}));try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`otp_cleared`})}catch{}}},300)});try{navigator.clipboard.readText().then(e=>{let t=T(e);(t.riskLevel===`critical`||t.riskLevel===`high`)&&navigator.clipboard.writeText(``).then(()=>{console.log(`[uid.one] CookieGuard / Privacy wiped sensitive content from clipboard cache.`);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`otp_cleared`})}catch{}})}).catch(()=>{})}catch{}}extractFormContent(e){let t=new FormData(e),n=[];return t.forEach((e,t)=>{e instanceof File||t.toLowerCase().includes(`password`)||t.toLowerCase().includes(`token`)||n.push(`${t}=${e}`)}),n.join(`
`)}},se=class{init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{e.settings_otp_shield!==!1&&document.querySelectorAll(`input[type="text"], input[type="email"], textarea`).forEach(e=>{e.getAttribute(`data-uid-dlp-shield`)||(e.setAttribute(`data-uid-dlp-shield`,`true`),e.addEventListener(`blur`,e=>{let t=e.target.value||``;if(t.trim()){let e=T(t);e.blocked&&chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Sensitive Data Alert`,message:`Potential sensitive data (${e.findings.map(e=>e.type).join(`, `)}) detected in input field.`})}}))})})}},O=class{init(){console.log(`[uid.one] Initializing ScreenshotProtector...`);let e=document.createElement(`style`);e.textContent=`
      @media print {
        body {
          display: none !important;
        }
        html {
          display: none !important;
        }
      }
      .uid-blur-active {
        filter: blur(25px) !important;
        transition: filter 0.1s ease-in-out !important;
      }
      
      input[type="password"]:not(:focus):not(:hover),
      input[name*="otp" i]:not(:focus):not(:hover),
      input[name*="code" i]:not(:focus):not(:hover),
      input[autocomplete*="one-time-code" i]:not(:focus):not(:hover),
      input[name*="card" i]:not(:focus):not(:hover),
      input[name*="cvv" i]:not(:focus):not(:hover),
      input[name*="cvc" i]:not(:focus):not(:hover) {
        filter: blur(5px) !important;
        transition: filter 0.15s ease-in-out !important;
      }
    `;let t=document.head||document.documentElement;t&&t.appendChild(e),document.addEventListener(`keydown`,e=>{let t=e.key===`PrintScreen`,n=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`p`,r=e.metaKey&&e.shiftKey&&e.key.toLowerCase()===`s`,i=e.metaKey&&e.shiftKey&&(e.key===`3`||e.key===`4`),a=e.key===`F12`,o=(e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key.toLowerCase()===`i`||e.key.toLowerCase()===`c`||e.key.toLowerCase()===`j`),s=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`u`;if(t||n||r||i){console.log(`[uid.one] Keydown screenshot/print event detected:`,e.key);let r=document.body||document.documentElement;r&&r.classList.add(`uid-blur-active`),(t||n)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Printing and screen capturing are disabled by UID.ONE.`)),setTimeout(()=>{if(document.hasFocus()){let e=document.body||document.documentElement;e&&e.classList.remove(`uid-blur-active`)}},2e3)}else if(a||o||s){let t=window.location.hostname,n=t===`uid.one`||t.endsWith(`.uid.one`),r=document.querySelector(`input[type="password"]`)!==null;(n||r)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Developer tools are disabled on secure pages.`))}},!0),document.addEventListener(`contextmenu`,e=>{let t=e.target,n=window.location.hostname,r=n===`uid.one`||n.endsWith(`.uid.one`),i=t.closest(`input[type="password"]`);(r||i)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Context menu options are disabled on secure domains/inputs.`))},!0),document.addEventListener(`visibilitychange`,()=>{let e=document.body||document.documentElement;document.hidden?(console.log(`[uid.one] Visibility hidden, applying blur filter`),e&&e.classList.add(`uid-blur-active`)):(console.log(`[uid.one] Visibility visible, removing blur filter`),e&&e.classList.remove(`uid-blur-active`))}),this.injectWatermark(),this.initDevToolsDetector()}initDevToolsDetector(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;if(!t&&!n)return;console.log(`[uid.one] Enabling DevTools console getter detector...`);let r=new Image;Object.defineProperty(r,`id`,{get:()=>{console.log(`[uid.one] DevTools console evaluated target object, triggering blur`);let e=document.body||document.documentElement;return e&&e.classList.add(`uid-blur-active`),chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:`Developer tools detected. Content has been secured.`}),`uid-secure`}}),setInterval(()=>{console.log(r)},1e3)}injectWatermark(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;if(!t&&!n||document.getElementById(`uid-watermark-overlay`))return;console.log(`[uid.one] Generating and injecting dynamic watermark overlay`);let r=document.createElement(`div`);r.id=`uid-watermark-overlay`,r.style.cssText=`
      position: fixed;
      inset: 0;
      z-index: 2147483640;
      pointer-events: none;
      opacity: 0.03;
      display: flex;
      flex-wrap: wrap;
      align-content: space-around;
      justify-content: space-around;
      overflow: hidden;
      user-select: none;
    `;let i=`UID.ONE | SECURE SESSION | ${navigator.userAgent.includes(`Mac`)?`macOS`:`Windows/Linux`}`;for(let e=0;e<20;e++){let e=document.createElement(`div`);e.style.cssText=`
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 15px;
        font-weight: 600;
        transform: rotate(-25deg);
        white-space: nowrap;
        margin: 50px;
        color: #000000;
      `,e.textContent=i,r.appendChild(e)}let a=document.body||document.documentElement;a&&a.appendChild(r)}showWarningToast(e){chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:e})}},k=class{SUSPICIOUS_PATTERNS=[/uid\.one\./i,/uid-one/i,/uidone/i,/uid_one/i];init(){this.checkCurrentPage(),this.monitorFormSubmissions()}checkCurrentPage(){let e=window.location.hostname,t=this.isLegitimateUIDDomain(e);this.isSuspiciousUIDDomain(e)&&!t&&this.showPhishingWarning(e)}isLegitimateUIDDomain(e){return[`uid.one`,`auth.uid.one`,`api.uid.one`].some(t=>e===t||e.endsWith(`.${t}`)||e===`localhost`||e===`127.0.0.1`)}isSuspiciousUIDDomain(e){return this.SUSPICIOUS_PATTERNS.some(t=>t.test(e))}showPhishingWarning(e){let t=document.createElement(`div`);t.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 2147483647;
      background: #dc2626;
      color: white;
      padding: 12px 16px;
      font-family: sans-serif;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    `,t.innerHTML=`
      <span>
        ⚠ <strong>Phishing warning:</strong>
        This page (${e}) may be impersonating UID.one.
        Do not enter your credentials.
      </span>
      <button id="uid-phish-dismiss"
        style="background:none;border:1px solid white;color:white;
               padding:4px 12px;border-radius:4px;cursor:pointer">
        Dismiss
      </button>
    `,document.body.prepend(t),t.querySelector(`#uid-phish-dismiss`)?.addEventListener(`click`,()=>t.remove())}monitorFormSubmissions(){document.addEventListener(`submit`,e=>{let t=e.target;if(!t.querySelector(`[data-uid-autofill]`))return;let n=new URL(t.action||window.location.href);n.protocol===`https:`||n.hostname===`localhost`||n.hostname===`127.0.0.1`||(e.preventDefault(),this.showInsecureSubmitWarning(n.hostname))},!0)}showInsecureSubmitWarning(e){chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Insecure Form Blocked`,message:`${e} uses HTTP. Your credentials were not submitted.`})}},ce=class{init(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;t||!n||(console.log(`[uid.one] Initializing ViewportCleaner...`),this.clean(),new MutationObserver(()=>{this.clean()}).observe(document.documentElement,{childList:!0,subtree:!0}))}clean(){let e=document.querySelector([`#kc-container`,`.login-pf-page`,`#app`,`#__next`,`#root`].join(`,`));Array.from(document.body?document.body.children:[]).forEach(t=>{if(e&&(t===e||e.contains(t))||t.id===`uid-watermark-overlay`||t.id===`uid-security-enforcer-banner`)return;let n=window.getComputedStyle(t),r=n.position===`fixed`||n.position===`absolute`,i=parseInt(n.zIndex,10);if(r&&(i>100||isNaN(i))){let e=parseFloat(n.opacity);(n.opacity===`0`||!isNaN(e)&&e<.15||n.backgroundColor===`transparent`||n.backgroundColor.includes(`rgba`)&&(n.backgroundColor.endsWith(`, 0)`)||n.backgroundColor.endsWith(`,0)`)))&&(console.log(`[uid.one] Suspect third-party viewport element hidden:`,t),t.style.setProperty(`display`,`none`,`important`),t.style.setProperty(`visibility`,`hidden`,`important`),t.style.setProperty(`opacity`,`0`,`important`),t.style.setProperty(`pointer-events`,`none`,`important`))}})}},le=class{SENSITIVE_COOKIE_PATTERNS=[/^_(ga|gid|gat|gac|gcl)/i,/^_(fbp|fbc)/i,/^_(uetsid|uetvid)/i,/^(cluid|hj|pin_)/i,/^_tt_enable_cookie/i,/^__pt/i,/cookieconsent/i,/ad-/i,/pixel/i,/tracking/i];init(){let e=window.location.hostname;this.isWhitelistedDomain(e)||chrome.storage.local.get(`settings_cookie_guard`).then(e=>{if(e.settings_cookie_guard===!1){console.log(`[uid.one] CookieGuard is disabled by policy.`),document.documentElement.dataset.uidCookieGuard=`false`;return}console.log(`[uid.one] Initializing CookieGuard...`),this.sweepCookies(),setInterval(()=>this.sweepCookies(),5e3)})}isWhitelistedDomain(e){return[`uid.one`,`trip.express`,`localhost`,`127.0.0.1`].some(t=>e===t||e.endsWith(`.`+t))}sweepCookies(){if(typeof document>`u`||!document.cookie)return;let e=document.cookie.split(`;`);for(let t of e){let e=t.indexOf(`=`);if(e===-1)continue;let n=t.substring(0,e).trim();if(this.SENSITIVE_COOKIE_PATTERNS.some(e=>e.test(n))){console.log(`[uid.one] CookieGuard sweeping tracking cookie:`,n),this.deleteCookie(n);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`cookies_blocked`})}catch{}}}}deleteCookie(e){let t=[``,window.location.hostname,`.`+window.location.hostname,this.getCookieDomain()];for(let n of t){let t=n?`; domain=${n}`:``;document.cookie=`${e}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${t}`}}getCookieDomain(){let e=window.location.hostname.split(`.`);return e.length>=2?`.`+e.slice(-2).join(`.`):window.location.hostname}},ue=class{init(){console.log(`[uid.one] NotificationBlocker registered in main world.`)}},de=class{init(){console.log(`[uid.one] GPCEnforcer registered in main world.`)}},fe=s(((e,t)=>{t.exports=function(){return typeof Promise==`function`&&Promise.prototype&&Promise.prototype.then}})),A=s((e=>{var t,n=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];e.getSymbolSize=function(e){if(!e)throw Error(`"version" cannot be null or undefined`);if(e<1||e>40)throw Error(`"version" should be in range from 1 to 40`);return e*4+17},e.getSymbolTotalCodewords=function(e){return n[e]},e.getBCHDigit=function(e){let t=0;for(;e!==0;)t++,e>>>=1;return t},e.setToSJISFunction=function(e){if(typeof e!=`function`)throw Error(`"toSJISFunc" is not a valid function.`);t=e},e.isKanjiModeEnabled=function(){return t!==void 0},e.toSJIS=function(e){return t(e)}})),j=s((e=>{e.L={bit:1},e.M={bit:0},e.Q={bit:3},e.H={bit:2};function t(t){if(typeof t!=`string`)throw Error(`Param is not a string`);switch(t.toLowerCase()){case`l`:case`low`:return e.L;case`m`:case`medium`:return e.M;case`q`:case`quartile`:return e.Q;case`h`:case`high`:return e.H;default:throw Error(`Unknown EC Level: `+t)}}e.isValid=function(e){return e&&e.bit!==void 0&&e.bit>=0&&e.bit<4},e.from=function(n,r){if(e.isValid(n))return n;try{return t(n)}catch{return r}}})),pe=s(((e,t)=>{function n(){this.buffer=[],this.length=0}n.prototype={get:function(e){let t=Math.floor(e/8);return(this.buffer[t]>>>7-e%8&1)==1},put:function(e,t){for(let n=0;n<t;n++)this.putBit((e>>>t-n-1&1)==1)},getLengthInBits:function(){return this.length},putBit:function(e){let t=Math.floor(this.length/8);this.buffer.length<=t&&this.buffer.push(0),e&&(this.buffer[t]|=128>>>this.length%8),this.length++}},t.exports=n})),me=s(((e,t)=>{function n(e){if(!e||e<1)throw Error(`BitMatrix size must be defined and greater than 0`);this.size=e,this.data=new Uint8Array(e*e),this.reservedBit=new Uint8Array(e*e)}n.prototype.set=function(e,t,n,r){let i=e*this.size+t;this.data[i]=n,r&&(this.reservedBit[i]=!0)},n.prototype.get=function(e,t){return this.data[e*this.size+t]},n.prototype.xor=function(e,t,n){this.data[e*this.size+t]^=n},n.prototype.isReserved=function(e,t){return this.reservedBit[e*this.size+t]},t.exports=n})),he=s((e=>{var t=A().getSymbolSize;e.getRowColCoords=function(e){if(e===1)return[];let n=Math.floor(e/7)+2,r=t(e),i=r===145?26:Math.ceil((r-13)/(2*n-2))*2,a=[r-7];for(let e=1;e<n-1;e++)a[e]=a[e-1]-i;return a.push(6),a.reverse()},e.getPositions=function(t){let n=[],r=e.getRowColCoords(t),i=r.length;for(let e=0;e<i;e++)for(let t=0;t<i;t++)e===0&&t===0||e===0&&t===i-1||e===i-1&&t===0||n.push([r[e],r[t]]);return n}})),ge=s((e=>{var t=A().getSymbolSize,n=7;e.getPositions=function(e){let r=t(e);return[[0,0],[r-n,0],[0,r-n]]}})),M=s((e=>{e.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};var t={N1:3,N2:3,N3:40,N4:10};e.isValid=function(e){return e!=null&&e!==``&&!isNaN(e)&&e>=0&&e<=7},e.from=function(t){return e.isValid(t)?parseInt(t,10):void 0},e.getPenaltyN1=function(e){let n=e.size,r=0,i=0,a=0,o=null,s=null;for(let c=0;c<n;c++){i=a=0,o=s=null;for(let l=0;l<n;l++){let n=e.get(c,l);n===o?i++:(i>=5&&(r+=t.N1+(i-5)),o=n,i=1),n=e.get(l,c),n===s?a++:(a>=5&&(r+=t.N1+(a-5)),s=n,a=1)}i>=5&&(r+=t.N1+(i-5)),a>=5&&(r+=t.N1+(a-5))}return r},e.getPenaltyN2=function(e){let n=e.size,r=0;for(let t=0;t<n-1;t++)for(let i=0;i<n-1;i++){let n=e.get(t,i)+e.get(t,i+1)+e.get(t+1,i)+e.get(t+1,i+1);(n===4||n===0)&&r++}return r*t.N2},e.getPenaltyN3=function(e){let n=e.size,r=0,i=0,a=0;for(let t=0;t<n;t++){i=a=0;for(let o=0;o<n;o++)i=i<<1&2047|e.get(t,o),o>=10&&(i===1488||i===93)&&r++,a=a<<1&2047|e.get(o,t),o>=10&&(a===1488||a===93)&&r++}return r*t.N3},e.getPenaltyN4=function(e){let n=0,r=e.data.length;for(let t=0;t<r;t++)n+=e.data[t];return Math.abs(Math.ceil(n*100/r/5)-10)*t.N4};function n(t,n,r){switch(t){case e.Patterns.PATTERN000:return(n+r)%2==0;case e.Patterns.PATTERN001:return n%2==0;case e.Patterns.PATTERN010:return r%3==0;case e.Patterns.PATTERN011:return(n+r)%3==0;case e.Patterns.PATTERN100:return(Math.floor(n/2)+Math.floor(r/3))%2==0;case e.Patterns.PATTERN101:return n*r%2+n*r%3==0;case e.Patterns.PATTERN110:return(n*r%2+n*r%3)%2==0;case e.Patterns.PATTERN111:return(n*r%3+(n+r)%2)%2==0;default:throw Error(`bad maskPattern:`+t)}}e.applyMask=function(e,t){let r=t.size;for(let i=0;i<r;i++)for(let a=0;a<r;a++)t.isReserved(a,i)||t.xor(a,i,n(e,a,i))},e.getBestMask=function(t,n){let r=Object.keys(e.Patterns).length,i=0,a=1/0;for(let o=0;o<r;o++){n(o),e.applyMask(o,t);let r=e.getPenaltyN1(t)+e.getPenaltyN2(t)+e.getPenaltyN3(t)+e.getPenaltyN4(t);e.applyMask(o,t),r<a&&(a=r,i=o)}return i}})),N=s((e=>{var t=j(),n=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],r=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];e.getBlocksCount=function(e,r){switch(r){case t.L:return n[(e-1)*4+0];case t.M:return n[(e-1)*4+1];case t.Q:return n[(e-1)*4+2];case t.H:return n[(e-1)*4+3];default:return}},e.getTotalCodewordsCount=function(e,n){switch(n){case t.L:return r[(e-1)*4+0];case t.M:return r[(e-1)*4+1];case t.Q:return r[(e-1)*4+2];case t.H:return r[(e-1)*4+3];default:return}}})),P=s((e=>{var t=new Uint8Array(512),n=new Uint8Array(256);(function(){let e=1;for(let r=0;r<255;r++)t[r]=e,n[e]=r,e<<=1,e&256&&(e^=285);for(let e=255;e<512;e++)t[e]=t[e-255]})(),e.log=function(e){if(e<1)throw Error(`log(`+e+`)`);return n[e]},e.exp=function(e){return t[e]},e.mul=function(e,r){return e===0||r===0?0:t[n[e]+n[r]]}})),F=s((e=>{var t=P();e.mul=function(e,n){let r=new Uint8Array(e.length+n.length-1);for(let i=0;i<e.length;i++)for(let a=0;a<n.length;a++)r[i+a]^=t.mul(e[i],n[a]);return r},e.mod=function(e,n){let r=new Uint8Array(e);for(;r.length-n.length>=0;){let e=r[0];for(let i=0;i<n.length;i++)r[i]^=t.mul(n[i],e);let i=0;for(;i<r.length&&r[i]===0;)i++;r=r.slice(i)}return r},e.generateECPolynomial=function(n){let r=new Uint8Array([1]);for(let i=0;i<n;i++)r=e.mul(r,new Uint8Array([1,t.exp(i)]));return r}})),I=s(((e,t)=>{var n=F();function r(e){this.genPoly=void 0,this.degree=e,this.degree&&this.initialize(this.degree)}r.prototype.initialize=function(e){this.degree=e,this.genPoly=n.generateECPolynomial(this.degree)},r.prototype.encode=function(e){if(!this.genPoly)throw Error(`Encoder not initialized`);let t=new Uint8Array(e.length+this.degree);t.set(e);let r=n.mod(t,this.genPoly),i=this.degree-r.length;if(i>0){let e=new Uint8Array(this.degree);return e.set(r,i),e}return r},t.exports=r})),L=s((e=>{e.isValid=function(e){return!isNaN(e)&&e>=1&&e<=40}})),R=s((e=>{var t=`[0-9]+`,n=`[A-Z $%*+\\-./:]+`,r=`(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+`;r=r.replace(/u/g,`\\u`);var i=`(?:(?![A-Z0-9 $%*+\\-./:]|`+r+`)(?:.|[\r
]))+`;e.KANJI=new RegExp(r,`g`),e.BYTE_KANJI=RegExp(`[^A-Z0-9 $%*+\\-./:]+`,`g`),e.BYTE=new RegExp(i,`g`),e.NUMERIC=new RegExp(t,`g`),e.ALPHANUMERIC=new RegExp(n,`g`);var a=RegExp(`^`+r+`$`),o=RegExp(`^`+t+`$`),s=RegExp(`^[A-Z0-9 $%*+\\-./:]+$`);e.testKanji=function(e){return a.test(e)},e.testNumeric=function(e){return o.test(e)},e.testAlphanumeric=function(e){return s.test(e)}})),z=s((e=>{var t=L(),n=R();e.NUMERIC={id:`Numeric`,bit:1,ccBits:[10,12,14]},e.ALPHANUMERIC={id:`Alphanumeric`,bit:2,ccBits:[9,11,13]},e.BYTE={id:`Byte`,bit:4,ccBits:[8,16,16]},e.KANJI={id:`Kanji`,bit:8,ccBits:[8,10,12]},e.MIXED={bit:-1},e.getCharCountIndicator=function(e,n){if(!e.ccBits)throw Error(`Invalid mode: `+e);if(!t.isValid(n))throw Error(`Invalid version: `+n);return n>=1&&n<10?e.ccBits[0]:n<27?e.ccBits[1]:e.ccBits[2]},e.getBestModeForData=function(t){return n.testNumeric(t)?e.NUMERIC:n.testAlphanumeric(t)?e.ALPHANUMERIC:n.testKanji(t)?e.KANJI:e.BYTE},e.toString=function(e){if(e&&e.id)return e.id;throw Error(`Invalid mode`)},e.isValid=function(e){return e&&e.bit&&e.ccBits};function r(t){if(typeof t!=`string`)throw Error(`Param is not a string`);switch(t.toLowerCase()){case`numeric`:return e.NUMERIC;case`alphanumeric`:return e.ALPHANUMERIC;case`kanji`:return e.KANJI;case`byte`:return e.BYTE;default:throw Error(`Unknown mode: `+t)}}e.from=function(t,n){if(e.isValid(t))return t;try{return r(t)}catch{return n}}})),_e=s((e=>{var t=A(),n=N(),r=j(),i=z(),a=L(),o=7973,s=t.getBCHDigit(o);function c(t,n,r){for(let i=1;i<=40;i++)if(n<=e.getCapacity(i,r,t))return i}function l(e,t){return i.getCharCountIndicator(e,t)+4}function u(e,t){let n=0;return e.forEach(function(e){let r=l(e.mode,t);n+=r+e.getBitsLength()}),n}function d(t,n){for(let r=1;r<=40;r++)if(u(t,r)<=e.getCapacity(r,n,i.MIXED))return r}e.from=function(e,t){return a.isValid(e)?parseInt(e,10):t},e.getCapacity=function(e,r,o){if(!a.isValid(e))throw Error(`Invalid QR Code version`);o===void 0&&(o=i.BYTE);let s=(t.getSymbolTotalCodewords(e)-n.getTotalCodewordsCount(e,r))*8;if(o===i.MIXED)return s;let c=s-l(o,e);switch(o){case i.NUMERIC:return Math.floor(c/10*3);case i.ALPHANUMERIC:return Math.floor(c/11*2);case i.KANJI:return Math.floor(c/13);case i.BYTE:default:return Math.floor(c/8)}},e.getBestVersionForData=function(e,t){let n,i=r.from(t,r.M);if(Array.isArray(e)){if(e.length>1)return d(e,i);if(e.length===0)return 1;n=e[0]}else n=e;return c(n.mode,n.getLength(),i)},e.getEncodedBits=function(e){if(!a.isValid(e)||e<7)throw Error(`Invalid QR Code version`);let n=e<<12;for(;t.getBCHDigit(n)-s>=0;)n^=o<<t.getBCHDigit(n)-s;return e<<12|n}})),ve=s((e=>{var t=A(),n=1335,r=21522,i=t.getBCHDigit(n);e.getEncodedBits=function(e,a){let o=e.bit<<3|a,s=o<<10;for(;t.getBCHDigit(s)-i>=0;)s^=n<<t.getBCHDigit(s)-i;return(o<<10|s)^r}})),ye=s(((e,t)=>{var n=z();function r(e){this.mode=n.NUMERIC,this.data=e.toString()}r.getBitsLength=function(e){return 10*Math.floor(e/3)+(e%3?e%3*3+1:0)},r.prototype.getLength=function(){return this.data.length},r.prototype.getBitsLength=function(){return r.getBitsLength(this.data.length)},r.prototype.write=function(e){let t,n,r;for(t=0;t+3<=this.data.length;t+=3)n=this.data.substr(t,3),r=parseInt(n,10),e.put(r,10);let i=this.data.length-t;i>0&&(n=this.data.substr(t),r=parseInt(n,10),e.put(r,i*3+1))},t.exports=r})),be=s(((e,t)=>{var n=z(),r=`0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:`.split(``);function i(e){this.mode=n.ALPHANUMERIC,this.data=e}i.getBitsLength=function(e){return 11*Math.floor(e/2)+e%2*6},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(e){let t;for(t=0;t+2<=this.data.length;t+=2){let n=r.indexOf(this.data[t])*45;n+=r.indexOf(this.data[t+1]),e.put(n,11)}this.data.length%2&&e.put(r.indexOf(this.data[t]),6)},t.exports=i})),B=s(((e,t)=>{var n=z();function r(e){this.mode=n.BYTE,typeof e==`string`?this.data=new TextEncoder().encode(e):this.data=new Uint8Array(e)}r.getBitsLength=function(e){return e*8},r.prototype.getLength=function(){return this.data.length},r.prototype.getBitsLength=function(){return r.getBitsLength(this.data.length)},r.prototype.write=function(e){for(let t=0,n=this.data.length;t<n;t++)e.put(this.data[t],8)},t.exports=r})),xe=s(((e,t)=>{var n=z(),r=A();function i(e){this.mode=n.KANJI,this.data=e}i.getBitsLength=function(e){return e*13},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(e){let t;for(t=0;t<this.data.length;t++){let n=r.toSJIS(this.data[t]);if(n>=33088&&n<=40956)n-=33088;else if(n>=57408&&n<=60351)n-=49472;else throw Error(`Invalid SJIS character: `+this.data[t]+`
Make sure your charset is UTF-8`);n=(n>>>8&255)*192+(n&255),e.put(n,13)}},t.exports=i})),Se=s(((e,t)=>{var n={single_source_shortest_paths:function(e,t,r){var i={},a={};a[t]=0;var o=n.PriorityQueue.make();o.push(t,0);for(var s,c,l,u,d,f,p,m,h;!o.empty();)for(l in s=o.pop(),c=s.value,u=s.cost,d=e[c]||{},d)d.hasOwnProperty(l)&&(f=d[l],p=u+f,m=a[l],h=a[l]===void 0,(h||m>p)&&(a[l]=p,o.push(l,p),i[l]=c));if(r!==void 0&&a[r]===void 0){var g=[`Could not find a path from `,t,` to `,r,`.`].join(``);throw Error(g)}return i},extract_shortest_path_from_predecessor_list:function(e,t){for(var n=[],r=t;r;)n.push(r),e[r],r=e[r];return n.reverse(),n},find_path:function(e,t,r){var i=n.single_source_shortest_paths(e,t,r);return n.extract_shortest_path_from_predecessor_list(i,r)},PriorityQueue:{make:function(e){var t=n.PriorityQueue,r={},i;for(i in e||={},t)t.hasOwnProperty(i)&&(r[i]=t[i]);return r.queue=[],r.sorter=e.sorter||t.default_sorter,r},default_sorter:function(e,t){return e.cost-t.cost},push:function(e,t){var n={value:e,cost:t};this.queue.push(n),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};t!==void 0&&(t.exports=n)})),Ce=s((e=>{var t=z(),n=ye(),r=be(),i=B(),a=xe(),o=R(),s=A(),c=Se();function l(e){return unescape(encodeURIComponent(e)).length}function u(e,t,n){let r=[],i;for(;(i=e.exec(n))!==null;)r.push({data:i[0],index:i.index,mode:t,length:i[0].length});return r}function d(e){let n=u(o.NUMERIC,t.NUMERIC,e),r=u(o.ALPHANUMERIC,t.ALPHANUMERIC,e),i,a;return s.isKanjiModeEnabled()?(i=u(o.BYTE,t.BYTE,e),a=u(o.KANJI,t.KANJI,e)):(i=u(o.BYTE_KANJI,t.BYTE,e),a=[]),n.concat(r,i,a).sort(function(e,t){return e.index-t.index}).map(function(e){return{data:e.data,mode:e.mode,length:e.length}})}function f(e,o){switch(o){case t.NUMERIC:return n.getBitsLength(e);case t.ALPHANUMERIC:return r.getBitsLength(e);case t.KANJI:return a.getBitsLength(e);case t.BYTE:return i.getBitsLength(e)}}function p(e){return e.reduce(function(e,t){let n=e.length-1>=0?e[e.length-1]:null;return n&&n.mode===t.mode?(e[e.length-1].data+=t.data,e):(e.push(t),e)},[])}function m(e){let n=[];for(let r=0;r<e.length;r++){let i=e[r];switch(i.mode){case t.NUMERIC:n.push([i,{data:i.data,mode:t.ALPHANUMERIC,length:i.length},{data:i.data,mode:t.BYTE,length:i.length}]);break;case t.ALPHANUMERIC:n.push([i,{data:i.data,mode:t.BYTE,length:i.length}]);break;case t.KANJI:n.push([i,{data:i.data,mode:t.BYTE,length:l(i.data)}]);break;case t.BYTE:n.push([{data:i.data,mode:t.BYTE,length:l(i.data)}])}}return n}function h(e,n){let r={},i={start:{}},a=[`start`];for(let o=0;o<e.length;o++){let s=e[o],c=[];for(let e=0;e<s.length;e++){let l=s[e],u=``+o+e;c.push(u),r[u]={node:l,lastCount:0},i[u]={};for(let e=0;e<a.length;e++){let o=a[e];r[o]&&r[o].node.mode===l.mode?(i[o][u]=f(r[o].lastCount+l.length,l.mode)-f(r[o].lastCount,l.mode),r[o].lastCount+=l.length):(r[o]&&(r[o].lastCount=l.length),i[o][u]=f(l.length,l.mode)+4+t.getCharCountIndicator(l.mode,n))}}a=c}for(let e=0;e<a.length;e++)i[a[e]].end=0;return{map:i,table:r}}function g(e,o){let c,l=t.getBestModeForData(e);if(c=t.from(o,l),c!==t.BYTE&&c.bit<l.bit)throw Error(`"`+e+`" cannot be encoded with mode `+t.toString(c)+`.
 Suggested mode is: `+t.toString(l));switch(c===t.KANJI&&!s.isKanjiModeEnabled()&&(c=t.BYTE),c){case t.NUMERIC:return new n(e);case t.ALPHANUMERIC:return new r(e);case t.KANJI:return new a(e);case t.BYTE:return new i(e)}}e.fromArray=function(e){return e.reduce(function(e,t){return typeof t==`string`?e.push(g(t,null)):t.data&&e.push(g(t.data,t.mode)),e},[])},e.fromString=function(t,n){let r=h(m(d(t,s.isKanjiModeEnabled())),n),i=c.find_path(r.map,`start`,`end`),a=[];for(let e=1;e<i.length-1;e++)a.push(r.table[i[e]].node);return e.fromArray(p(a))},e.rawSplit=function(t){return e.fromArray(d(t,s.isKanjiModeEnabled()))}})),we=s((e=>{var t=A(),n=j(),r=pe(),i=me(),a=he(),o=ge(),s=M(),c=N(),l=I(),u=_e(),d=ve(),f=z(),p=Ce();function m(e,t){let n=e.size,r=o.getPositions(t);for(let t=0;t<r.length;t++){let i=r[t][0],a=r[t][1];for(let t=-1;t<=7;t++)if(!(i+t<=-1||n<=i+t))for(let r=-1;r<=7;r++)a+r<=-1||n<=a+r||(t>=0&&t<=6&&(r===0||r===6)||r>=0&&r<=6&&(t===0||t===6)||t>=2&&t<=4&&r>=2&&r<=4?e.set(i+t,a+r,!0,!0):e.set(i+t,a+r,!1,!0))}}function h(e){let t=e.size;for(let n=8;n<t-8;n++){let t=n%2==0;e.set(n,6,t,!0),e.set(6,n,t,!0)}}function g(e,t){let n=a.getPositions(t);for(let t=0;t<n.length;t++){let r=n[t][0],i=n[t][1];for(let t=-2;t<=2;t++)for(let n=-2;n<=2;n++)t===-2||t===2||n===-2||n===2||t===0&&n===0?e.set(r+t,i+n,!0,!0):e.set(r+t,i+n,!1,!0)}}function v(e,t){let n=e.size,r=u.getEncodedBits(t),i,a,o;for(let t=0;t<18;t++)i=Math.floor(t/3),a=t%3+n-8-3,o=(r>>t&1)==1,e.set(i,a,o,!0),e.set(a,i,o,!0)}function y(e,t,n){let r=e.size,i=d.getEncodedBits(t,n),a,o;for(a=0;a<15;a++)o=(i>>a&1)==1,a<6?e.set(a,8,o,!0):a<8?e.set(a+1,8,o,!0):e.set(r-15+a,8,o,!0),a<8?e.set(8,r-a-1,o,!0):a<9?e.set(8,15-a-1+1,o,!0):e.set(8,15-a-1,o,!0);e.set(r-8,8,1,!0)}function b(e,t){let n=e.size,r=-1,i=n-1,a=7,o=0;for(let s=n-1;s>0;s-=2)for(s===6&&s--;;){for(let n=0;n<2;n++)if(!e.isReserved(i,s-n)){let r=!1;o<t.length&&(r=(t[o]>>>a&1)==1),e.set(i,s-n,r),a--,a===-1&&(o++,a=7)}if(i+=r,i<0||n<=i){i-=r,r=-r;break}}}function x(e,n,i){let a=new r;i.forEach(function(t){a.put(t.mode.bit,4),a.put(t.getLength(),f.getCharCountIndicator(t.mode,e)),t.write(a)});let o=(t.getSymbolTotalCodewords(e)-c.getTotalCodewordsCount(e,n))*8;for(a.getLengthInBits()+4<=o&&a.put(0,4);a.getLengthInBits()%8!=0;)a.putBit(0);let s=(o-a.getLengthInBits())/8;for(let e=0;e<s;e++)a.put(e%2?17:236,8);return S(a,e,n)}function S(e,n,r){let i=t.getSymbolTotalCodewords(n),a=i-c.getTotalCodewordsCount(n,r),o=c.getBlocksCount(n,r),s=o-i%o,u=Math.floor(i/o),d=Math.floor(a/o),f=d+1,p=u-d,m=new l(p),h=0,g=Array(o),v=Array(o),y=0,b=new Uint8Array(e.buffer);for(let e=0;e<o;e++){let t=e<s?d:f;g[e]=b.slice(h,h+t),v[e]=m.encode(g[e]),h+=t,y=Math.max(y,t)}let x=new Uint8Array(i),S=0,C,w;for(C=0;C<y;C++)for(w=0;w<o;w++)C<g[w].length&&(x[S++]=g[w][C]);for(C=0;C<p;C++)for(w=0;w<o;w++)x[S++]=v[w][C];return x}function C(e,n,r,a){let o;if(Array.isArray(e))o=p.fromArray(e);else if(typeof e==`string`){let t=n;if(!t){let n=p.rawSplit(e);t=u.getBestVersionForData(n,r)}o=p.fromString(e,t||40)}else throw Error(`Invalid data`);let c=u.getBestVersionForData(o,r);if(!c)throw Error(`The amount of data is too big to be stored in a QR Code`);if(!n)n=c;else if(n<c)throw Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+c+`.
`);let l=x(n,r,o),d=new i(t.getSymbolSize(n));return m(d,n),h(d),g(d,n),y(d,r,0),n>=7&&v(d,n),b(d,l),isNaN(a)&&(a=s.getBestMask(d,y.bind(null,d,r))),s.applyMask(a,d),y(d,r,a),{modules:d,version:n,errorCorrectionLevel:r,maskPattern:a,segments:o}}e.create=function(e,r){if(e===void 0||e===``)throw Error(`No input text`);let i=n.M,a,o;return r!==void 0&&(i=n.from(r.errorCorrectionLevel,n.M),a=u.from(r.version),o=s.from(r.maskPattern),r.toSJISFunc&&t.setToSJISFunction(r.toSJISFunc)),C(e,a,i,o)}})),V=s((e=>{function t(e){if(typeof e==`number`&&(e=e.toString()),typeof e!=`string`)throw Error(`Color should be defined as hex string`);let t=e.slice().replace(`#`,``).split(``);if(t.length<3||t.length===5||t.length>8)throw Error(`Invalid hex color: `+e);(t.length===3||t.length===4)&&(t=Array.prototype.concat.apply([],t.map(function(e){return[e,e]}))),t.length===6&&t.push(`F`,`F`);let n=parseInt(t.join(``),16);return{r:n>>24&255,g:n>>16&255,b:n>>8&255,a:n&255,hex:`#`+t.slice(0,6).join(``)}}e.getOptions=function(e){e||={},e.color||={};let n=e.margin===void 0||e.margin===null||e.margin<0?4:e.margin,r=e.width&&e.width>=21?e.width:void 0,i=e.scale||4;return{width:r,scale:r?4:i,margin:n,color:{dark:t(e.color.dark||`#000000ff`),light:t(e.color.light||`#ffffffff`)},type:e.type,rendererOpts:e.rendererOpts||{}}},e.getScale=function(e,t){return t.width&&t.width>=e+t.margin*2?t.width/(e+t.margin*2):t.scale},e.getImageWidth=function(t,n){let r=e.getScale(t,n);return Math.floor((t+n.margin*2)*r)},e.qrToImageData=function(t,n,r){let i=n.modules.size,a=n.modules.data,o=e.getScale(i,r),s=Math.floor((i+r.margin*2)*o),c=r.margin*o,l=[r.color.light,r.color.dark];for(let e=0;e<s;e++)for(let n=0;n<s;n++){let u=(e*s+n)*4,d=r.color.light;if(e>=c&&n>=c&&e<s-c&&n<s-c){let t=Math.floor((e-c)/o),r=Math.floor((n-c)/o);d=l[+!!a[t*i+r]]}t[u++]=d.r,t[u++]=d.g,t[u++]=d.b,t[u]=d.a}}})),Te=s((e=>{var t=V();function n(e,t,n){e.clearRect(0,0,t.width,t.height),t.style||={},t.height=n,t.width=n,t.style.height=n+`px`,t.style.width=n+`px`}function r(){try{return document.createElement(`canvas`)}catch{throw Error(`You need to specify a canvas element`)}}e.render=function(e,i,a){let o=a,s=i;o===void 0&&(!i||!i.getContext)&&(o=i,i=void 0),i||(s=r()),o=t.getOptions(o);let c=t.getImageWidth(e.modules.size,o),l=s.getContext(`2d`),u=l.createImageData(c,c);return t.qrToImageData(u.data,e,o),n(l,s,c),l.putImageData(u,0,0),s},e.renderToDataURL=function(t,n,r){let i=r;i===void 0&&(!n||!n.getContext)&&(i=n,n=void 0),i||={};let a=e.render(t,n,i),o=i.type||`image/png`,s=i.rendererOpts||{};return a.toDataURL(o,s.quality)}})),Ee=s((e=>{var t=V();function n(e,t){let n=e.a/255,r=t+`="`+e.hex+`"`;return n<1?r+` `+t+`-opacity="`+n.toFixed(2).slice(1)+`"`:r}function r(e,t,n){let r=e+t;return n!==void 0&&(r+=` `+n),r}function i(e,t,n){let i=``,a=0,o=!1,s=0;for(let c=0;c<e.length;c++){let l=Math.floor(c%t),u=Math.floor(c/t);!l&&!o&&(o=!0),e[c]?(s++,c>0&&l>0&&e[c-1]||(i+=o?r(`M`,l+n,.5+u+n):r(`m`,a,0),a=0,o=!1),l+1<t&&e[c+1]||(i+=r(`h`,s),s=0)):a++}return i}e.render=function(e,r,a){let o=t.getOptions(r),s=e.modules.size,c=e.modules.data,l=s+o.margin*2,u=o.color.light.a?`<path `+n(o.color.light,`fill`)+` d="M0 0h`+l+`v`+l+`H0z"/>`:``,d=`<path `+n(o.color.dark,`stroke`)+` d="`+i(c,s,o.margin)+`"/>`,f=`viewBox="0 0 `+l+` `+l+`"`,p=`<svg xmlns="http://www.w3.org/2000/svg" `+(o.width?`width="`+o.width+`" height="`+o.width+`" `:``)+f+` shape-rendering="crispEdges">`+u+d+`</svg>
`;return typeof a==`function`&&a(null,p),p}})),De=l(s((e=>{var t=fe(),n=we(),r=Te(),i=Ee();function a(e,r,i,a,o){let s=[].slice.call(arguments,1),c=s.length,l=typeof s[c-1]==`function`;if(!l&&!t())throw Error(`Callback required as last argument`);if(l){if(c<2)throw Error(`Too few arguments provided`);c===2?(o=i,i=r,r=a=void 0):c===3&&(r.getContext&&o===void 0?(o=a,a=void 0):(o=a,a=i,i=r,r=void 0))}else{if(c<1)throw Error(`Too few arguments provided`);return c===1?(i=r,r=a=void 0):c===2&&!r.getContext&&(a=i,i=r,r=void 0),new Promise(function(t,o){try{t(e(n.create(i,a),r,a))}catch(e){o(e)}})}try{let t=n.create(i,a);o(null,e(t,r,a))}catch(e){o(e)}}e.create=n.create,e.toCanvas=a.bind(null,r.render),e.toDataURL=a.bind(null,r.renderToDataURL),e.toString=a.bind(null,function(e,t,n){return i.render(e,n)})}))(),1),H=!1;function U(){try{let e=document.getElementById(`oneuid-handshake-token`);if(e){let t=e.getAttribute(`data-token`);t&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t,origin:window.location.origin}),e&&!e.dataset.uidObserved&&(e.dataset.uidObserved=`true`,new MutationObserver(t=>{for(let n of t)if(n.type===`attributes`&&n.attributeName===`data-token`){let t=e.getAttribute(`data-token`);t?chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t,origin:window.location.origin}):chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])}}).observe(e,{attributes:!0}))}}catch(e){console.error(`[uid.one] captureSessionToken DOM handshake check failed:`,e)}try{let e=(window.wrappedJSObject||window).localStorage.getItem(`oneuid_access_token`);e&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:e,origin:window.location.origin})}catch{}if(!H)try{window.addEventListener(`message`,e=>{if(e.data&&e.data.type===`oneuid_session_login`){let t=e.data.token;t&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t,origin:window.location.origin})}else e.data&&e.data.type===`oneuid_session_logout`&&chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])}),window.addEventListener(`oneuid_session_login`,e=>{let t=(e.detail&&e.detail.wrappedJSObject?e.detail.wrappedJSObject:e.detail)?.token;t&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t,origin:window.location.origin})}),window.addEventListener(`oneuid_session_logout`,()=>{chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])}),H=!0}catch(e){console.error(`[uid.one] Failed to attach message/customEvent listeners:`,e)}}var W=new WeakSet;function G(){let e=document.querySelector(`meta[name="uid-passkey-native"]`);if(e&&e.getAttribute(`content`)===`true`)return;let t=window.location.hostname,n=window.location.protocol===`http:`&&t!==`localhost`&&t!==`127.0.0.1`,r=t===`uid.one`||t.endsWith(`.uid.one`);n||r||document.querySelectorAll(`input[type="password"]`).forEach(e=>{e.disabled||e.readOnly||e.type===`hidden`||e.style.display===`none`||e.style.visibility===`hidden`||e.autocomplete===`new-password`||W.has(e)||(Oe(e),W.add(e))})}function Oe(e){let t=document.createElement(`div`);t.className=`uid-passkey-wrapper`,t.style.position=`absolute`,t.style.zIndex=`999999`,t.style.cursor=`pointer`,document.body.appendChild(t);let n=window.getComputedStyle(e),r=parseFloat(n.paddingRight)||0;e.style.paddingRight=`${r+28}px`,e.setAttribute(`data-uid-autofill`,`true`);let i=()=>{let n=e.getBoundingClientRect();if(n.width===0||n.height===0||!document.body.contains(e)){t.style.display=`none`;return}t.style.display=`block`,t.style.top=`${n.top+window.scrollY+n.height/2}px`;let i=r+28;t.style.left=`${n.right+window.scrollX-i}px`,t.style.transform=`translateY(-50%)`};i(),window.addEventListener(`resize`,i),window.addEventListener(`scroll`,i),setInterval(i,500);let a=t.attachShadow({mode:`closed`}),o=document.createElement(`div`);o.style.cssText=`
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    color: #0B1220;
    opacity: 1;
    transition: color 0.2s ease, transform 0.2s ease, opacity 0.2s ease;
  `,o.innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-fingerprint">
    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
    <path d="M18.9 7a8 8 0 0 1 1.1 5v1a6 6 0 0 0 .8 3" />
    <path d="M8 11a4 4 0 0 1 8 0v1a10 10 0 0 0 2 6" />
    <path d="M12 11v2a14 14 0 0 0 2.5 8" />
    <path d="M8 15a18 18 0 0 0 1.8 6" />
    <path d="M4.9 19a22 22 0 0 1 -.9 -7v-1a8 8 0 0 1 12 -6.95" />
  </svg>`,o.title=chrome.runtime?.id&&chrome.i18n.getMessage(`iconTitle`)||`Login with Passkey`,o.addEventListener(`mouseenter`,()=>{o.style.color=`#1A2233`,o.style.transform=`scale(1.05)`}),o.addEventListener(`mouseleave`,()=>{o.style.color=`#0B1220`,o.style.transform=`scale(1)`});let s=async(e,t)=>{try{if(!chrome.runtime?.id){alert(`Extension context invalidated. Please refresh the page.`);return}let n=window.location.hostname,r=navigator.userAgent.includes(`Mac`)?`Chrome on macOS`:`Chrome Web`;if(!(await new Promise(e=>{chrome.runtime.sendMessage({type:`CHECK_PAIRING`},e)}))?.isPaired){let i=await new Promise(t=>{chrome.runtime.sendMessage({type:`START_OOB_AUTH`,domain:n,device:r,identifier:e},t)});if(!i?.success)return alert(`Failed to initiate Pairing`);let a=`https://uid.one/qr?challenge=${i.challenge.token}&client_id=uid-extension-client&client_name=Extension`,o=await De.toDataURL(a,{margin:2,width:200}),c=document.createElement(`div`);c.innerHTML=`
          <div style="position: fixed; inset: 0; background: rgba(2, 8, 23, 0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 9999999;">
            <div id="uid-qr-container" style="background: #ffffff; border-radius: 12px; padding: 24px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; align-items: center; gap: 16px; font-family: system-ui, sans-serif; color: #0f172a; position: relative; min-width: 280px; min-height: 320px; justify-content: center;">
              <button id="close-qr" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
              <h3 style="margin: 0; font-size: 18px; font-weight: 600;">Pair Device</h3>
              <div style="padding: 8px; border: 1px solid #e2e8f0; border-radius: 8px;">
                <img src="${o}" alt="QR Code" style="width: 200px; height: 200px; display: block;" />
              </div>
              <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center; max-width: 220px; line-height: 1.4;">
                Scan this code with the UID.ONE App, or <a href="${a}" target="_blank" style="color: #0ea5e9; text-decoration: underline; font-weight: 500; cursor: pointer;">approve on this browser</a>.
              </p>
            </div>
          </div>
        `,document.body.appendChild(c),c.querySelector(`#close-qr`)?.addEventListener(`click`,()=>c.remove());let l=setInterval(async()=>{let n=await new Promise(e=>{chrome.runtime.sendMessage({type:`POLL_OOB_STATUS`,token:i.challenge.token},e)});if(n?.success&&n.status===`APPROVED`){clearInterval(l),await new Promise(e=>chrome.runtime.sendMessage({type:`SAVE_PAIRING`,token:i.challenge.token},e));let n=c.querySelector(`#uid-qr-container`);n&&(n.innerHTML=`
                <div style="display: flex; flex-direction: column; align-items: center; gap: 16px;">
                  <div style="width: 64px; height: 64px; border-radius: 50%; background: #dcfce7; display: flex; align-items: center; justify-content: center; color: #16a34a;">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  </div>
                  <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #16a34a;">Paired Successfully!</h3>
                  <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">You can now use push notifications.</p>
                </div>
              `,setTimeout(()=>{c.remove(),s(e,t)},2e3))}},2e3);return}let i=await new Promise(e=>{chrome.runtime.sendMessage({type:`PUSH_REQUEST`,domain:n},e)});if(!i?.success){alert(`Failed to request push: `+(i?.error||`Unknown error`));return}let a=i.data.match_number,o=i.data.token,c=document.createElement(`div`);c.innerHTML=`
        <div style="position: fixed; inset: 0; background: rgba(2, 8, 23, 0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 9999999;">
          <div id="uid-match-container" style="background: #ffffff; border-radius: 12px; padding: 32px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; align-items: center; gap: 16px; font-family: system-ui, sans-serif; color: #0f172a; position: relative; min-width: 300px;">
            <button id="close-match" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
            <h3 style="margin: 0; font-size: 18px; font-weight: 600; text-align: center;">Check your phone</h3>
            <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">Enter the following number in the UID.ONE app to approve this login.</p>
            <div style="font-size: 48px; font-weight: 800; letter-spacing: 8px; color: #0f172a; padding: 16px 32px; background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; margin-top: 8px;">
              ${a}
            </div>
            <div style="display: flex; align-items: center; gap: 8px; margin-top: 16px;">
               <svg class="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation: spin 1s linear infinite;"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
               <span style="font-size: 12px; color: #64748b;">Waiting for approval...</span>
            </div>
            <style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>
          </div>
        </div>
      `,document.body.appendChild(c),c.querySelector(`#close-match`)?.addEventListener(`click`,()=>c.remove());let l=`wss://api.uid.one/ws/challenges/${o}/`,u=new WebSocket(l);u.onmessage=async e=>{try{let n=JSON.parse(e.data);if(n.status===`APPROVED`&&n.encrypted_payload){u.close();let e=await new Promise(e=>{chrome.runtime.sendMessage({type:`DECRYPT_PAYLOAD`,token:o,encrypted_payload:n.encrypted_payload},e)}),r=c.querySelector(`#uid-match-container`);e?.success&&e.decrypted_password?(r&&(r.innerHTML=`
                  <div style="display: flex; flex-direction: column; align-items: center; gap: 16px;">
                    <div style="width: 64px; height: 64px; border-radius: 50%; background: #dcfce7; display: flex; align-items: center; justify-content: center; color: #16a34a;">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                    <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #16a34a;">Approved!</h3>
                    <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">Login successful. Auto-filling...</p>
                  </div>
                `),setTimeout(()=>{t.value=e.decrypted_password,t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),c.remove(),setTimeout(()=>{let e=document.querySelector(`button[type="submit"], input[type="submit"]`);e&&e.click()},500)},500)):r&&(r.innerHTML=`
                  <button id="close-match-error" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
                  <div style="display: flex; flex-direction: column; align-items: center; gap: 16px; margin-top: 16px;">
                    <div style="width: 64px; height: 64px; border-radius: 50%; background: #fee2e2; display: flex; align-items: center; justify-content: center; color: #dc2626;">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                    </div>
                    <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #dc2626;">Failed</h3>
                    <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center; max-width: 220px;">Could not inject password.</p>
                  </div>
                `,r.querySelector(`#close-match-error`)?.addEventListener(`click`,()=>c.remove()))}}catch(e){console.error(`WS parse error`,e)}},u.onerror=e=>{console.error(`WS Error`,e)}}catch(e){console.error(`[uid.one] Error:`,e)}};o.addEventListener(`click`,async t=>{t.preventDefault(),t.stopPropagation();let n=e.closest(`form`),r=``;if(n){let e=n.querySelector(`input[type="text"], input[type="email"], input[name="email"], input[name="username"]`);e&&(r=e.value.trim())}if(!r){alert(chrome.i18n.getMessage(`errorNoUsernameProvided`)||`Please enter your email or username first to use your Passkey.`);return}await s(r,e)}),a.appendChild(o)}var ke=`urgent.wire transfer.payment.bank.password.click here.sign.contract.deadline.account details.invoice.khẩn cấp.chuyển tiền.thanh toán.ngân hàng.mật khẩu.nhấp vào.ký kết.hợp đồng.hạn chót.thông tin tài khoản.hóa đơn.عاجل.تحويل بنكي.دفع.بنك.كلمة مرور.انقر هنا.عقد.فاتورة.dringend.überweisung.zahlung.passwort.hier klicken.vertrag.rechnung.urgente.transferencia.pago.banco.contraseña.haga clic aquí.contrato.factura.virement.paiement.banque.mot de passe.cliquez ici.contrat.facture.bonifico.pagamento.banca.clicca qui.contratto.fattura.至急.振込.送金.支払い.銀行.パスワード.ここをクリック.契約.請求書.긴급.송금.결제.지불.은행.비밀번호.여기 클릭.계약.청구서.срочно.перевод.оплата.пароль.нажмите здесь.договор.счет.ด่วน.โอนเงิน.การชำระเงิน.ธนาคาร.รหัสผ่าน.คลิกที่นี่.สัญญา.ใบแจ้งหนี้.紧急.转账.汇款.支付.付款.密码.点击这里.合同.发票`.split(`.`),Ae=`approve.sign.contract.deadline.payment.phê duyệt.ký kết.hợp đồng.hạn chót.thanh toán.وافق.توقيع.عقد.الموعد النهائي.دفع.genehmigen.unterschreiben.vertrag.frist.zahlung.aprobar.firmar.contrato.fecha límite.pago.approuver.signer.contrat.date limite.paiement.approvare.firmare.contratto.scadenza.pagamento.承認.署名.契約.締め切り.支払い.승인.서명.계약.마감일.결제.одобрить.подписать.договор.крайний срок.оплата.อนุมัติ.ลงชื่อ.สัญญา.กำหนดส่ง.การชำระเงิน.审批.签署.合同.截止日期.付款`.split(`.`),je=class{init(){console.log(`[uid.one] Initializing EmailSignatureGuard...`);let e=document.createElement(`style`);e.textContent=`
      .uid-email-verified-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #ecfdf5;
        border: 1px solid #10b981;
        color: #047857;
        padding: 4px 8px;
        border-radius: 6px;
        font-family: system-ui, sans-serif;
        font-size: 12px;
        font-weight: 600;
        margin: 8px 0;
      }
      .uid-email-warning-banner {
        display: flex;
        align-items: center;
        gap: 8px;
        background: #fef2f2;
        border: 1px solid #f87171;
        color: #b91c1c;
        padding: 12px 16px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 13px;
        font-weight: 500;
        margin: 12px 0;
      }
    `+K.getStyles();let t=document.head||document.documentElement;t&&t.appendChild(e),document.addEventListener(`click`,e=>{let t=e.target.closest(`a`);if(t&&t.href&&t.href.includes(`/verify/#data=`)){e.preventDefault(),e.stopPropagation();let n=new URL(t.href).hash;if(n&&n.startsWith(`#data=`)){let e=n.substring(6);this.showVerificationDetailsModal(e)}}}),this.scanEmails(),new MutationObserver(()=>{this.scanEmails()}).observe(document.body||document.documentElement,{childList:!0,subtree:!0})}async showVerificationDetailsModal(e){try{let t=e.replace(/-/g,`+`).replace(/_/g,`/`),n=JSON.parse(atob(t)),r=n.signer,i=n.hash,a=r.replace(`did:uid:`,``),o=document.createElement(`div`);o.className=`uid-sig-overlay`,o.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999999;
        font-family: system-ui, -apple-system, sans-serif;
        color: #e4e4e7;
        opacity: 0;
        transition: opacity 0.3s ease;
      `;let s=document.createElement(`div`);s.style.cssText=`
        background: rgba(10, 10, 10, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 24px;
        width: 100%;
        max-width: 500px;
        padding: 32px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        position: relative;
        transform: translateY(20px);
        transition: transform 0.3s ease;
      `,s.innerHTML=`
        <div style="text-align: center; margin-bottom: 24px;">
          <div style="display: inline-flex; width: 64px; height: 64px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 50%; align-items: center; justify-content: center; margin-bottom: 16px; position: relative;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 4px 0; tracking: -0.025em;">Signature Authenticated</h3>
          <span style="font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; color: #10b981;">Sovereign Verification System</span>
        </div>

        <div style="display: flex; flex-direction: column; gap: 16px; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 20px;">
          <div>
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Signer Identity (DID)</div>
            <div style="font-size: 13px; font-weight: 600; color: #fff; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px; word-break: break-all;">${r}</div>
          </div>

          <div>
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Content Integrity Hash (SHA-256)</div>
            <div style="font-size: 12px; font-family: monospace; color: #a1a1aa; background: #000; border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px; word-break: break-all; user-select: all;">${i}</div>
          </div>

          <div id="uid-modal-key-section">
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Active Public Key (RSA 2048-bit)</div>
            <div style="font-size: 11px; color: #a1a1aa; display: flex; align-items: center; justify-content: space-between; cursor: pointer; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px;" id="uid-modal-toggle-key">
              <span>Show Sovereign Public Key PEM</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" id="uid-modal-arrow" style="transition: transform 0.2s;"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <textarea readonly id="uid-modal-pubkey-text" style="display: none; width: 100%; height: 100px; background: #000; color: #52525b; font-family: monospace; font-size: 9px; border: 1px solid rgba(255, 255, 255, 0.04); border-radius: 10px; padding: 8px; margin-top: 8px; resize: none; box-sizing: border-box; outline: none;"></textarea>
          </div>
        </div>

        <div style="margin-top: 28px;">
          <button id="uid-modal-close-btn" style="width: 100%; padding: 12px; border-radius: 12px; background: #27272a; border: 1px solid rgba(255, 255, 255, 0.04); color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; transition: background 0.2s;">Close</button>
        </div>
      `,o.appendChild(s),document.body.appendChild(o),setTimeout(()=>{o.style.opacity=`1`,s.style.transform=`translateY(0)`},50),chrome.runtime.sendMessage({type:`GET_USER_PUBKEY`,identifier:a},e=>{if(e&&e.success&&e.publicKey){let t=s.querySelector(`#uid-modal-pubkey-text`);t&&(t.value=e.publicKey)}});let c=!1,l=s.querySelector(`#uid-modal-toggle-key`),u=s.querySelector(`#uid-modal-pubkey-text`),d=s.querySelector(`#uid-modal-arrow`);l&&u&&l.addEventListener(`click`,()=>{c=!c,u.style.display=c?`block`:`none`,d.style.transform=c?`rotate(180deg)`:`rotate(0deg)`});let f=()=>{o.style.opacity=`0`,s.style.transform=`translateY(20px)`,setTimeout(()=>{o.remove()},300)},p=s.querySelector(`#uid-modal-close-btn`);p&&p.addEventListener(`click`,f),o.addEventListener(`click`,e=>{e.target===o&&f()})}catch(e){console.error(`[uid.one] Failed to show verification modal:`,e)}}scanEmails(){if(!u())return;let e=new Set;document.querySelectorAll(`[role="document"], [role="article"], article`).forEach(t=>{t.getAttribute(`contenteditable`)===`true`||t.tagName===`INPUT`||t.tagName===`TEXTAREA`||e.add(t)});let t=[`.a3s`,`.rps_code`,`.zmMailContent`,`.zmContent`,`.zmContentMain`,`.zmcContent`,`[id^="mailContent_"]`,`.zmc-mailview-body`,`.message-body-container`,`.message-content`,`.email-wrapped`,`.message_body`,`.msg-body`,`#messagebody`,`.v-Message-body`].join(`, `);if(document.querySelectorAll(t).forEach(t=>{t.tagName!==`IFRAME`&&e.add(t)}),document.querySelectorAll(`#uid-one-signature, .uid-email-signature-block`).forEach(t=>{let n=this.findEmailContainer(t);n&&e.add(n)}),document.querySelectorAll(`a`).forEach(t=>{let n=t.getAttribute(`href`)||``;if(n.includes(`uid.one`)&&(n.includes(`verify`)||n.includes(`data`))){let n=this.findEmailContainer(t);n&&e.add(n)}}),window!==window.top){let t=window.location.hostname||d();if((t.includes(`mail.`)||t.includes(`proton`)||t.includes(`outlook`)||t.includes(`zoho`)||t.includes(`ymail`))&&document.body&&document.body.textContent&&document.body.textContent.trim().length>10){let t=window.innerWidth,n=window.innerHeight;t>200&&n>200&&e.add(document.body)}}Array.from(e).filter(e=>!(e.classList.contains(`uid-email-signature-block`)||e.closest(`.uid-email-signature-block`))).filter(t=>!Array.from(e).some(e=>t!==e&&t.contains(e))).forEach(e=>{let t=e.textContent||``,n=`${t.length}_${t.slice(0,100).replace(/\s/g,``)}`,r=e.getAttribute(`data-uid-content-hash`);if(r&&r!==n&&(e.removeAttribute(`data-uid-processed`),e.removeAttribute(`data-uid-processing`),e.querySelectorAll(`.uid-ai-triage-badge, .uid-email-warning-banner, .uid-email-verified-badge`).forEach(e=>e.remove())),e.querySelector(`.uid-email-warning-banner, .uid-email-verified-badge, .uid-ai-triage-badge`)||e.getAttribute(`data-uid-processing`)===`true`||e.getAttribute(`data-uid-processed`)===`true`||e.querySelector(`[contenteditable="true"]`)||e.closest(`div[role="dialog"], .M9, .AD`))return;let i=e.querySelector(`#uid-one-signature`)||e.querySelector(`.uid-email-signature-block`),a=e.querySelector(`a[href*="uid.one/verify"], a[href*="/verify/#data="]`)!==null||/uid\.one[\/|%2F]verify[\/|%2F]/i.test(e.innerHTML),o=t.match(/(ký số bởi|digitally signed by) UID\.one/i);i||o||a?(e.setAttribute(`data-uid-processing`,`true`),e.setAttribute(`data-uid-content-hash`,n),this.processVerification(e,i).finally(()=>{e.removeAttribute(`data-uid-processing`),e.setAttribute(`data-uid-processed`,`true`)})):t.trim().length>10&&(p()?(e.setAttribute(`data-uid-processing`,`true`),e.setAttribute(`data-uid-content-hash`,n),new K().triage(e,!1,``).then(()=>{e.setAttribute(`data-uid-processed`,`true`)}).catch(console.error).finally(()=>{e.removeAttribute(`data-uid-processing`)})):(e.setAttribute(`data-uid-content-hash`,n),e.setAttribute(`data-uid-processed`,`true`)))})}findEmailContainer(e){let t=e.parentElement;for(;t&&t!==document.body;){if(t.matches(`.a3s, .rps_code, .zmContent, .zmContentMain, .zmcContent, [id^="mailContent_"], .zmc-mailview-body, .message-body-container, .message-content, .email-wrapped, .message_body, .msg-body, #messagebody, .v-Message-body`))return t;t=t.parentElement}return document.body}processVerification(e,t){return u()?new Promise(n=>{try{let r=``,i=``,a=``;if(t&&(r=t.getAttribute(`data-sig`)||``,i=t.getAttribute(`data-signer`)||``),!i){let t=(e.innerHTML||``).match(/uid\.one[\/|%2F]verify[\/|%2F](?:#|%23)data(?:=|%3D)([A-Za-z0-9_-]+)/i);if(t&&t[1])try{let e=atob(t[1].replace(/-/g,`+`).replace(/_/g,`/`)),n=JSON.parse(e);r=n.sig||``,i=n.signer||``,a=n.hash||``}catch(e){console.warn(`[uid.one] Failed to decode verify link hash:`,e)}}if(!i){let t=chrome.i18n.getMessage(`warningInvalidSignature`)||`Invalid signature or email has been tampered with.`;new K().triage(e,!1,``,t).catch(console.error),n();return}console.log(`[uid.one] Verifying signature for ${i} (hash: ${a||`DOM`}, sig: ${r.slice(0,10)}...)`),chrome.runtime.sendMessage({type:`GET_USER_PUBKEY`,identifier:i.replace(`did:uid:`,``)},async t=>{try{if(!t||!t.success||!t.publicKey)throw Error(t?.error||`Public key lookup failed`);let n=t.publicKey.replace(`-----BEGIN PUBLIC KEY-----`,``).replace(`-----END PUBLIC KEY-----`,``).replace(/\s+/g,``),o=atob(n),s=new Uint8Array(o.length);for(let e=0;e<o.length;e++)s[e]=o.charCodeAt(e);let c=await crypto.subtle.importKey(`spki`,s.buffer,{name:`RSASSA-PKCS1-v1_5`,hash:{name:`SHA-256`}},!1,[`verify`]),l=atob(r.replace(/-/g,`+`).replace(/_/g,`/`)),u=new Uint8Array(l.length);for(let e=0;e<l.length;e++)u[e]=l.charCodeAt(e);let d=a,f=``,p=null,m=e.cloneNode(!0),h=m.querySelector(`.uid-email-signature-block`);h&&h.remove(),m.querySelectorAll(`.uid-ai-triage-badge, .uid-email-warning-banner, .uid-email-verified-badge`).forEach(e=>e.remove());let g=(m.innerText||m.textContent||``).replace(/\r\n/g,`
`).trim(),v=new TextEncoder,y=v.encode(g);p=await crypto.subtle.digest(`SHA-256`,y),f=Array.from(new Uint8Array(p)).map(e=>e.toString(16).padStart(2,`0`)).join(``);let b=!1;if(d){let e=v.encode(d);b=await crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,c,u,e)}if(b||=await crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,c,u,y),!b){let e=v.encode(f);b=await crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,c,u,e)}if(!b&&p&&(b=await crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,c,u,p)),b){if(console.log(`[uid.one] Cryptographic signature VERIFIED successfully for ${i}`),e.querySelectorAll(`.uid-ai-triage-badge, .uid-email-warning-banner`).forEach(e=>e.remove()),!e.querySelector(`.uid-email-verified-badge`)){let t=document.createElement(`div`);t.className=`uid-email-verified-badge`,t.innerHTML=`
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 4px;">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>${chrome.i18n.getMessage(`alertVerifiedSender`,[i.replace(`did:uid:`,``)])||`This email is digitally signed and verified by UID.one for sender: ${i.replace(`did:uid:`,``)}`}</span>
                  `,e.insertBefore(t,e.firstChild)}e.querySelectorAll(`.uid-verify-link, a[href*="/verify/#data="]`).forEach(e=>{e.style.setProperty(`display`,`none`,`important`)})}else{console.warn(`[uid.one] Cryptographic signature VERIFICATION FAILED for ${i}`);let t=chrome.i18n.getMessage(`warningContentTampered`)||`Digital signature does not match email content (Content has been modified).`;new K().triage(e,!1,``,t).catch(console.error)}}catch(t){console.warn(`[uid.one] Cryptographic verification error:`,t);let n=chrome.i18n.getMessage(`warningVerifyError`,[t.message])||`Technical error verifying signature: ${t.message}`;new K().triage(e,!1,``,n).catch(console.warn)}finally{n()}})}catch{let t=chrome.i18n.getMessage(`warningVerificationFailed`)||`Digital signature verification failed.`;new K().triage(e,!1,``,t).catch(console.error),n()}}):Promise.resolve()}},Me=class{init(){console.log(`[uid.one] Initializing EmailSendInterceptor...`),document.addEventListener(`click`,e=>{let t=e.target;if(!t)return;let n=t.closest(`[role="button"], button, input[type="submit"], input[type="button"]`);if(!n)return;let r=(n.innerText||n.textContent||``).trim().toLowerCase(),i=(n.getAttribute(`aria-label`)||``).toLowerCase(),a=(n.getAttribute(`title`)||``).toLowerCase(),o=(n.getAttribute(`data-tooltip`)||``).toLowerCase();(r===`send`||r===`gửi`||r===`envoyer`||r===`enviar`||i.includes(`send`)||i.includes(`gửi`)||a.includes(`send`)||a.includes(`gửi`)||o.includes(`send`)||o.includes(`gửi`)||n.classList.contains(`aoO`))&&this.cleanupLoadingBlocks()},!0),document.addEventListener(`keydown`,e=>{(e.ctrlKey||e.metaKey)&&e.key===`Enter`&&this.cleanupLoadingBlocks()},!0)}cleanupLoadingBlocks(){let e=document.querySelectorAll(`.uid-email-signature-loading-block`);e.length>0&&(console.log(`[uid.one] Cleaning up ${e.length} signature loading blocks before send.`),e.forEach(e=>{let t=e.parentElement;e.remove(),t&&t.dispatchEvent(new Event(`input`,{bubbles:!0}))}))}},Ne=class{activeButton=null;activeTarget=null;activeIframe=null;init(){if(window!==window.top||!p())return;document.addEventListener(`focusin`,e=>{if(!u())return;let t=e.target;t&&(t.closest(`[contenteditable="true"]`)||t.tagName===`INPUT`||t.tagName===`TEXTAREA`)&&(t.clientHeight>80||t.getAttribute(`role`)===`textbox`)&&this.showButton(t,null)}),document.addEventListener(`click`,e=>{if(!u())return;let t=e.target;this.activeButton&&!this.activeButton.contains(t)&&this.activeTarget&&!this.activeTarget.contains(t)&&this.hideButton()});let e=()=>{u()&&document.querySelectorAll(`iframe`).forEach(e=>{this.bindToIframe(e)})};e();let t=setInterval(()=>{if(!u()){clearInterval(t);return}e()},1e3),n=setInterval(()=>{if(!u()){clearInterval(n);return}if(this.activeTarget&&this.activeButton){if(this.activeIframe&&!document.body.contains(this.activeIframe)){this.hideButton();return}let e=this.activeIframe?this.activeIframe.contentDocument||this.activeIframe.contentWindow?.document:document;if(!e||!e.body.contains(this.activeTarget)||this.activeTarget.offsetWidth===0){this.hideButton();return}this.updatePosition()}},500)}bindToIframe(e){try{let t=e.contentDocument||e.contentWindow?.document;if(!t||t.__uidBound)return;t.__uidBound=!0,t.addEventListener(`focusin`,t=>{if(!u())return;let n=t.target;if(!n)return;let r=n.closest(`[contenteditable="true"]`)||n.tagName===`INPUT`||n.tagName===`TEXTAREA`,i=n.tagName===`BODY`&&n.ownerDocument!==document;r&&(i||n.clientHeight>80||n.getAttribute(`role`)===`textbox`)&&this.showButton(n,e)}),t.addEventListener(`click`,e=>{if(!u())return;let t=e.target;this.activeButton&&!this.activeButton.contains(t)&&this.activeTarget&&!this.activeTarget.contains(t)&&this.hideButton()}),t.addEventListener(`contextmenu`,e=>{if(!u())return;let t=e.target;if(t.closest(`[contenteditable="true"]`)||t.tagName===`INPUT`||t.tagName===`TEXTAREA`){J(t);let e=x(t);e||=C(),e?chrome.runtime.sendMessage({type:`GET_PROFILE`},t=>{if(t&&t.success&&t.email&&S(t.email)!==S(e)){chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!1});return}chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!0})}):chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!1})}else chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!0})})}catch{}}showButton(e,t){this.activeTarget=e,this.activeIframe=t;let n=x(e);n||=C(),chrome.runtime.sendMessage({type:`GET_PROFILE`},e=>{let t=!1,r=``,i=!1;if(e&&e.success&&e.email&&(i=!0,r=e.email,n&&(t=S(e.email)===S(n))),i&&!t){this.hideButton();return}if(!this.activeButton){let e=document;this.activeButton=e.createElement(`div`),this.activeButton.className=`uid-floating-sign-btn`,e.body.appendChild(this.activeButton)}this.activeButton.style.display=`flex`,this.activeButton.style.cssText=`
        position: fixed;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        border-radius: 50%;
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        user-select: none;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.16);
        background: ${t?`#2563eb`:`#94a3b8`};
        border: 1px solid ${t?`#1d4ed8`:`#cbd5e1`};
        color: #ffffff;
      `,this.activeButton.onmouseenter=()=>{this.activeButton&&(this.activeButton.style.transform=`scale(1.1)`,t?this.activeButton.style.background=`#1d4ed8`:(this.activeButton.style.background=`#64748b`,this.activeButton.style.borderColor=`#475569`))},this.activeButton.onmouseleave=()=>{this.activeButton&&(this.activeButton.style.transform=`scale(1)`,t?this.activeButton.style.background=`#2563eb`:(this.activeButton.style.background=`#94a3b8`,this.activeButton.style.borderColor=`#cbd5e1`))},this.activeButton.innerHTML=`
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-lock-check">
          <path stroke="none" d="M0 0h24v24H0z" fill="none" />
          <path d="M11.5 21h-4.5a2 2 0 0 1 -2 -2v-6a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v.5" />
          <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
          <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
          <path d="M15 19l2 2l4 -4" />
        </svg>
      `;let a=(this.activeButton.ownerDocument||document).createElement(`div`);a.className=`uid-floating-tooltip`,a.style.cssText=`
        position: absolute;
        bottom: 42px;
        right: 0;
        background: #0f172a;
        color: #f8fafc;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 11px;
        font-family: system-ui, -apple-system, sans-serif;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.15s ease;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        border: 1px solid #334155;
      `,t?a.textContent=chrome.i18n.getMessage(`floatingTooltipSign`)||`Sign this email with UID.one`:(a.textContent=chrome.i18n.getMessage(`floatingTooltipMismatch`,[n||`unknown`,r||`none`])||`Sender email mismatch`,a.style.background=`#881337`,a.style.borderColor=`#fda4af`,a.style.color=`#ffe4e6`),this.activeButton.appendChild(a),this.activeButton.onmouseover=()=>{a.style.opacity=`1`},this.activeButton.onmouseout=()=>{a.style.opacity=`0`},this.activeButton.onclick=e=>{if(e.stopPropagation(),!t){alert(a.textContent);return}this.handleSignAction()},this.updatePosition()})}updatePosition(){if(!this.activeTarget||!this.activeButton)return;let e=0,t=0;if(this.activeIframe){let n=this.activeIframe.getBoundingClientRect(),r=this.activeTarget.getBoundingClientRect();e=n.top+r.bottom-46,t=n.left+r.right-46}else{let n=this.activeTarget.getBoundingClientRect();e=n.bottom-46,t=n.right-46}this.activeButton.style.top=`${e}px`,this.activeButton.style.left=`${t}px`}hideButton(){this.activeButton&&(this.activeButton.style.display=`none`),this.activeTarget=null,this.activeIframe=null}handleSignAction(){this.activeTarget&&(J(this.activeTarget),Z((this.activeIframe?this.activeIframe.contentWindow:window)?.getSelection()?.toString()||(this.activeTarget.tagName===`INPUT`||this.activeTarget.tagName===`TEXTAREA`?this.activeTarget.value:this.activeTarget.innerText||``)).catch(console.error))}},K=class{static getStyles(){return`
      .uid-ai-triage-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 8px;
        border-radius: 6px;
        font-family: system-ui, sans-serif;
        font-size: 12px;
        font-weight: 600;
        margin: 8px 4px;
      }
      .uid-ai-priority {
        background: #fef3c7;
        border: 1px solid #d97706;
        color: #92400e;
      }
      .uid-ai-safe {
        background: #eff6ff;
        border: 1px solid #3b82f6;
        color: #1e40af;
      }
      .uid-ai-unverified {
        background: #fff1f2;
        border: 1px solid #f43f5e;
        color: #9f1239;
        animation: uid-pulse 2s infinite;
      }
      @keyframes uid-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
      }
    `}async triage(e,t,n,r){if(e.querySelector(`.uid-ai-triage-badge`))return;let i=e.textContent||``,a=`SAFE`,o=``;try{if(typeof window<`u`&&window.ai&&window.ai.assistant){let e=await window.ai.assistant.create(),s=`
          Analyze this email.
          - Signed state: ${t?`SIGNED & VERIFIED BY `+n:r?`INVALID SIGNATURE: `+r:`UNSIGNED / UNVERIFIED SENDER`}
          - Content: "${i.slice(0,1e3)}"
          
          Respond in exactly this JSON format:
          {
            "category": "PRIORITY" (if verified urgent action), "SAFE" (if normal trusted message), or "UNVERIFIED_SUSPICIOUS" (if unsigned or looks like BEC/phishing),
            "reason": "short 1 sentence explanation in Vietnamese"
          }
        `,c=await e.prompt(s),l=JSON.parse(c);a=l.category||`SAFE`,o=l.reason||``,r&&a===`UNVERIFIED_SUSPICIOUS`&&(o=`${o} ${r}`)}else{let e=i.toLowerCase(),n=new RegExp(ke.map(e=>e.replace(/[-\/\\^$*+?.()|[\]{}]/g,`\\$&`)).join(`|`),`i`).test(e);if(t){let t=new RegExp(Ae.map(e=>e.replace(/[-\/\\^$*+?.()|[\]{}]/g,`\\$&`)).join(`|`),`i`).test(e);a=t?`PRIORITY`:`SAFE`,o=t?chrome.i18n.getMessage(`reasonSignedImportant`)||`Email from trusted partner contains important action request.`:chrome.i18n.getMessage(`reasonSignedSafe`)||`Safe email from partner.`}else{a=`UNVERIFIED_SUSPICIOUS`;let e=``;e=n?chrome.i18n.getMessage(`reasonUnsignedSensitive`)||`Unsigned email contains sensitive financial keywords.`:chrome.i18n.getMessage(`reasonUnsigned`)||`Email is not signed.`,r?o=`${e} ${r}`:(a=n?`UNVERIFIED_SUSPICIOUS`:`SAFE`,o=e)}}}catch{a=t?`SAFE`:`UNVERIFIED_SUSPICIOUS`,o=t?chrome.i18n.getMessage(`reasonTrustedVerified`)||`Trusted source has been verified.`:r?`${chrome.i18n.getMessage(`reasonNotSigned`)||`Sender is unsigned.`} ${r}`:chrome.i18n.getMessage(`reasonNotSigned`)||`Sender is unsigned.`}this.injectBadge(e,a,o)}injectBadge(e,t,n){if(t!==`UNVERIFIED_SUSPICIOUS`||e.querySelector(`.uid-email-warning-banner, .uid-email-verified-badge`))return;let r=document.createElement(`div`);r.className=`uid-ai-triage-badge uid-ai-unverified`,r.style.cssText=`
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      border-radius: 8px;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 12px;
      font-weight: 600;
      margin: 8px 0;
      background: #fff1f2;
      border: 1px solid #f43f5e;
      color: #9f1239;
    `,r.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle;">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg>
      <span>${chrome.i18n.getMessage(`filterWarning`,[n])||`UID Trust Shield: Warning (${n})`}</span>
    `,e.insertBefore(r,e.firstChild)}};console.log(`[uid.one] Content script loaded on`,window.location.hostname);var q=null;function J(e){q=e}document.addEventListener(`contextmenu`,e=>{if(u())if(q=e.target,q.closest(`[contenteditable="true"]`)||q.tagName===`INPUT`||q.tagName===`TEXTAREA`){let e=x(q);e||=C(),e?chrome.runtime.sendMessage({type:`GET_PROFILE`},t=>{if(t&&t.success&&t.email&&S(t.email)!==S(e)){chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!1});return}chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!0})}):p()?chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!1}):chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!0})}else chrome.runtime.sendMessage({type:`SET_CONTEXT_MENU_ENABLED`,enabled:!0})}),chrome.runtime.onMessage.addListener((e,t,n)=>{e.action===`START_PDF_SIGNING`?Pe(e.url).catch(console.error):e.action===`START_TEXT_SIGNING`&&Z(e.text).catch(console.error)});function Y(e,t){console.log(`[uid.one - ${t}] ${e}`)}function X(e,t){let n=document.createElement(`div`);n.className=`uid-otp-overlay`,n.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999999;
    font-family: system-ui, -apple-system, sans-serif;
    color: #e4e4e7;
  `;let r=document.createElement(`div`);r.style.cssText=`
    background: rgba(10, 10, 10, 0.95);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 24px;
    width: 90%;
    max-width: 400px;
    padding: 32px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    text-align: center;
  `,r.innerHTML=`
    <div style="margin-bottom: 20px;">
      <div style="display: inline-flex; width: 56px; height: 56px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 50%; align-items: center; justify-content: center; margin-bottom: 12px;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
      </div>
      <h3 style="font-size: 18px; font-weight: 700; color: #fff; margin: 0 0 6px 0;">${chrome.i18n.getMessage(`otpPromptTitle`)||`Google Authenticator`}</h3>
      <p style="font-size: 13px; color: #a1a1aa; margin: 0; line-height: 1.5;">${chrome.i18n.getMessage(`otpPromptDesc`)||`Please enter the 6-digit OTP code to verify your digital signature:`}</p>
    </div>

    <div style="margin-bottom: 24px;">
      <input type="text" id="uid-otp-input" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="000000" style="
        width: 80%;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 12px;
        font-size: 28px;
        letter-spacing: 6px;
        text-align: center;
        color: #fff;
        font-family: monospace;
        outline: none;
        box-sizing: border-box;
      ">
    </div>

    <div style="display: flex; gap: 12px; justify-content: center;">
      <button id="uid-otp-cancel" style="
        flex: 1;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: #a1a1aa;
        padding: 10px 16px;
        border-radius: 10px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
      ">${chrome.i18n.getMessage(`otpCancel`)||`Cancel`}</button>
      <button id="uid-otp-confirm" style="
        flex: 1;
        background: #10b981;
        border: none;
        color: #fff;
        padding: 10px 16px;
        border-radius: 10px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
      ">${chrome.i18n.getMessage(`otpConfirm`)||`Sign`}</button>
    </div>
  `,n.appendChild(r),document.body.appendChild(n);let i=n.querySelector(`#uid-otp-input`);i&&(i.focus(),i.addEventListener(`focus`,()=>{i.style.borderColor=`rgba(16, 185, 129, 0.5)`}),i.addEventListener(`blur`,()=>{i.style.borderColor=`rgba(255, 255, 255, 0.1)`}),i.addEventListener(`input`,()=>{i.value=i.value.replace(/[^0-9]/g,``)}),i.addEventListener(`keydown`,e=>{e.key===`Enter`&&a()}));let a=()=>{let t=i?.value||``;if(t.length!==6){alert(chrome.i18n.getMessage(`otpErrorLength`)||`The OTP code must be exactly 6 digits.`);return}n.remove(),e(t)};n.querySelector(`#uid-otp-cancel`)?.addEventListener(`click`,()=>{n.remove(),t()}),n.querySelector(`#uid-otp-confirm`)?.addEventListener(`click`,a)}async function Z(e){let t=q;if(!t){Y(`No target element to sign`,`error`);return}let n=t.closest(`[contenteditable="true"]`);n&&(t=n);let r=e;if(r||=t.innerText||t.value||``,r.replace(/\s/g,``).length===0){alert(chrome.i18n.getMessage(`alertEnterContent`)||`Please enter content before signing.`);return}chrome.runtime.sendMessage({type:`GET_PROFILE`},e=>{if(!e||!e.success){let t=e?.error||``;if(t.includes(`403`)||t.includes(`401`)||t.includes(`paired`)||t.includes(`Not paired`)||t.includes(`expired`))alert(chrome.i18n.getMessage(`alertSessionExpired`)||`Session expired or not linked. Please log in to UID.one and click 'Link Extension' to continue.`);else{let e=t||`Failed to retrieve account details.`;alert(chrome.i18n.getMessage(`errorVerification`,[e])||`Verification error: ${e}`)}return}let n=e.email;X(e=>{Y(`Signing selected text...`,`info`);let i=new TextEncoder().encode(r);crypto.subtle.digest(`SHA-256`,i).then(i=>{let a=Array.from(new Uint8Array(i)).map(e=>e.toString(16).padStart(2,`0`)).join(``),o=setInterval(()=>{chrome.runtime.sendMessage({type:`HEARTBEAT`},()=>{chrome.runtime.lastError&&console.warn(`[uid.one] Heartbeat error:`,chrome.runtime.lastError.message)})},1e4);chrome.runtime.sendMessage({action:`REQUEST_DIGITAL_SIGNATURE`,domain:window.location.hostname,user_agent:navigator.userAgent,identifier:`Text Signature`,otp_code:e,metadata:{text_hash:a,text_snippet:r.slice(0,100)}},e=>{if(clearInterval(o),e&&e.success)Ie(t,e.signature,n,a,e.signer),Y(`Signature applied successfully!`,`success`);else{let t=e?.error||chrome.i18n.getMessage(`alertRejected`)||`Signing request was rejected or expired.`;alert(t)}})})},()=>{Y(`Signing cancelled by user.`,`info`)})})}async function Pe(e){chrome.runtime.sendMessage({type:`GET_PROFILE`},async t=>{if(!t||!t.success){let e=t?.error||``;if(e.includes(`403`)||e.includes(`401`)||e.includes(`paired`)||e.includes(`Not paired`)||e.includes(`expired`))alert(chrome.i18n.getMessage(`alertSessionExpired`)||`Session expired or not linked. Please log in to UID.one and click 'Link Extension' to continue.`);else{let t=e||`Failed to retrieve account details.`;alert(chrome.i18n.getMessage(`errorVerification`,[t])||`Verification error: ${t}`)}return}Y(`Fetching PDF for signing...`,`info`);let n=await(await fetch(e)).arrayBuffer(),r=await crypto.subtle.digest(`SHA-256`,n),i=Array.from(new Uint8Array(r)).map(e=>e.toString(16).padStart(2,`0`)).join(``),a=setInterval(()=>{chrome.runtime.sendMessage({type:`HEARTBEAT`},()=>{chrome.runtime.lastError&&console.warn(`[uid.one] Heartbeat error:`,chrome.runtime.lastError.message)})},1e4);X(t=>{chrome.runtime.sendMessage({action:`REQUEST_DIGITAL_SIGNATURE`,domain:window.location.hostname,user_agent:navigator.userAgent,identifier:`Digital Signature`,otp_code:t,metadata:{pdf_hash:i,document_url:e}},e=>{clearInterval(a),e&&e.success?Y(`PDF signed successfully!`,`success`):Y(`PDF signing failed or was rejected: `+(e?.error||`Unknown error`),`error`)})},()=>{clearInterval(a),Y(`PDF signing cancelled by user`,`info`)})})}function Fe(e){let t=e.closest(`div[role="dialog"], .M9, .AD, .zmCompose, .compose-box`);if(!t&&window.parent&&window.parent!==window)try{let e=window.parent.document.querySelectorAll(`iframe`);for(let n=0;n<e.length;n++)if(e[n].contentWindow===window){t=e[n].closest(`div[role="dialog"], .M9, .AD, .zmCompose, .compose-box`);break}}catch{}if(!t&&(t=e.ownerDocument.querySelector(`.zmCompose, .compose-box, [role="dialog"]`),!t&&window.parent&&window.parent!==window))try{t=window.parent.document.querySelector(`.zmCompose, .compose-box, [role="dialog"]`)}catch{}if(!t)return;let n=t.querySelector(`.aYy, .hz, [role="heading"], .co, .zmCompose-header, .compose-header`);if(!n)return;let r=n.ownerDocument;if(n.querySelector(`.uid-compose-signed-badge`))return;let i=r.createElement(`span`);i.className=`uid-compose-signed-badge`,i.style.cssText=`
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: rgba(16, 185, 129, 0.1);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #047857;
    padding: 2px 8px;
    border-radius: 6px;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 11px;
    font-weight: 600;
    margin-left: 12px;
    vertical-align: middle;
    user-select: none;
  `,i.innerHTML=`
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle; margin-right: 2px;">
      <path d="M20 6L9 17l-5-5"></path>
    </svg>
    <span>Signed by UID.one</span>
  `,n.appendChild(i)}function Ie(e,t,n,r,i){let a=new Date,o=chrome.i18n.getUILanguage()||`en-US`,s=a.toLocaleTimeString(o,{hour:`2-digit`,minute:`2-digit`})+` — `+a.toLocaleDateString(o),c=i||`did:uid:${n}`,l=JSON.stringify({sig:t,signer:c,hash:r}),u=`https://uid.one/verify/#data=${btoa(l).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}`;if(e.isContentEditable||e.getAttribute(`contenteditable`)===`true`){let n=e.querySelector(`.uid-email-signature-loading-block`);n&&n.remove();let r=e.querySelector(`.uid-email-signature-block`);r&&r.remove();let i=e.querySelector(`#uid-one-signature`);i&&i.remove();let a=e.ownerDocument,o=a.createElement(`div`);o.id=`uid-one-signature`,o.setAttribute(`data-signer`,c),o.setAttribute(`data-sig`,t),o.style.display=`none`;let l=a.createElement(`div`);l.className=`uid-email-signature-block`,l.setAttribute(`contenteditable`,`false`),l.style.cssText=`
      position: relative;
      border-top: 1px solid #e2e8f0;
      margin-top: 24px;
      padding-top: 12px;
      padding-bottom: 12px;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 13px;
      color: #475569;
      max-width: 500px;
      display: block;
      user-select: none;
      text-align: left;
      overflow: hidden;
    `,l.innerHTML=`
      <div style="display: flex; align-items: center; gap: 6px; font-weight: 600; color: #059669; margin-bottom: 2px; position: relative; z-index: 1;">
        <span style="font-size: 14px; margin-right: 4px; display: inline-block; vertical-align: middle;">🔐</span>
        <a href="${u}" class="uid-signature-link-text" style="color: #059669; text-decoration: none; font-weight: 600; font-family: system-ui, -apple-system, sans-serif; display: inline-block; vertical-align: middle;">
          ${chrome.i18n.getMessage(`signatureTitle`)||`This email is digitally signed by UID.one`}
        </a>
      </div>
      <div style="font-size: 11px; color: #64748b; line-height: 1.5; position: relative; z-index: 1; padding-left: 0;">
        ${chrome.i18n.getMessage(`signatureSigner`)||`Signer`}: <span style="font-family: monospace; color: #0f172a; font-weight: 500;">${c}</span><br>
        ${chrome.i18n.getMessage(`signatureTime`)||`Signing Time`}: ${s}
        <a href="${u}" class="uid-verify-link" style="display:none !important; width:0; height:0; opacity:0; visibility:hidden;" aria-hidden="true"></a>
      </div>
    `,e.firstChild?e.insertBefore(o,e.firstChild):e.appendChild(o),e.appendChild(l),Fe(e)}else if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let t=`\n\n[🔐 ${chrome.i18n.getMessage(`signatureTitle`)||`Digitally signed by UID.one`}]\n${chrome.i18n.getMessage(`signatureSigner`)||`Signer`}: ${n}\n${chrome.i18n.getMessage(`signatureTime`)||`Time`}: ${s}`;e.value+=t}e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}var Q=!1;function $(){if(Q)return;if(Q=!0,!chrome.runtime?.id){console.warn(`[uid.one] Extension context invalidated. Please refresh the page.`);return}console.log(`[uid.one] Content script initialized on:`,window.location.href);let e=document.createElement(`meta`);e.name=`uid-extension-client-active`,e.content=`true`;let t=document.head||document.documentElement;t&&t.appendChild(e);try{G()}catch(e){console.error(`[uid.one] injectAll failed:`,e)}let n=[{name:`FileUploadInterceptor`,run:()=>new ie().init()},{name:`ClipboardInterceptor`,run:()=>new ae().init()},{name:`FormInterceptor`,run:()=>new oe().init()},{name:`OriginVerifier`,run:()=>new k().init()},{name:`ScreenshotProtector`,run:()=>new O().init()},{name:`ViewportCleaner`,run:()=>new ce().init()},{name:`NotificationBlocker`,run:()=>new ue().init()},{name:`CookieGuard`,run:()=>new le().init()},{name:`GPCEnforcer`,run:()=>new de().init()},{name:`TextDLPShield`,run:()=>new se().init()},{name:`EmailSignatureGuard`,run:()=>new je().init()},{name:`EmailSendInterceptor`,run:()=>new Me().init()},{name:`ComposerFloatingSignButton`,run:()=>new Ne().init()},{name:`captureSessionToken`,run:()=>U()}];for(let e of n)try{e.run(),console.log(`[uid.one] Subsystem ${e.name} loaded successfully.`)}catch(t){console.error(`[uid.one] Failed to initialize ${e.name}:`,t)}let r=new MutationObserver(()=>{if(!u()){r.disconnect();return}G(),U()});r.observe(document.body,{childList:!0,subtree:!0})}return document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,$):$(),e.handleTextSigning=Z,Object.defineProperty(e,`lastRightClickedElement`,{enumerable:!0,get:function(){return q}}),e.setLastRightClickedElement=J,e})({});