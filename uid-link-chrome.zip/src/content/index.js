var _=(function(e){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var t=Object.create,n=Object.defineProperty,r=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,a=Object.getPrototypeOf,o=Object.prototype.hasOwnProperty,s=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),c=(e,t,a,s)=>{if(t&&typeof t==`object`||typeof t==`function`)for(var c=i(t),l=0,u=c.length,d;l<u;l++)d=c[l],!o.call(e,d)&&d!==a&&n(e,d,{get:(e=>t[e]).bind(null,d),enumerable:!(s=r(t,d))||s.enumerable});return e},l=(e,r,i)=>(i=e==null?{}:t(a(e)),c(r||!e||!e.__esModule?n(i,`default`,{value:e,enumerable:!0}):i,e)),u=s(((e,t)=>{t.exports=function(){return typeof Promise==`function`&&Promise.prototype&&Promise.prototype.then}})),d=s((e=>{var t,n=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];e.getSymbolSize=function(e){if(!e)throw Error(`"version" cannot be null or undefined`);if(e<1||e>40)throw Error(`"version" should be in range from 1 to 40`);return e*4+17},e.getSymbolTotalCodewords=function(e){return n[e]},e.getBCHDigit=function(e){let t=0;for(;e!==0;)t++,e>>>=1;return t},e.setToSJISFunction=function(e){if(typeof e!=`function`)throw Error(`"toSJISFunc" is not a valid function.`);t=e},e.isKanjiModeEnabled=function(){return t!==void 0},e.toSJIS=function(e){return t(e)}})),f=s((e=>{e.L={bit:1},e.M={bit:0},e.Q={bit:3},e.H={bit:2};function t(t){if(typeof t!=`string`)throw Error(`Param is not a string`);switch(t.toLowerCase()){case`l`:case`low`:return e.L;case`m`:case`medium`:return e.M;case`q`:case`quartile`:return e.Q;case`h`:case`high`:return e.H;default:throw Error(`Unknown EC Level: `+t)}}e.isValid=function(e){return e&&e.bit!==void 0&&e.bit>=0&&e.bit<4},e.from=function(n,r){if(e.isValid(n))return n;try{return t(n)}catch{return r}}})),p=s(((e,t)=>{function n(){this.buffer=[],this.length=0}n.prototype={get:function(e){let t=Math.floor(e/8);return(this.buffer[t]>>>7-e%8&1)==1},put:function(e,t){for(let n=0;n<t;n++)this.putBit((e>>>t-n-1&1)==1)},getLengthInBits:function(){return this.length},putBit:function(e){let t=Math.floor(this.length/8);this.buffer.length<=t&&this.buffer.push(0),e&&(this.buffer[t]|=128>>>this.length%8),this.length++}},t.exports=n})),m=s(((e,t)=>{function n(e){if(!e||e<1)throw Error(`BitMatrix size must be defined and greater than 0`);this.size=e,this.data=new Uint8Array(e*e),this.reservedBit=new Uint8Array(e*e)}n.prototype.set=function(e,t,n,r){let i=e*this.size+t;this.data[i]=n,r&&(this.reservedBit[i]=!0)},n.prototype.get=function(e,t){return this.data[e*this.size+t]},n.prototype.xor=function(e,t,n){this.data[e*this.size+t]^=n},n.prototype.isReserved=function(e,t){return this.reservedBit[e*this.size+t]},t.exports=n})),h=s((e=>{var t=d().getSymbolSize;e.getRowColCoords=function(e){if(e===1)return[];let n=Math.floor(e/7)+2,r=t(e),i=r===145?26:Math.ceil((r-13)/(2*n-2))*2,a=[r-7];for(let e=1;e<n-1;e++)a[e]=a[e-1]-i;return a.push(6),a.reverse()},e.getPositions=function(t){let n=[],r=e.getRowColCoords(t),i=r.length;for(let e=0;e<i;e++)for(let t=0;t<i;t++)e===0&&t===0||e===0&&t===i-1||e===i-1&&t===0||n.push([r[e],r[t]]);return n}})),g=s((e=>{var t=d().getSymbolSize,n=7;e.getPositions=function(e){let r=t(e);return[[0,0],[r-n,0],[0,r-n]]}})),v=s((e=>{e.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};var t={N1:3,N2:3,N3:40,N4:10};e.isValid=function(e){return e!=null&&e!==``&&!isNaN(e)&&e>=0&&e<=7},e.from=function(t){return e.isValid(t)?parseInt(t,10):void 0},e.getPenaltyN1=function(e){let n=e.size,r=0,i=0,a=0,o=null,s=null;for(let c=0;c<n;c++){i=a=0,o=s=null;for(let l=0;l<n;l++){let n=e.get(c,l);n===o?i++:(i>=5&&(r+=t.N1+(i-5)),o=n,i=1),n=e.get(l,c),n===s?a++:(a>=5&&(r+=t.N1+(a-5)),s=n,a=1)}i>=5&&(r+=t.N1+(i-5)),a>=5&&(r+=t.N1+(a-5))}return r},e.getPenaltyN2=function(e){let n=e.size,r=0;for(let t=0;t<n-1;t++)for(let i=0;i<n-1;i++){let n=e.get(t,i)+e.get(t,i+1)+e.get(t+1,i)+e.get(t+1,i+1);(n===4||n===0)&&r++}return r*t.N2},e.getPenaltyN3=function(e){let n=e.size,r=0,i=0,a=0;for(let t=0;t<n;t++){i=a=0;for(let o=0;o<n;o++)i=i<<1&2047|e.get(t,o),o>=10&&(i===1488||i===93)&&r++,a=a<<1&2047|e.get(o,t),o>=10&&(a===1488||a===93)&&r++}return r*t.N3},e.getPenaltyN4=function(e){let n=0,r=e.data.length;for(let t=0;t<r;t++)n+=e.data[t];return Math.abs(Math.ceil(n*100/r/5)-10)*t.N4};function n(t,n,r){switch(t){case e.Patterns.PATTERN000:return(n+r)%2==0;case e.Patterns.PATTERN001:return n%2==0;case e.Patterns.PATTERN010:return r%3==0;case e.Patterns.PATTERN011:return(n+r)%3==0;case e.Patterns.PATTERN100:return(Math.floor(n/2)+Math.floor(r/3))%2==0;case e.Patterns.PATTERN101:return n*r%2+n*r%3==0;case e.Patterns.PATTERN110:return(n*r%2+n*r%3)%2==0;case e.Patterns.PATTERN111:return(n*r%3+(n+r)%2)%2==0;default:throw Error(`bad maskPattern:`+t)}}e.applyMask=function(e,t){let r=t.size;for(let i=0;i<r;i++)for(let a=0;a<r;a++)t.isReserved(a,i)||t.xor(a,i,n(e,a,i))},e.getBestMask=function(t,n){let r=Object.keys(e.Patterns).length,i=0,a=1/0;for(let o=0;o<r;o++){n(o),e.applyMask(o,t);let r=e.getPenaltyN1(t)+e.getPenaltyN2(t)+e.getPenaltyN3(t)+e.getPenaltyN4(t);e.applyMask(o,t),r<a&&(a=r,i=o)}return i}})),y=s((e=>{var t=f(),n=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],r=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];e.getBlocksCount=function(e,r){switch(r){case t.L:return n[(e-1)*4+0];case t.M:return n[(e-1)*4+1];case t.Q:return n[(e-1)*4+2];case t.H:return n[(e-1)*4+3];default:return}},e.getTotalCodewordsCount=function(e,n){switch(n){case t.L:return r[(e-1)*4+0];case t.M:return r[(e-1)*4+1];case t.Q:return r[(e-1)*4+2];case t.H:return r[(e-1)*4+3];default:return}}})),b=s((e=>{var t=new Uint8Array(512),n=new Uint8Array(256);(function(){let e=1;for(let r=0;r<255;r++)t[r]=e,n[e]=r,e<<=1,e&256&&(e^=285);for(let e=255;e<512;e++)t[e]=t[e-255]})(),e.log=function(e){if(e<1)throw Error(`log(`+e+`)`);return n[e]},e.exp=function(e){return t[e]},e.mul=function(e,r){return e===0||r===0?0:t[n[e]+n[r]]}})),x=s((e=>{var t=b();e.mul=function(e,n){let r=new Uint8Array(e.length+n.length-1);for(let i=0;i<e.length;i++)for(let a=0;a<n.length;a++)r[i+a]^=t.mul(e[i],n[a]);return r},e.mod=function(e,n){let r=new Uint8Array(e);for(;r.length-n.length>=0;){let e=r[0];for(let i=0;i<n.length;i++)r[i]^=t.mul(n[i],e);let i=0;for(;i<r.length&&r[i]===0;)i++;r=r.slice(i)}return r},e.generateECPolynomial=function(n){let r=new Uint8Array([1]);for(let i=0;i<n;i++)r=e.mul(r,new Uint8Array([1,t.exp(i)]));return r}})),S=s(((e,t)=>{var n=x();function r(e){this.genPoly=void 0,this.degree=e,this.degree&&this.initialize(this.degree)}r.prototype.initialize=function(e){this.degree=e,this.genPoly=n.generateECPolynomial(this.degree)},r.prototype.encode=function(e){if(!this.genPoly)throw Error(`Encoder not initialized`);let t=new Uint8Array(e.length+this.degree);t.set(e);let r=n.mod(t,this.genPoly),i=this.degree-r.length;if(i>0){let e=new Uint8Array(this.degree);return e.set(r,i),e}return r},t.exports=r})),C=s((e=>{e.isValid=function(e){return!isNaN(e)&&e>=1&&e<=40}})),w=s((e=>{var t=`[0-9]+`,n=`[A-Z $%*+\\-./:]+`,r=`(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+`;r=r.replace(/u/g,`\\u`);var i=`(?:(?![A-Z0-9 $%*+\\-./:]|`+r+`)(?:.|[\r
]))+`;e.KANJI=new RegExp(r,`g`),e.BYTE_KANJI=RegExp(`[^A-Z0-9 $%*+\\-./:]+`,`g`),e.BYTE=new RegExp(i,`g`),e.NUMERIC=new RegExp(t,`g`),e.ALPHANUMERIC=new RegExp(n,`g`);var a=RegExp(`^`+r+`$`),o=RegExp(`^`+t+`$`),s=RegExp(`^[A-Z0-9 $%*+\\-./:]+$`);e.testKanji=function(e){return a.test(e)},e.testNumeric=function(e){return o.test(e)},e.testAlphanumeric=function(e){return s.test(e)}})),T=s((e=>{var t=C(),n=w();e.NUMERIC={id:`Numeric`,bit:1,ccBits:[10,12,14]},e.ALPHANUMERIC={id:`Alphanumeric`,bit:2,ccBits:[9,11,13]},e.BYTE={id:`Byte`,bit:4,ccBits:[8,16,16]},e.KANJI={id:`Kanji`,bit:8,ccBits:[8,10,12]},e.MIXED={bit:-1},e.getCharCountIndicator=function(e,n){if(!e.ccBits)throw Error(`Invalid mode: `+e);if(!t.isValid(n))throw Error(`Invalid version: `+n);return n>=1&&n<10?e.ccBits[0]:n<27?e.ccBits[1]:e.ccBits[2]},e.getBestModeForData=function(t){return n.testNumeric(t)?e.NUMERIC:n.testAlphanumeric(t)?e.ALPHANUMERIC:n.testKanji(t)?e.KANJI:e.BYTE},e.toString=function(e){if(e&&e.id)return e.id;throw Error(`Invalid mode`)},e.isValid=function(e){return e&&e.bit&&e.ccBits};function r(t){if(typeof t!=`string`)throw Error(`Param is not a string`);switch(t.toLowerCase()){case`numeric`:return e.NUMERIC;case`alphanumeric`:return e.ALPHANUMERIC;case`kanji`:return e.KANJI;case`byte`:return e.BYTE;default:throw Error(`Unknown mode: `+t)}}e.from=function(t,n){if(e.isValid(t))return t;try{return r(t)}catch{return n}}})),ee=s((e=>{var t=d(),n=y(),r=f(),i=T(),a=C(),o=7973,s=t.getBCHDigit(o);function c(t,n,r){for(let i=1;i<=40;i++)if(n<=e.getCapacity(i,r,t))return i}function l(e,t){return i.getCharCountIndicator(e,t)+4}function u(e,t){let n=0;return e.forEach(function(e){let r=l(e.mode,t);n+=r+e.getBitsLength()}),n}function p(t,n){for(let r=1;r<=40;r++)if(u(t,r)<=e.getCapacity(r,n,i.MIXED))return r}e.from=function(e,t){return a.isValid(e)?parseInt(e,10):t},e.getCapacity=function(e,r,o){if(!a.isValid(e))throw Error(`Invalid QR Code version`);o===void 0&&(o=i.BYTE);let s=(t.getSymbolTotalCodewords(e)-n.getTotalCodewordsCount(e,r))*8;if(o===i.MIXED)return s;let c=s-l(o,e);switch(o){case i.NUMERIC:return Math.floor(c/10*3);case i.ALPHANUMERIC:return Math.floor(c/11*2);case i.KANJI:return Math.floor(c/13);case i.BYTE:default:return Math.floor(c/8)}},e.getBestVersionForData=function(e,t){let n,i=r.from(t,r.M);if(Array.isArray(e)){if(e.length>1)return p(e,i);if(e.length===0)return 1;n=e[0]}else n=e;return c(n.mode,n.getLength(),i)},e.getEncodedBits=function(e){if(!a.isValid(e)||e<7)throw Error(`Invalid QR Code version`);let n=e<<12;for(;t.getBCHDigit(n)-s>=0;)n^=o<<t.getBCHDigit(n)-s;return e<<12|n}})),te=s((e=>{var t=d(),n=1335,r=21522,i=t.getBCHDigit(n);e.getEncodedBits=function(e,a){let o=e.bit<<3|a,s=o<<10;for(;t.getBCHDigit(s)-i>=0;)s^=n<<t.getBCHDigit(s)-i;return(o<<10|s)^r}})),E=s(((e,t)=>{var n=T();function r(e){this.mode=n.NUMERIC,this.data=e.toString()}r.getBitsLength=function(e){return 10*Math.floor(e/3)+(e%3?e%3*3+1:0)},r.prototype.getLength=function(){return this.data.length},r.prototype.getBitsLength=function(){return r.getBitsLength(this.data.length)},r.prototype.write=function(e){let t,n,r;for(t=0;t+3<=this.data.length;t+=3)n=this.data.substr(t,3),r=parseInt(n,10),e.put(r,10);let i=this.data.length-t;i>0&&(n=this.data.substr(t),r=parseInt(n,10),e.put(r,i*3+1))},t.exports=r})),D=s(((e,t)=>{var n=T(),r=`0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:`.split(``);function i(e){this.mode=n.ALPHANUMERIC,this.data=e}i.getBitsLength=function(e){return 11*Math.floor(e/2)+e%2*6},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(e){let t;for(t=0;t+2<=this.data.length;t+=2){let n=r.indexOf(this.data[t])*45;n+=r.indexOf(this.data[t+1]),e.put(n,11)}this.data.length%2&&e.put(r.indexOf(this.data[t]),6)},t.exports=i})),O=s(((e,t)=>{var n=T();function r(e){this.mode=n.BYTE,typeof e==`string`?this.data=new TextEncoder().encode(e):this.data=new Uint8Array(e)}r.getBitsLength=function(e){return e*8},r.prototype.getLength=function(){return this.data.length},r.prototype.getBitsLength=function(){return r.getBitsLength(this.data.length)},r.prototype.write=function(e){for(let t=0,n=this.data.length;t<n;t++)e.put(this.data[t],8)},t.exports=r})),k=s(((e,t)=>{var n=T(),r=d();function i(e){this.mode=n.KANJI,this.data=e}i.getBitsLength=function(e){return e*13},i.prototype.getLength=function(){return this.data.length},i.prototype.getBitsLength=function(){return i.getBitsLength(this.data.length)},i.prototype.write=function(e){let t;for(t=0;t<this.data.length;t++){let n=r.toSJIS(this.data[t]);if(n>=33088&&n<=40956)n-=33088;else if(n>=57408&&n<=60351)n-=49472;else throw Error(`Invalid SJIS character: `+this.data[t]+`
Make sure your charset is UTF-8`);n=(n>>>8&255)*192+(n&255),e.put(n,13)}},t.exports=i})),A=s(((e,t)=>{var n={single_source_shortest_paths:function(e,t,r){var i={},a={};a[t]=0;var o=n.PriorityQueue.make();o.push(t,0);for(var s,c,l,u,d,f,p,m,h;!o.empty();)for(l in s=o.pop(),c=s.value,u=s.cost,d=e[c]||{},d)d.hasOwnProperty(l)&&(f=d[l],p=u+f,m=a[l],h=a[l]===void 0,(h||m>p)&&(a[l]=p,o.push(l,p),i[l]=c));if(r!==void 0&&a[r]===void 0){var g=[`Could not find a path from `,t,` to `,r,`.`].join(``);throw Error(g)}return i},extract_shortest_path_from_predecessor_list:function(e,t){for(var n=[],r=t;r;)n.push(r),e[r],r=e[r];return n.reverse(),n},find_path:function(e,t,r){var i=n.single_source_shortest_paths(e,t,r);return n.extract_shortest_path_from_predecessor_list(i,r)},PriorityQueue:{make:function(e){var t=n.PriorityQueue,r={},i;for(i in e||={},t)t.hasOwnProperty(i)&&(r[i]=t[i]);return r.queue=[],r.sorter=e.sorter||t.default_sorter,r},default_sorter:function(e,t){return e.cost-t.cost},push:function(e,t){var n={value:e,cost:t};this.queue.push(n),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};t!==void 0&&(t.exports=n)})),ne=s((e=>{var t=T(),n=E(),r=D(),i=O(),a=k(),o=w(),s=d(),c=A();function l(e){return unescape(encodeURIComponent(e)).length}function u(e,t,n){let r=[],i;for(;(i=e.exec(n))!==null;)r.push({data:i[0],index:i.index,mode:t,length:i[0].length});return r}function f(e){let n=u(o.NUMERIC,t.NUMERIC,e),r=u(o.ALPHANUMERIC,t.ALPHANUMERIC,e),i,a;return s.isKanjiModeEnabled()?(i=u(o.BYTE,t.BYTE,e),a=u(o.KANJI,t.KANJI,e)):(i=u(o.BYTE_KANJI,t.BYTE,e),a=[]),n.concat(r,i,a).sort(function(e,t){return e.index-t.index}).map(function(e){return{data:e.data,mode:e.mode,length:e.length}})}function p(e,o){switch(o){case t.NUMERIC:return n.getBitsLength(e);case t.ALPHANUMERIC:return r.getBitsLength(e);case t.KANJI:return a.getBitsLength(e);case t.BYTE:return i.getBitsLength(e)}}function m(e){return e.reduce(function(e,t){let n=e.length-1>=0?e[e.length-1]:null;return n&&n.mode===t.mode?(e[e.length-1].data+=t.data,e):(e.push(t),e)},[])}function h(e){let n=[];for(let r=0;r<e.length;r++){let i=e[r];switch(i.mode){case t.NUMERIC:n.push([i,{data:i.data,mode:t.ALPHANUMERIC,length:i.length},{data:i.data,mode:t.BYTE,length:i.length}]);break;case t.ALPHANUMERIC:n.push([i,{data:i.data,mode:t.BYTE,length:i.length}]);break;case t.KANJI:n.push([i,{data:i.data,mode:t.BYTE,length:l(i.data)}]);break;case t.BYTE:n.push([{data:i.data,mode:t.BYTE,length:l(i.data)}])}}return n}function g(e,n){let r={},i={start:{}},a=[`start`];for(let o=0;o<e.length;o++){let s=e[o],c=[];for(let e=0;e<s.length;e++){let l=s[e],u=``+o+e;c.push(u),r[u]={node:l,lastCount:0},i[u]={};for(let e=0;e<a.length;e++){let o=a[e];r[o]&&r[o].node.mode===l.mode?(i[o][u]=p(r[o].lastCount+l.length,l.mode)-p(r[o].lastCount,l.mode),r[o].lastCount+=l.length):(r[o]&&(r[o].lastCount=l.length),i[o][u]=p(l.length,l.mode)+4+t.getCharCountIndicator(l.mode,n))}}a=c}for(let e=0;e<a.length;e++)i[a[e]].end=0;return{map:i,table:r}}function v(e,o){let c,l=t.getBestModeForData(e);if(c=t.from(o,l),c!==t.BYTE&&c.bit<l.bit)throw Error(`"`+e+`" cannot be encoded with mode `+t.toString(c)+`.
 Suggested mode is: `+t.toString(l));switch(c===t.KANJI&&!s.isKanjiModeEnabled()&&(c=t.BYTE),c){case t.NUMERIC:return new n(e);case t.ALPHANUMERIC:return new r(e);case t.KANJI:return new a(e);case t.BYTE:return new i(e)}}e.fromArray=function(e){return e.reduce(function(e,t){return typeof t==`string`?e.push(v(t,null)):t.data&&e.push(v(t.data,t.mode)),e},[])},e.fromString=function(t,n){let r=g(h(f(t,s.isKanjiModeEnabled())),n),i=c.find_path(r.map,`start`,`end`),a=[];for(let e=1;e<i.length-1;e++)a.push(r.table[i[e]].node);return e.fromArray(m(a))},e.rawSplit=function(t){return e.fromArray(f(t,s.isKanjiModeEnabled()))}})),re=s((e=>{var t=d(),n=f(),r=p(),i=m(),a=h(),o=g(),s=v(),c=y(),l=S(),u=ee(),b=te(),x=T(),C=ne();function w(e,t){let n=e.size,r=o.getPositions(t);for(let t=0;t<r.length;t++){let i=r[t][0],a=r[t][1];for(let t=-1;t<=7;t++)if(!(i+t<=-1||n<=i+t))for(let r=-1;r<=7;r++)a+r<=-1||n<=a+r||(t>=0&&t<=6&&(r===0||r===6)||r>=0&&r<=6&&(t===0||t===6)||t>=2&&t<=4&&r>=2&&r<=4?e.set(i+t,a+r,!0,!0):e.set(i+t,a+r,!1,!0))}}function E(e){let t=e.size;for(let n=8;n<t-8;n++){let t=n%2==0;e.set(n,6,t,!0),e.set(6,n,t,!0)}}function D(e,t){let n=a.getPositions(t);for(let t=0;t<n.length;t++){let r=n[t][0],i=n[t][1];for(let t=-2;t<=2;t++)for(let n=-2;n<=2;n++)t===-2||t===2||n===-2||n===2||t===0&&n===0?e.set(r+t,i+n,!0,!0):e.set(r+t,i+n,!1,!0)}}function O(e,t){let n=e.size,r=u.getEncodedBits(t),i,a,o;for(let t=0;t<18;t++)i=Math.floor(t/3),a=t%3+n-8-3,o=(r>>t&1)==1,e.set(i,a,o,!0),e.set(a,i,o,!0)}function k(e,t,n){let r=e.size,i=b.getEncodedBits(t,n),a,o;for(a=0;a<15;a++)o=(i>>a&1)==1,a<6?e.set(a,8,o,!0):a<8?e.set(a+1,8,o,!0):e.set(r-15+a,8,o,!0),a<8?e.set(8,r-a-1,o,!0):a<9?e.set(8,15-a-1+1,o,!0):e.set(8,15-a-1,o,!0);e.set(r-8,8,1,!0)}function A(e,t){let n=e.size,r=-1,i=n-1,a=7,o=0;for(let s=n-1;s>0;s-=2)for(s===6&&s--;;){for(let n=0;n<2;n++)if(!e.isReserved(i,s-n)){let r=!1;o<t.length&&(r=(t[o]>>>a&1)==1),e.set(i,s-n,r),a--,a===-1&&(o++,a=7)}if(i+=r,i<0||n<=i){i-=r,r=-r;break}}}function re(e,n,i){let a=new r;i.forEach(function(t){a.put(t.mode.bit,4),a.put(t.getLength(),x.getCharCountIndicator(t.mode,e)),t.write(a)});let o=(t.getSymbolTotalCodewords(e)-c.getTotalCodewordsCount(e,n))*8;for(a.getLengthInBits()+4<=o&&a.put(0,4);a.getLengthInBits()%8!=0;)a.putBit(0);let s=(o-a.getLengthInBits())/8;for(let e=0;e<s;e++)a.put(e%2?17:236,8);return j(a,e,n)}function j(e,n,r){let i=t.getSymbolTotalCodewords(n),a=i-c.getTotalCodewordsCount(n,r),o=c.getBlocksCount(n,r),s=o-i%o,u=Math.floor(i/o),d=Math.floor(a/o),f=d+1,p=u-d,m=new l(p),h=0,g=Array(o),v=Array(o),y=0,b=new Uint8Array(e.buffer);for(let e=0;e<o;e++){let t=e<s?d:f;g[e]=b.slice(h,h+t),v[e]=m.encode(g[e]),h+=t,y=Math.max(y,t)}let x=new Uint8Array(i),S=0,C,w;for(C=0;C<y;C++)for(w=0;w<o;w++)C<g[w].length&&(x[S++]=g[w][C]);for(C=0;C<p;C++)for(w=0;w<o;w++)x[S++]=v[w][C];return x}function M(e,n,r,a){let o;if(Array.isArray(e))o=C.fromArray(e);else if(typeof e==`string`){let t=n;if(!t){let n=C.rawSplit(e);t=u.getBestVersionForData(n,r)}o=C.fromString(e,t||40)}else throw Error(`Invalid data`);let c=u.getBestVersionForData(o,r);if(!c)throw Error(`The amount of data is too big to be stored in a QR Code`);if(!n)n=c;else if(n<c)throw Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+c+`.
`);let l=re(n,r,o),d=new i(t.getSymbolSize(n));return w(d,n),E(d),D(d,n),k(d,r,0),n>=7&&O(d,n),A(d,l),isNaN(a)&&(a=s.getBestMask(d,k.bind(null,d,r))),s.applyMask(a,d),k(d,r,a),{modules:d,version:n,errorCorrectionLevel:r,maskPattern:a,segments:o}}e.create=function(e,r){if(e===void 0||e===``)throw Error(`No input text`);let i=n.M,a,o;return r!==void 0&&(i=n.from(r.errorCorrectionLevel,n.M),a=u.from(r.version),o=s.from(r.maskPattern),r.toSJISFunc&&t.setToSJISFunction(r.toSJISFunc)),M(e,a,i,o)}})),j=s((e=>{function t(e){if(typeof e==`number`&&(e=e.toString()),typeof e!=`string`)throw Error(`Color should be defined as hex string`);let t=e.slice().replace(`#`,``).split(``);if(t.length<3||t.length===5||t.length>8)throw Error(`Invalid hex color: `+e);(t.length===3||t.length===4)&&(t=Array.prototype.concat.apply([],t.map(function(e){return[e,e]}))),t.length===6&&t.push(`F`,`F`);let n=parseInt(t.join(``),16);return{r:n>>24&255,g:n>>16&255,b:n>>8&255,a:n&255,hex:`#`+t.slice(0,6).join(``)}}e.getOptions=function(e){e||={},e.color||={};let n=e.margin===void 0||e.margin===null||e.margin<0?4:e.margin,r=e.width&&e.width>=21?e.width:void 0,i=e.scale||4;return{width:r,scale:r?4:i,margin:n,color:{dark:t(e.color.dark||`#000000ff`),light:t(e.color.light||`#ffffffff`)},type:e.type,rendererOpts:e.rendererOpts||{}}},e.getScale=function(e,t){return t.width&&t.width>=e+t.margin*2?t.width/(e+t.margin*2):t.scale},e.getImageWidth=function(t,n){let r=e.getScale(t,n);return Math.floor((t+n.margin*2)*r)},e.qrToImageData=function(t,n,r){let i=n.modules.size,a=n.modules.data,o=e.getScale(i,r),s=Math.floor((i+r.margin*2)*o),c=r.margin*o,l=[r.color.light,r.color.dark];for(let e=0;e<s;e++)for(let n=0;n<s;n++){let u=(e*s+n)*4,d=r.color.light;if(e>=c&&n>=c&&e<s-c&&n<s-c){let t=Math.floor((e-c)/o),r=Math.floor((n-c)/o);d=l[+!!a[t*i+r]]}t[u++]=d.r,t[u++]=d.g,t[u++]=d.b,t[u]=d.a}}})),M=s((e=>{var t=j();function n(e,t,n){e.clearRect(0,0,t.width,t.height),t.style||={},t.height=n,t.width=n,t.style.height=n+`px`,t.style.width=n+`px`}function r(){try{return document.createElement(`canvas`)}catch{throw Error(`You need to specify a canvas element`)}}e.render=function(e,i,a){let o=a,s=i;o===void 0&&(!i||!i.getContext)&&(o=i,i=void 0),i||(s=r()),o=t.getOptions(o);let c=t.getImageWidth(e.modules.size,o),l=s.getContext(`2d`),u=l.createImageData(c,c);return t.qrToImageData(u.data,e,o),n(l,s,c),l.putImageData(u,0,0),s},e.renderToDataURL=function(t,n,r){let i=r;i===void 0&&(!n||!n.getContext)&&(i=n,n=void 0),i||={};let a=e.render(t,n,i),o=i.type||`image/png`,s=i.rendererOpts||{};return a.toDataURL(o,s.quality)}})),ie=s((e=>{var t=j();function n(e,t){let n=e.a/255,r=t+`="`+e.hex+`"`;return n<1?r+` `+t+`-opacity="`+n.toFixed(2).slice(1)+`"`:r}function r(e,t,n){let r=e+t;return n!==void 0&&(r+=` `+n),r}function i(e,t,n){let i=``,a=0,o=!1,s=0;for(let c=0;c<e.length;c++){let l=Math.floor(c%t),u=Math.floor(c/t);!l&&!o&&(o=!0),e[c]?(s++,c>0&&l>0&&e[c-1]||(i+=o?r(`M`,l+n,.5+u+n):r(`m`,a,0),a=0,o=!1),l+1<t&&e[c+1]||(i+=r(`h`,s),s=0)):a++}return i}e.render=function(e,r,a){let o=t.getOptions(r),s=e.modules.size,c=e.modules.data,l=s+o.margin*2,u=o.color.light.a?`<path `+n(o.color.light,`fill`)+` d="M0 0h`+l+`v`+l+`H0z"/>`:``,d=`<path `+n(o.color.dark,`stroke`)+` d="`+i(c,s,o.margin)+`"/>`,f=`viewBox="0 0 `+l+` `+l+`"`,p=`<svg xmlns="http://www.w3.org/2000/svg" `+(o.width?`width="`+o.width+`" height="`+o.width+`" `:``)+f+` shape-rendering="crispEdges">`+u+d+`</svg>
`;return typeof a==`function`&&a(null,p),p}})),ae=l(s((e=>{var t=u(),n=re(),r=M(),i=ie();function a(e,r,i,a,o){let s=[].slice.call(arguments,1),c=s.length,l=typeof s[c-1]==`function`;if(!l&&!t())throw Error(`Callback required as last argument`);if(l){if(c<2)throw Error(`Too few arguments provided`);c===2?(o=i,i=r,r=a=void 0):c===3&&(r.getContext&&o===void 0?(o=a,a=void 0):(o=a,a=i,i=r,r=void 0))}else{if(c<1)throw Error(`Too few arguments provided`);return c===1?(i=r,r=a=void 0):c===2&&!r.getContext&&(a=i,i=r,r=void 0),new Promise(function(t,o){try{t(e(n.create(i,a),r,a))}catch(e){o(e)}})}try{let t=n.create(i,a);o(null,e(t,r,a))}catch(e){o(e)}}e.create=n.create,e.toCanvas=a.bind(null,r.render),e.toDataURL=a.bind(null,r.renderToDataURL),e.toString=a.bind(null,function(e,t,n){return i.render(e,n)})}))(),1);console.log(`[uid.one] Content script loaded on`,window.location.hostname);var N={vnId:/\b\d{9}(\d{3})?\b/g,creditCard:/\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b/g,bankAccount:/\b\d{9,16}\b/g,emailBulk:/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g,phone:/(?:\+\d{1,4}[\s.-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{2,6}\b|(?:\+\d{1,4}[\s.-]?)?\d{7,14}\b/g,apiKey:/\b(sk-|pk-|api_key=|secret=)[A-Za-z0-9]{20,}\b/gi,jwt:/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,privateKey:/-----BEGIN (RSA |EC |)PRIVATE KEY-----/};function P(e){let t=[];for(let[n,r]of Object.entries(N)){let i=e.match(r);i&&i.length>0&&t.push({type:n,count:i.length,sample:se(i[0])})}if(t.length===0)return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``};let n=oe(t);return{blocked:n===`critical`||n===`high`,riskLevel:n,findings:t,recommendation:ce(t,n)}}function oe(e){let t=e.map(e=>e.type);return t.includes(`privateKey`)||t.includes(`jwt`)?`critical`:t.some(e=>[`creditCard`,`apiKey`,`vnId`].includes(e))?`high`:t.some(e=>[`phone`,`emailBulk`].includes(e))?`medium`:`low`}function se(e){return e.length<=8?`••••••••`:e.slice(0,4)+`••••`+e.slice(-4)}function ce(e,t){return t===`critical`?`This content contains credentials or tokens. Sending it could compromise your accounts.`:t===`high`?`This content may contain sensitive personal or financial data.`:`Review this content before sending.`}async function F(e){return new Promise(t=>{let n=document.createElement(`div`);n.style.cssText=`
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.6);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    `;let r={file_upload:`File upload`,clipboard_paste:`Clipboard paste`,form_submit:`Form submission`,drag_drop:`File drop`}[e.context];n.innerHTML=`
      <div style="
        background: white;
        border-radius: 12px;
        padding: 24px;
        max-width: 480px;
        width: 90%;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      ">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <div style="
            width:40px;height:40px;border-radius:8px;
            background:${{critical:`#dc2626`,high:`#ea580c`,medium:`#d97706`,low:`#2563eb`}[e.result.riskLevel]};display:flex;
            align-items:center;justify-content:center;
            color:white;font-size:20px;flex-shrink:0
          ">⚠</div>
          <div>
            <div style="font-weight:600;font-size:15px;color:#111827;">
              Sensitive data detected
            </div>
            <div style="color:#6b7280;font-size:13px">
              ${r}${e.filename?` — ${e.filename}`:``}
            </div>
          </div>
        </div>

        <p style="color:#374151;font-size:14px;line-height:1.5;margin:0 0 16px">
          ${e.result.recommendation}
        </p>

        <div style="
          background:#f9fafb;border-radius:8px;
          padding:12px;margin-bottom:20px;
          border:1px solid #e5e7eb
        ">
          ${e.result.findings.map(e=>`
            <div style="font-size:13px;color:#374151;padding:2px 0">
              <strong>${e.type}</strong>
              ${e.count>1?`× ${e.count}`:``}
              — <code style="color:#dc2626">${e.sample}</code>
            </div>
          `).join(``)}
        </div>

        <div style="display:flex;gap:8px;justify-content:flex-end">
          ${e.onAllow?`
            <button id="uid-dlp-allow" style="
              background:none;border:1px solid #d1d5db;
              color:#374151;padding:8px 16px;border-radius:6px;
              cursor:pointer;font-size:14px
            ">Send anyway</button>
          `:``}
          <button id="uid-dlp-block" style="
            background:#111827;color:white;
            border:none;padding:8px 20px;border-radius:6px;
            cursor:pointer;font-size:14px;font-weight:500
          ">Don't send</button>
        </div>
      </div>
    `,document.body.appendChild(n),n.querySelector(`#uid-dlp-block`)?.addEventListener(`click`,()=>{n.remove(),t()}),n.querySelector(`#uid-dlp-allow`)?.addEventListener(`click`,()=>{n.remove(),e.onAllow?.(),t()})})}function le(e){let t=new DataView(e);if(t.byteLength<4||t.getUint16(0)!==65496)return e;let n=2,r=t.byteLength,i=[],a=0;for(;n<r-1;){let r=t.getUint16(n);if(r===65505){let r=t.getUint16(n+2);n>a&&i.push(e.slice(a,n)),a=n+2+r,n=a}else if(r>=65488&&r<=65497)n+=2;else{let e=t.getUint16(n+2);n+=2+e}}if(a<r&&i.push(e.slice(a,r)),i.length===0)return e;let o=i.reduce((e,t)=>e+t.byteLength,0),s=new Uint8Array(o),c=0;for(let e of i)s.set(new Uint8Array(e),c),c+=e.byteLength;return s.buffer}async function I(e){if(e.type===`image/jpeg`||e.name.toLowerCase().endsWith(`.jpg`)||e.name.toLowerCase().endsWith(`.jpeg`))try{let t=await e.arrayBuffer(),n=le(t);if(n.byteLength!==t.byteLength){console.log(`[uid.one] CookieGuard / Privacy stripped EXIF metadata from: ${e.name}`);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`exif_stripped`})}catch{}return new File([n],e.name,{type:e.type,lastModified:Date.now()})}}catch(e){console.warn(`[uid.one] Failed to strip EXIF from image:`,e)}return e}var L=class{observer=null;init(){chrome.storage.local.get(`settings_exif_stripper`).then(e=>{if(e.settings_exif_stripper===!1){console.log(`[uid.one] FileUploadInterceptor (EXIF Stripper) is disabled.`);return}this.scanFileInputs(document.querySelectorAll(`input[type="file"]`)),this.observer=new MutationObserver(e=>{for(let t of e)t.addedNodes.forEach(e=>{if(e instanceof Element){let t=e.querySelectorAll(`input[type="file"]`);this.scanFileInputs(t)}})}),this.observer.observe(document.body,{childList:!0,subtree:!0}),document.addEventListener(`drop`,this.handleDrop.bind(this),!0)})}scanFileInputs(e){e.forEach(e=>{e.getAttribute(`data-uid-scanned`)||(e.setAttribute(`data-uid-scanned`,`true`),e.addEventListener(`change`,async e=>{let t=e.target;if(t.getAttribute(`data-uid-metadata-cleaning`)===`true`)return;if(t.getAttribute(`data-uid-allowed`)===`true`){t.removeAttribute(`data-uid-allowed`);return}let n=t.files;if(!(!n||n.length===0)){t.setAttribute(`data-uid-metadata-cleaning`,`true`);try{let e=[],r=!1;for(let t=0;t<n.length;t++){let i=n[t],a=await I(i);a!==i&&(r=!0),e.push(a)}if(r){let n=new DataTransfer;e.forEach(e=>n.items.add(e)),t.files=n.files,t.dispatchEvent(new Event(`change`,{bubbles:!0}));return}}finally{t.removeAttribute(`data-uid-metadata-cleaning`)}await this.handleFiles(Array.from(t.files||[]),t)}}))})}async handleFiles(e,t){for(let n of e){let e=await this.scanFile(n);e.blocked&&(t.value=``,await F({context:`file_upload`,filename:n.name,result:e,onAllow:()=>{t.setAttribute(`data-uid-allowed`,`true`)}}))}}async scanFile(e){if(!([`text/`,`application/json`,`application/xml`,`application/csv`,`application/sql`].some(t=>e.type.startsWith(t))||e.name.endsWith(`.txt`)||e.name.endsWith(`.csv`)||e.name.endsWith(`.json`)||e.name.endsWith(`.sql`)||e.name.endsWith(`.env`)||e.name.endsWith(`.key`)||e.name.endsWith(`.pem`)))return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``};if(e.size>1024*1024)return{blocked:!1,riskLevel:`medium`,findings:[{type:`large_file`,count:1,sample:`${(e.size/1024/1024).toFixed(1)}MB`}],recommendation:`Large file — please verify it does not contain sensitive data.`};try{return P(await e.text())}catch{return{blocked:!1,riskLevel:`low`,findings:[],recommendation:``}}}async handleDrop(e){if(!e.dataTransfer?.files?.length||e.defaultPrevented)return;let t=e.target;if(e.dataTransfer.types.includes(`Files`)&&t.getAttribute(`data-uid-dropped-clean`)===`true`){t.removeAttribute(`data-uid-dropped-clean`);return}let n=Array.from(e.dataTransfer.files);for(let t of n){let n=await this.scanFile(t);if(n.blocked){e.preventDefault(),e.stopPropagation(),await F({context:`drag_drop`,filename:t.name,result:n});return}}let r=!1,i=[];for(let e of n){let t=await I(e);t!==e&&(r=!0),i.push(t)}if(r){e.preventDefault(),e.stopPropagation(),t.setAttribute(`data-uid-dropped-clean`,`true`);let n=new DataTransfer;i.forEach(e=>n.items.add(e));let r=new DragEvent(`drop`,{bubbles:!0,cancelable:!0,dataTransfer:n});t.dispatchEvent(r)}}},R=class{isDlpActive=!0;init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{this.isDlpActive=e.settings_otp_shield!==!1}),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.settings_otp_shield&&(this.isDlpActive=e.settings_otp_shield.newValue!==!1)}),document.addEventListener(`paste`,this.handlePaste.bind(this),!0),document.addEventListener(`copy`,this.handleCopy.bind(this),!0)}async handlePaste(e){if(!this.isDlpActive)return;let t=e.target;if(t.getAttribute(`data-uid-allowed`)===`true`){t.removeAttribute(`data-uid-allowed`);return}let n=e.clipboardData?.getData(`text/plain`);if(!n)return;let r=P(n);r.riskLevel===`critical`&&(e.preventDefault(),e.stopPropagation(),await F({context:`clipboard_paste`,result:r,onAllow:()=>{if(t.setAttribute(`data-uid-allowed`,`true`),t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){let e=t.selectionStart||0,r=t.selectionEnd||0,i=t.value;t.value=i.slice(0,e)+n+i.slice(r),t.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}))}handleCopy(e){if(!this.isDlpActive)return;let t=window.getSelection()?.toString();if(!t)return;let n=P(t),r=0,i=0,a=[],o=[`emailBulk`,`phone`,`creditCard`,`apiKey`,`vnId`,`privateKey`,`jwt`,`bankAccount`],s=[];for(let e of n.findings)if(o.includes(e.type)){a.push(e.type);let n=N[e.type];if(n){n.lastIndex=0;let r;if(n.global)for(;(r=n.exec(t))!==null;)r[0]&&s.push({start:r.index,end:r.index+r[0].length,type:e.type});else r=n.exec(t),r&&r[0]&&s.push({start:r.index,end:r.index+r[0].length,type:e.type})}}s.sort((e,t)=>e.start-t.start);let c=[];for(let e of s)if(c.length===0)c.push(e);else{let t=c[c.length-1];e.start<t.end?t.end=Math.max(t.end,e.end):c.push(e)}r=c.length;let l={};for(let e of c)l[e.type]=(l[e.type]||0)+1;for(let e of Object.values(l))e>i&&(i=e);r>0&&(r>=3||i>=3?(e.preventDefault(),e.clipboardData&&e.clipboardData.setData(`text/plain`,`[SECURE DATA BLOCKED BY UID.ONE]`),chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:`Bulk copying of sensitive customer data (email/phone/credentials) is disabled.`}),chrome.runtime.sendMessage({type:`AUDIT_COPY`,domain:window.location.hostname,sensitive_type:a.join(`,`),sample:`[BULK COPY BLOCKED]`,count:r,blocked:!0})):chrome.runtime.sendMessage({type:`AUDIT_COPY`,domain:window.location.hostname,sensitive_type:a.join(`,`),sample:t.slice(0,50)+(t.length>50?`...`:``),count:r,blocked:!1}))}},z=class{init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{e.settings_otp_shield!==!1&&(document.addEventListener(`submit`,this.handleSubmit.bind(this),!0),document.addEventListener(`click`,e=>{let t=e.target.closest(`button, input[type="submit"]`);if(t&&(t.getAttribute(`type`)===`submit`||/submit|login|verify|confirm|pay/i.test(t.textContent||``)||/submit|login|verify|confirm|pay/i.test(t.value||``))){let e=t.closest(`form`);if(e)this.wipeSensitiveInputs(e);else{let e=t.parentElement;e&&e.querySelectorAll(`input[type="password"], input[name*="otp" i], input[name*="code" i], input[autocomplete*="one-time-code" i], input[name*="card" i], input[name*="cvv" i], input[name*="cvc" i]`).forEach(e=>{setTimeout(()=>{e.value&&(e.value=``,e.dispatchEvent(new Event(`input`,{bubbles:!0})))},300)})}}},!0))})}async handleSubmit(e){let t=e.target;if(t.getAttribute(`data-uid-owned`))return;if(t.getAttribute(`data-uid-allowed`)===`true`){this.wipeSensitiveInputs(t);return}let n=this.extractFormContent(t);if(!n){this.wipeSensitiveInputs(t);return}let r=P(n);r.blocked?(e.preventDefault(),e.stopPropagation(),await F({context:`form_submit`,result:r,onAllow:()=>{t.setAttribute(`data-uid-allowed`,`true`),t.requestSubmit()}})):this.wipeSensitiveInputs(t)}wipeSensitiveInputs(e){e.querySelectorAll(`input[type="password"], input[name*="otp" i], input[name*="code" i], input[autocomplete*="one-time-code" i], input[name*="card" i], input[name*="cvv" i], input[name*="cvc" i]`).forEach(e=>{setTimeout(()=>{if(e.value){console.log(`[uid.one] CookieGuard / Privacy wiped sensitive value from input: ${e.name||e.id}`),e.value=``,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}));try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`otp_cleared`})}catch{}}},300)});try{navigator.clipboard.readText().then(e=>{let t=P(e);(t.riskLevel===`critical`||t.riskLevel===`high`)&&navigator.clipboard.writeText(``).then(()=>{console.log(`[uid.one] CookieGuard / Privacy wiped sensitive content from clipboard cache.`);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`otp_cleared`})}catch{}})}).catch(()=>{})}catch{}}extractFormContent(e){let t=new FormData(e),n=[];return t.forEach((e,t)=>{e instanceof File||t.toLowerCase().includes(`password`)||t.toLowerCase().includes(`token`)||n.push(`${t}=${e}`)}),n.join(`
`)}},B=class{init(){console.log(`[uid.one] Initializing ScreenshotProtector...`);let e=document.createElement(`style`);e.textContent=`
      @media print {
        body {
          display: none !important;
        }
        html {
          display: none !important;
        }
      }
      .uid-blur-active {
        filter: blur(25px) !important;
        transition: filter 0.1s ease-in-out !important;
      }
      
      /* Auto-blur sensitive inputs when not active to prevent screenshot leakage */
      input[type="password"]:not(:focus):not(:hover),
      input[name*="otp" i]:not(:focus):not(:hover),
      input[name*="code" i]:not(:focus):not(:hover),
      input[autocomplete*="one-time-code" i]:not(:focus):not(:hover),
      input[name*="card" i]:not(:focus):not(:hover),
      input[name*="cvv" i]:not(:focus):not(:hover),
      input[name*="cvc" i]:not(:focus):not(:hover) {
        filter: blur(5px) !important;
        transition: filter 0.15s ease-in-out !important;
      }
    `;let t=document.head||document.documentElement;t&&t.appendChild(e),document.addEventListener(`keydown`,e=>{let t=e.key===`PrintScreen`,n=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`p`,r=e.metaKey&&e.shiftKey&&e.key.toLowerCase()===`s`,i=e.metaKey&&e.shiftKey&&(e.key===`3`||e.key===`4`),a=e.key===`F12`,o=(e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key.toLowerCase()===`i`||e.key.toLowerCase()===`c`||e.key.toLowerCase()===`j`),s=(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()===`u`;if(t||n||r||i){console.log(`[uid.one] Keydown screenshot/print event detected:`,e.key);let r=document.body||document.documentElement;r&&r.classList.add(`uid-blur-active`),(t||n)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Printing and screen capturing are disabled by UID.ONE.`)),setTimeout(()=>{if(document.hasFocus()){let e=document.body||document.documentElement;e&&e.classList.remove(`uid-blur-active`)}},2e3)}else if(a||o||s){let t=window.location.hostname,n=t===`uid.one`||t.endsWith(`.uid.one`),r=document.querySelector(`input[type="password"]`)!==null;(n||r)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Developer tools are disabled on secure pages.`))}},!0),document.addEventListener(`contextmenu`,e=>{let t=e.target,n=window.location.hostname,r=n===`uid.one`||n.endsWith(`.uid.one`),i=t.closest(`input[type="password"]`);(r||i)&&(e.preventDefault(),e.stopPropagation(),this.showWarningToast(`Context menu options are disabled on secure domains/inputs.`))},!0),document.addEventListener(`visibilitychange`,()=>{let e=document.body||document.documentElement;document.hidden?(console.log(`[uid.one] Visibility hidden, applying blur filter`),e&&e.classList.add(`uid-blur-active`)):(console.log(`[uid.one] Visibility visible, removing blur filter`),e&&e.classList.remove(`uid-blur-active`))}),this.injectWatermark(),this.initDevToolsDetector()}initDevToolsDetector(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;if(!t&&!n)return;console.log(`[uid.one] Enabling DevTools console getter detector...`);let r=new Image;Object.defineProperty(r,`id`,{get:()=>{console.log(`[uid.one] DevTools console evaluated target object, triggering blur`);let e=document.body||document.documentElement;return e&&e.classList.add(`uid-blur-active`),chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:`Developer tools detected. Content has been secured.`}),`uid-secure`}}),setInterval(()=>{console.log(r)},1e3)}injectWatermark(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;if(!t&&!n||document.getElementById(`uid-watermark-overlay`))return;console.log(`[uid.one] Generating and injecting dynamic watermark overlay`);let r=document.createElement(`div`);r.id=`uid-watermark-overlay`,r.style.cssText=`
      position: fixed;
      inset: 0;
      z-index: 2147483640;
      pointer-events: none;
      opacity: 0.03;
      display: flex;
      flex-wrap: wrap;
      align-content: space-around;
      justify-content: space-around;
      overflow: hidden;
      user-select: none;
    `;let i=`UID.ONE | SECURE SESSION | ${navigator.userAgent.includes(`Mac`)?`macOS`:`Windows/Linux`}`;for(let e=0;e<20;e++){let e=document.createElement(`div`);e.style.cssText=`
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 15px;
        font-weight: 600;
        transform: rotate(-25deg);
        white-space: nowrap;
        margin: 50px;
        color: #000000;
      `,e.textContent=i,r.appendChild(e)}let a=document.body||document.documentElement;a&&a.appendChild(r)}showWarningToast(e){chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Security Alert`,message:e})}},V=class{SUSPICIOUS_PATTERNS=[/uid\.one\./i,/uid-one/i,/uidone/i,/uid_one/i];init(){this.checkCurrentPage(),this.monitorFormSubmissions()}checkCurrentPage(){let e=window.location.hostname,t=this.isLegitimateUIDDomain(e);this.isSuspiciousUIDDomain(e)&&!t&&this.showPhishingWarning(e)}isLegitimateUIDDomain(e){return[`uid.one`,`auth.uid.one`,`api.uid.one`].some(t=>e===t||e.endsWith(`.${t}`)||e===`localhost`||e===`127.0.0.1`)}isSuspiciousUIDDomain(e){return this.SUSPICIOUS_PATTERNS.some(t=>t.test(e))}showPhishingWarning(e){let t=document.createElement(`div`);t.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 2147483647;
      background: #dc2626;
      color: white;
      padding: 12px 16px;
      font-family: sans-serif;
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    `,t.innerHTML=`
      <span>
        ⚠ <strong>Phishing warning:</strong>
        This page (${e}) may be impersonating UID.one.
        Do not enter your credentials.
      </span>
      <button id="uid-phish-dismiss"
        style="background:none;border:1px solid white;color:white;
               padding:4px 12px;border-radius:4px;cursor:pointer">
        Dismiss
      </button>
    `,document.body.prepend(t),t.querySelector(`#uid-phish-dismiss`)?.addEventListener(`click`,()=>t.remove())}monitorFormSubmissions(){document.addEventListener(`submit`,e=>{let t=e.target;if(!t.querySelector(`[data-uid-autofill]`))return;let n=new URL(t.action||window.location.href);n.protocol===`https:`||n.hostname===`localhost`||n.hostname===`127.0.0.1`||(e.preventDefault(),this.showInsecureSubmitWarning(n.hostname))},!0)}showInsecureSubmitWarning(e){chrome.runtime.sendMessage({type:`SHOW_NOTIFICATION`,title:`Insecure Form Blocked`,message:`${e} uses HTTP. Your credentials were not submitted.`})}},H=!1;function U(){try{let e=document.getElementById(`oneuid-handshake-token`)?.getAttribute(`data-token`);e&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:e})}catch{}try{let e=(window.wrappedJSObject||window).localStorage.getItem(`oneuid_access_token`);e&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:e})}catch{}if(!H)try{window.addEventListener(`message`,e=>{if(e.source===window)if(e.data&&e.data.type===`oneuid_session_login`){let t=e.data.token;t&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t})}else e.data&&e.data.type===`oneuid_session_logout`&&chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])}),window.addEventListener(`oneuid_session_login`,e=>{let t=(e.detail&&e.detail.wrappedJSObject?e.detail.wrappedJSObject:e.detail)?.token;t&&chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t})}),window.addEventListener(`oneuid_session_logout`,()=>{chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])});let e=document.getElementById(`oneuid-handshake-token`);e&&new MutationObserver(t=>{for(let n of t)if(n.type===`attributes`&&n.attributeName===`data-token`){let t=e.getAttribute(`data-token`);t?chrome.runtime.sendMessage({type:`SET_SESSION_TOKEN`,token:t}):chrome.storage.local.remove([`oneuid_access_token`,`identity_token`])}}).observe(e,{attributes:!0}),H=!0}catch{}}var W=!1;function G(){if(W)return;if(W=!0,!chrome.runtime?.id){console.warn(`[uid.one] Extension context invalidated. Please refresh the page.`);return}console.log(`[uid.one] Content script initialized on:`,window.location.href);let e=document.createElement(`meta`);e.name=`uid-extension-client-active`,e.content=`true`;let t=document.head||document.documentElement;t&&t.appendChild(e);try{q()}catch(e){console.error(`[uid.one] injectAll failed:`,e)}let n=[{name:`FileUploadInterceptor`,run:()=>new L().init()},{name:`ClipboardInterceptor`,run:()=>new R().init()},{name:`FormInterceptor`,run:()=>new z().init()},{name:`OriginVerifier`,run:()=>new V().init()},{name:`ScreenshotProtector`,run:()=>new B().init()},{name:`ViewportCleaner`,run:()=>new X().init()},{name:`NotificationBlocker`,run:()=>new me().init()},{name:`CookieGuard`,run:()=>new Z().init()},{name:`GPCEnforcer`,run:()=>new he().init()},{name:`TextDLPShield`,run:()=>new ge().init()},{name:`EmailSignatureGuard`,run:()=>new _e().init()},{name:`EmailComposeSigner`,run:()=>new Q().init()},{name:`captureSessionToken`,run:()=>U()}];for(let e of n)try{e.run(),console.log(`[uid.one] Subsystem ${e.name} loaded successfully.`)}catch(t){console.error(`[uid.one] Failed to initialize ${e.name}:`,t)}let r=new MutationObserver(()=>{if(!chrome.runtime?.id){r.disconnect();return}q(),U()});r.observe(document.body,{childList:!0,subtree:!0})}var K=new WeakSet;function q(){let e=document.querySelector(`meta[name="uid-passkey-native"]`);if(e&&e.getAttribute(`content`)===`true`)return;let t=window.location.hostname,n=window.location.protocol===`http:`&&t!==`localhost`&&t!==`127.0.0.1`,r=t===`uid.one`||t.endsWith(`.uid.one`);n||r||document.querySelectorAll(`input[type="password"]`).forEach(e=>{e.disabled||e.readOnly||e.type===`hidden`||e.style.display===`none`||e.style.visibility===`hidden`||e.autocomplete===`new-password`||K.has(e)||(ue(e),K.add(e))})}function ue(e){let t=document.createElement(`div`);t.className=`uid-passkey-wrapper`,t.style.position=`absolute`,t.style.zIndex=`999999`,t.style.cursor=`pointer`,document.body.appendChild(t);let n=window.getComputedStyle(e),r=parseFloat(n.paddingRight)||0;e.style.paddingRight=`${r+28}px`,e.setAttribute(`data-uid-autofill`,`true`);let i=()=>{let n=e.getBoundingClientRect();if(n.width===0||n.height===0||!document.body.contains(e)){t.style.display=`none`;return}t.style.display=`block`,t.style.top=`${n.top+window.scrollY+n.height/2}px`;let i=r+28;t.style.left=`${n.right+window.scrollX-i}px`,t.style.transform=`translateY(-50%)`};i(),window.addEventListener(`resize`,i),window.addEventListener(`scroll`,i),setInterval(i,500);let a=t.attachShadow({mode:`closed`}),o=document.createElement(`div`);o.style.width=`24px`,o.style.height=`24px`,o.style.display=`flex`,o.style.alignItems=`center`,o.style.justifyContent=`center`,o.style.cursor=`pointer`,o.style.color=`#0B1220`,o.style.opacity=`1`,o.style.transition=`color 0.2s ease, transform 0.2s ease, opacity 0.2s ease`,o.innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-fingerprint">
    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
    <path d="M18.9 7a8 8 0 0 1 1.1 5v1a6 6 0 0 0 .8 3" />
    <path d="M8 11a4 4 0 0 1 8 0v1a10 10 0 0 0 2 6" />
    <path d="M12 11v2a14 14 0 0 0 2.5 8" />
    <path d="M8 15a18 18 0 0 0 1.8 6" />
    <path d="M4.9 19a22 22 0 0 1 -.9 -7v-1a8 8 0 0 1 12 -6.95" />
  </svg>`,o.title=chrome.runtime?.id&&chrome.i18n.getMessage(`iconTitle`)||`Login with Passkey`,o.addEventListener(`mouseenter`,()=>{o.style.color=`#1A2233`,o.style.transform=`scale(1.05)`}),o.addEventListener(`mouseleave`,()=>{o.style.color=`#0B1220`,o.style.transform=`scale(1)`});let s=async(e,t)=>{try{if(!chrome.runtime?.id){alert(`Extension context invalidated. Please refresh the page.`);return}let n=window.location.hostname,r=navigator.userAgent.includes(`Mac`)?`Chrome on macOS`:`Chrome Web`;if(!(await new Promise(e=>{chrome.runtime.sendMessage({type:`CHECK_PAIRING`},e)}))?.isPaired){let i=await new Promise(t=>{chrome.runtime.sendMessage({type:`START_OOB_AUTH`,domain:n,device:r,identifier:e},t)});if(!i?.success)return alert(`Failed to initiate Pairing`);let a=`https://uid.one/qr?challenge=${i.challenge.token}&client_id=uid-extension-client&client_name=Extension`,o=await ae.toDataURL(a,{margin:2,width:200}),c=document.createElement(`div`);c.innerHTML=`
          <div style="position: fixed; inset: 0; background: rgba(2, 8, 23, 0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 9999999;">
            <div id="uid-qr-container" style="background: #ffffff; border-radius: 12px; padding: 24px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; align-items: center; gap: 16px; font-family: system-ui, sans-serif; color: #0f172a; position: relative; min-width: 280px; min-height: 320px; justify-content: center;">
              <button id="close-qr" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
              <h3 style="margin: 0; font-size: 18px; font-weight: 600;">Pair Device</h3>
              <div style="padding: 8px; border: 1px solid #e2e8f0; border-radius: 8px;">
                <img src="${o}" alt="QR Code" style="width: 200px; height: 200px; display: block;" />
              </div>
              <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center; max-width: 220px; line-height: 1.4;">
                Scan this code with the UID.ONE App, or <a href="${a}" target="_blank" style="color: #0ea5e9; text-decoration: underline; font-weight: 500; cursor: pointer;">approve on this browser</a>.
              </p>
            </div>
          </div>
        `,document.body.appendChild(c),c.querySelector(`#close-qr`)?.addEventListener(`click`,()=>c.remove());let l=setInterval(async()=>{let n=await new Promise(e=>{chrome.runtime.sendMessage({type:`POLL_OOB_STATUS`,token:i.challenge.token},e)});if(n?.success&&n.status===`APPROVED`){clearInterval(l),await new Promise(e=>chrome.runtime.sendMessage({type:`SAVE_PAIRING`,token:i.challenge.token},e));let n=c.querySelector(`#uid-qr-container`);n&&(n.innerHTML=`
                <div style="display: flex; flex-direction: column; align-items: center; gap: 16px;">
                  <div style="width: 64px; height: 64px; border-radius: 50%; background: #dcfce7; display: flex; align-items: center; justify-content: center; color: #16a34a;">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  </div>
                  <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #16a34a;">Paired Successfully!</h3>
                  <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">You can now use push notifications.</p>
                </div>
              `,setTimeout(()=>{c.remove(),s(e,t)},2e3))}},2e3);return}let i=await new Promise(e=>{chrome.runtime.sendMessage({type:`PUSH_REQUEST`,domain:n},e)});if(!i?.success){alert(`Failed to request push: `+(i?.error||`Unknown error`));return}let a=i.data.match_number,o=i.data.token,c=document.createElement(`div`);c.innerHTML=`
        <div style="position: fixed; inset: 0; background: rgba(2, 8, 23, 0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 9999999;">
          <div id="uid-match-container" style="background: #ffffff; border-radius: 12px; padding: 32px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; align-items: center; gap: 16px; font-family: system-ui, sans-serif; color: #0f172a; position: relative; min-width: 300px;">
            <button id="close-match" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
            <h3 style="margin: 0; font-size: 18px; font-weight: 600; text-align: center;">Check your phone</h3>
            <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">Enter the following number in the UID.ONE app to approve this login.</p>
            <div style="font-size: 48px; font-weight: 800; letter-spacing: 8px; color: #0f172a; padding: 16px 32px; background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; margin-top: 8px;">
              ${a}
            </div>
            <div style="display: flex; align-items: center; gap: 8px; margin-top: 16px;">
               <svg class="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="animation: spin 1s linear infinite;"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
               <span style="font-size: 12px; color: #64748b;">Waiting for approval...</span>
            </div>
            <style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>
          </div>
        </div>
      `,document.body.appendChild(c),c.querySelector(`#close-match`)?.addEventListener(`click`,()=>c.remove());let l=`ws://127.0.0.1:8001/ws/challenges/${o}/`,u=new WebSocket(l);u.onmessage=async e=>{try{let n=JSON.parse(e.data);if(n.status===`APPROVED`&&n.encrypted_payload){u.close();let e=await new Promise(e=>{chrome.runtime.sendMessage({type:`DECRYPT_PAYLOAD`,token:o,encrypted_payload:n.encrypted_payload},e)}),r=c.querySelector(`#uid-match-container`);e?.success&&e.decrypted_password?(r&&(r.innerHTML=`
                  <div style="display: flex; flex-direction: column; align-items: center; gap: 16px;">
                    <div style="width: 64px; height: 64px; border-radius: 50%; background: #dcfce7; display: flex; align-items: center; justify-content: center; color: #16a34a;">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                    <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #16a34a;">Approved!</h3>
                    <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center;">Login successful. Auto-filling...</p>
                  </div>
                `),setTimeout(()=>{t.value=e.decrypted_password,t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),c.remove(),setTimeout(()=>{let e=document.querySelector(`button[type="submit"], input[type="submit"]`);e&&e.click()},500)},500)):r&&(r.innerHTML=`
                  <button id="close-match-error" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; cursor: pointer; color: #64748b; font-size: 16px;">✕</button>
                  <div style="display: flex; flex-direction: column; align-items: center; gap: 16px; margin-top: 16px;">
                    <div style="width: 64px; height: 64px; border-radius: 50%; background: #fee2e2; display: flex; align-items: center; justify-content: center; color: #dc2626;">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                    </div>
                    <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: #dc2626;">Failed</h3>
                    <p style="margin: 0; font-size: 14px; color: #64748b; text-align: center; max-width: 220px;">Could not inject password.</p>
                  </div>
                `,r.querySelector(`#close-match-error`)?.addEventListener(`click`,()=>c.remove()))}}catch(e){console.error(`WS parse error`,e)}},u.onerror=e=>{console.error(`WS Error`,e)}}catch(e){console.error(`[uid.one] Error:`,e)}};o.addEventListener(`click`,async t=>{t.preventDefault(),t.stopPropagation();let n=e.closest(`form`),r=``;if(n){let e=n.querySelector(`input[type="text"], input[type="email"], input[name="email"], input[name="username"]`);e&&(r=e.value.trim())}if(!r){alert(chrome.i18n.getMessage(`errorNoUsernameProvided`)||`Please enter your email or username first to use your Passkey.`);return}await s(r,e)}),a.appendChild(o)}var J=null;document.addEventListener(`contextmenu`,e=>{J=e.target}),chrome.runtime.onMessage.addListener((e,t,n)=>{e.action===`START_PDF_SIGNING`?fe(e.url).catch(console.error):e.action===`START_TEXT_SIGNING`&&de(e.text).catch(console.error)});function Y(e,t){console.log(`[uid.one - ${t}] ${e}`)}async function de(e){let t=J;if(!t){Y(`No target element to sign`,`error`);return}let n=e;if(n||=t.innerText||t.value||``,n.replace(/\s/g,``).length===0){alert(chrome.i18n.getMessage(`alertEnterContent`)||`Please enter content before signing.`);return}chrome.runtime.sendMessage({type:`GET_PROFILE`},e=>{if(!e||!e.success){alert(chrome.i18n.getMessage(`alertLinkFirst`)||`Please link your UID.one account before performing digital signature.`);return}let r=e.email;Y(`Signing selected text...`,`info`);let i=new TextEncoder().encode(n);crypto.subtle.digest(`SHA-256`,i).then(e=>{let i=Array.from(new Uint8Array(e)).map(e=>e.toString(16).padStart(2,`0`)).join(``);chrome.runtime.sendMessage({action:`REQUEST_DIGITAL_SIGNATURE`,domain:window.location.hostname,user_agent:navigator.userAgent,identifier:`Text Signature`,metadata:{text_hash:i,text_snippet:n.slice(0,100)}},e=>{e&&e.success?(pe(t,e.signature,r,i),Y(`Signature applied successfully!`,`success`)):Y(`Signing failed or was rejected: `+(e?.error||`Unknown error`),`error`)})})})}async function fe(e){chrome.runtime.sendMessage({type:`GET_PROFILE`},async t=>{if(!t||!t.success){alert(chrome.i18n.getMessage(`alertLinkFirst`)||`Please link your UID.one account before performing digital signature.`);return}Y(`Fetching PDF for signing...`,`info`);let n=await(await fetch(e)).arrayBuffer(),r=await crypto.subtle.digest(`SHA-256`,n),i=Array.from(new Uint8Array(r)).map(e=>e.toString(16).padStart(2,`0`)).join(``);chrome.runtime.sendMessage({action:`REQUEST_DIGITAL_SIGNATURE`,domain:window.location.hostname,user_agent:navigator.userAgent,identifier:`Digital Signature`,metadata:{pdf_hash:i,document_url:e}},e=>{e&&e.success?Y(`PDF signed successfully!`,`success`):Y(`PDF signing failed or was rejected: `+(e?.error||`Unknown error`),`error`)})})}function pe(e,t,n,r){let i=new Date,a=chrome.i18n.getUILanguage()||`en-US`,o=i.toLocaleTimeString(a,{hour:`2-digit`,minute:`2-digit`})+` — `+i.toLocaleDateString(a),s={sig:t,signer:`did:uid:${n}`,hash:r},c=JSON.stringify(s),l=`https://uid.one/verify/#data=${btoa(c).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}`;if(e.isContentEditable||e.getAttribute(`contenteditable`)===`true`){let r=`
      <br><br>
      <div id="uid-one-signature" data-signer="did:uid:${n}" data-sig="${t}" style="display:none;"></div>
      <div class="uid-email-signature-block" style="border-top: 1px dashed rgba(255, 255, 255, 0.15); margin-top: 16px; padding-top: 12px; font-family: system-ui, -apple-system, sans-serif; font-size: 13px; color: #94a3b8; background: #0b1329; padding: 14px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.08); text-align: left; max-width: 500px; display: block;" contenteditable="false">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-weight: 600; color: #38bdf8;">
          <span style="font-size: 14px;">🔐</span> ${chrome.i18n.getMessage(`signatureTitle`)||`This email is digitally signed by UID.one`}
        </div>
        <div style="font-size: 11px; color: #64748b; line-height: 1.6;">
          ${chrome.i18n.getMessage(`signatureSigner`)||`Signer`}: <strong>${n}</strong><br>
          ${chrome.i18n.getMessage(`signatureTime`)||`Signing Time`}: ${o}<br>
          <a href="${l}" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: 600; display: inline-block; margin-top: 4px;">${chrome.i18n.getMessage(`signatureVerify`)||`Verify Identity →`}</a>
        </div>
      </div>
      <br>
    `,i=e.querySelector(`.uid-email-signature-block`);i?i.outerHTML=r:e.innerHTML+=r}else if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let t=`\n\n[🔐 ${chrome.i18n.getMessage(`signatureTitle`)||`Digitally signed by UID.one`}]\n${chrome.i18n.getMessage(`signatureSigner`)||`Signer`}: ${n}\n${chrome.i18n.getMessage(`signatureTime`)||`Time`}: ${o}\nVerify: ${l}`;e.value+=t}e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}var X=class{init(){let e=window.location.hostname,t=e===`uid.one`||e.endsWith(`.uid.one`),n=document.querySelector(`input[type="password"]`)!==null;t||!n||(console.log(`[uid.one] Initializing ViewportCleaner...`),this.clean(),new MutationObserver(()=>{this.clean()}).observe(document.documentElement,{childList:!0,subtree:!0}))}clean(){let e=document.querySelector([`#kc-container`,`.login-pf-page`,`#app`,`#__next`,`#root`].join(`,`));Array.from(document.body?document.body.children:[]).forEach(t=>{if(e&&(t===e||e.contains(t))||t.id===`uid-watermark-overlay`||t.id===`uid-security-enforcer-banner`)return;let n=window.getComputedStyle(t),r=n.position===`fixed`||n.position===`absolute`,i=parseInt(n.zIndex,10);if(r&&(i>100||isNaN(i))){let e=parseFloat(n.opacity);(n.opacity===`0`||!isNaN(e)&&e<.15||n.backgroundColor===`transparent`||n.backgroundColor.includes(`rgba`)&&(n.backgroundColor.endsWith(`, 0)`)||n.backgroundColor.endsWith(`,0)`)))&&(console.log(`[uid.one] Suspect third-party viewport element hidden:`,t),t.style.setProperty(`display`,`none`,`important`),t.style.setProperty(`visibility`,`hidden`,`important`),t.style.setProperty(`opacity`,`0`,`important`),t.style.setProperty(`pointer-events`,`none`,`important`))}})}},Z=class{SENSITIVE_COOKIE_PATTERNS=[/^_(ga|gid|gat|gac|gcl)/i,/^_(fbp|fbc)/i,/^_(uetsid|uetvid)/i,/^(cluid|hj|pin_)/i,/^_tt_enable_cookie/i,/^__pt/i,/cookieconsent/i,/ad-/i,/pixel/i,/tracking/i];init(){let e=window.location.hostname;this.isWhitelistedDomain(e)||chrome.storage.local.get(`settings_cookie_guard`).then(e=>{if(e.settings_cookie_guard===!1){console.log(`[uid.one] CookieGuard is disabled by policy.`),document.documentElement.dataset.uidCookieGuard=`false`;return}console.log(`[uid.one] Initializing CookieGuard...`),this.sweepCookies(),setInterval(()=>this.sweepCookies(),5e3)})}isWhitelistedDomain(e){return[`uid.one`,`trip.express`,`localhost`,`127.0.0.1`].some(t=>e===t||e.endsWith(`.`+t))}sweepCookies(){if(typeof document>`u`||!document.cookie)return;let e=document.cookie.split(`;`);for(let t of e){let e=t.indexOf(`=`);if(e===-1)continue;let n=t.substring(0,e).trim();if(this.SENSITIVE_COOKIE_PATTERNS.some(e=>e.test(n))){console.log(`[uid.one] CookieGuard sweeping tracking cookie:`,n),this.deleteCookie(n);try{chrome.runtime.sendMessage({type:`INC_STAT`,key:`cookies_blocked`})}catch{}}}}deleteCookie(e){let t=[``,window.location.hostname,`.`+window.location.hostname,this.getCookieDomain()];for(let n of t){let t=n?`; domain=${n}`:``;document.cookie=`${e}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/${t}`}}getCookieDomain(){let e=window.location.hostname.split(`.`);return e.length>=2?`.`+e.slice(-2).join(`.`):window.location.hostname}},me=class{init(){console.log(`[uid.one] NotificationBlocker registered in main world.`)}},he=class{init(){console.log(`[uid.one] GPCEnforcer registered in main world.`)}},ge=class{observer=null;SKIP_TAGS=new Set([`SCRIPT`,`STYLE`,`IFRAME`,`NOSCRIPT`,`TEXTAREA`,`INPUT`,`OPTION`,`HEAD`,`TITLE`]);init(){chrome.storage.local.get(`settings_otp_shield`).then(e=>{if(e.settings_otp_shield===!1){console.log(`[uid.one] TextDLPShield is disabled.`);return}console.log(`[uid.one] Initializing TextDLPShield...`);let t=document.createElement(`style`);t.textContent=`
        .uid-text-blurred {
          filter: none !important;
          background: transparent;
          border-radius: 3px;
          padding: 0 2px;
          display: inline-block;
          transition: filter 0.15s ease-in-out, background 0.15s ease-in-out !important;
        }
        .uid-presentation-active .uid-text-blurred {
          filter: blur(4.5px) !important;
          background: rgba(0, 0, 0, 0.05);
        }
        .uid-presentation-active .uid-text-blurred:hover {
          filter: none !important;
          background: transparent;
        }
      `;let n=document.head||document.documentElement;n&&n.appendChild(t),document.addEventListener(`keydown`,e=>{if(e.altKey&&e.shiftKey&&e.key.toLowerCase()===`p`){e.preventDefault(),e.stopPropagation();let t=document.documentElement.classList.toggle(`uid-presentation-active`);this.showToast(t?`Presentation Mode Enabled (Sensitive data hidden)`:`Presentation Mode Disabled (Sensitive data visible)`,t)}},!0),setTimeout(()=>{this.scanNode(document.body||document.documentElement)},100);let r=document.body||document.documentElement;this.observer=new MutationObserver(e=>{this.observer?.disconnect();for(let t=0;t<e.length;t++){let n=e[t];if(n.type===`childList`){let e=n.addedNodes;for(let t=0;t<e.length;t++)this.scanNode(e[t])}else n.type===`characterData`&&this.scanNode(n.target)}this.observer?.observe(r,{childList:!0,subtree:!0,characterData:!0})}),this.observer.observe(r,{childList:!0,subtree:!0,characterData:!0}),setInterval(()=>{this.scanNode(document.body||document.documentElement)},800)})}showToast(e,t){let n=document.getElementById(`uid-presentation-toast`);n&&n.remove();let r=document.createElement(`div`);r.id=`uid-presentation-toast`,r.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: ${t?`#0f172a`:`#334155`};
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 14px;
      font-weight: 500;
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 8px;
      pointer-events: none;
      transform: translateY(100px);
      opacity: 0;
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease;
    `,r.innerHTML=`${t?`<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h20"/><path d="M20 12v8H4v-8"/><circle cx="12" cy="12" r="3"/></svg>`:`<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h20"/><path d="M20 12v8H4v-8"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg>`} <span>${e}</span>`,document.body.appendChild(r),requestAnimationFrame(()=>{r.style.transform=`translateY(0)`,r.style.opacity=`1`}),setTimeout(()=>{r.style.transform=`translateY(100px)`,r.style.opacity=`0`,setTimeout(()=>r.remove(),300)},3e3)}scanNode(e){if(e)if(e.nodeType===Node.ELEMENT_NODE){let t=e;if(this.SKIP_TAGS.has(t.tagName)||t.classList.contains(`uid-passkey-wrapper`))return;let n=t.firstChild;for(;n;){let e=n.nextSibling;this.scanNode(n),n=e}}else e.nodeType===Node.TEXT_NODE&&this.processTextNode(e)}processTextNode(e){let t=e.parentNode;if(!t||t instanceof Element&&(t.classList.contains(`uid-text-blurred`)||t.closest(`.uid-text-blurred`)))return;let n=e.nodeValue||``;if(!n.trim())return;let r=[...n.matchAll(/(?:eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b|\b\d{9}(?:\d{3})?\b|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|(?:\+\d{1,4}[\s.-]?)?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{2,6}\b|(?:\+\d{1,4}[\s.-]?)?\d{7,14}\b)/g)];if(r.length===0)return;let i=document.createDocumentFragment(),a=0;for(let e of r){let t=e.index??0,r=e[0];t>a&&i.appendChild(document.createTextNode(n.substring(a,t)));let o=document.createElement(`span`);o.className=`uid-text-blurred`,o.textContent=r,i.appendChild(o),a=t+r.length}a<n.length&&i.appendChild(document.createTextNode(n.substring(a)));try{t.replaceChild(i,e)}catch{}}},_e=class{init(){console.log(`[uid.one] Initializing EmailSignatureGuard...`);let e=document.createElement(`style`);e.textContent=`
      .uid-email-verified-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #ecfdf5;
        border: 1px solid #10b981;
        color: #047857;
        padding: 4px 8px;
        border-radius: 6px;
        font-family: system-ui, sans-serif;
        font-size: 12px;
        font-weight: 600;
        margin: 8px 0;
      }
      .uid-email-warning-banner {
        display: flex;
        align-items: center;
        gap: 8px;
        background: #fef2f2;
        border: 1px solid #f87171;
        color: #b91c1c;
        padding: 12px 16px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 13px;
        font-weight: 500;
        margin: 12px 0;
      }
    `+$.getStyles();let t=document.head||document.documentElement;t&&t.appendChild(e),document.addEventListener(`click`,e=>{let t=e.target.closest(`a`);if(t&&t.href&&t.href.includes(`/verify/#data=`)){e.preventDefault(),e.stopPropagation();let n=new URL(t.href).hash;if(n&&n.startsWith(`#data=`)){let e=n.substring(6);this.showVerificationDetailsModal(e)}}}),this.scanEmails(),new MutationObserver(()=>{this.scanEmails()}).observe(document.body||document.documentElement,{childList:!0,subtree:!0})}async showVerificationDetailsModal(e){try{let t=e.replace(/-/g,`+`).replace(/_/g,`/`),n=JSON.parse(atob(t)),r=n.signer,i=n.hash,a=r.replace(`did:uid:`,``),o=document.createElement(`div`);o.className=`uid-sig-overlay`,o.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999999;
        font-family: system-ui, -apple-system, sans-serif;
        color: #e4e4e7;
        opacity: 0;
        transition: opacity 0.3s ease;
      `;let s=document.createElement(`div`);s.style.cssText=`
        background: rgba(10, 10, 10, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 24px;
        width: 100%;
        max-width: 500px;
        padding: 32px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        position: relative;
        transform: translateY(20px);
        transition: transform 0.3s ease;
      `,s.innerHTML=`
        <div style="text-align: center; margin-bottom: 24px;">
          <div style="display: inline-flex; width: 64px; height: 64px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 50%; align-items: center; justify-content: center; margin-bottom: 16px; position: relative;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <h3 style="font-size: 20px; font-weight: 700; color: #fff; margin: 0 0 4px 0; tracking: -0.025em;">Signature Authenticated</h3>
          <span style="font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; color: #10b981;">Sovereign Verification System</span>
        </div>

        <div style="display: flex; flex-direction: column; gap: 16px; border-top: 1px solid rgba(255, 255, 255, 0.06); padding-top: 20px;">
          <div>
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Signer Identity (DID)</div>
            <div style="font-size: 13px; font-weight: 600; color: #fff; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px; word-break: break-all;">${r}</div>
          </div>

          <div>
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Content Integrity Hash (SHA-256)</div>
            <div style="font-size: 12px; font-family: monospace; color: #a1a1aa; background: #000; border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px; word-break: break-all; user-select: all;">${i}</div>
          </div>

          <div id="uid-modal-key-section">
            <div style="font-size: 11px; color: #71717a; font-weight: 500; margin-bottom: 4px;">Active Public Key (RSA 2048-bit)</div>
            <div style="font-size: 11px; color: #a1a1aa; display: flex; align-items: center; justify-content: space-between; cursor: pointer; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); padding: 8px 12px; border-radius: 10px;" id="uid-modal-toggle-key">
              <span>Show Sovereign Public Key PEM</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" id="uid-modal-arrow" style="transition: transform 0.2s;"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </div>
            <textarea readonly id="uid-modal-pubkey-text" style="display: none; width: 100%; height: 100px; background: #000; color: #52525b; font-family: monospace; font-size: 9px; border: 1px solid rgba(255, 255, 255, 0.04); border-radius: 10px; padding: 8px; margin-top: 8px; resize: none; box-sizing: border-box; outline: none;"></textarea>
          </div>
        </div>

        <div style="margin-top: 28px;">
          <button id="uid-modal-close-btn" style="width: 100%; padding: 12px; border-radius: 12px; background: #27272a; border: 1px solid rgba(255, 255, 255, 0.04); color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; transition: background 0.2s;">Close</button>
        </div>
      `,o.appendChild(s),document.body.appendChild(o),setTimeout(()=>{o.style.opacity=`1`,s.style.transform=`translateY(0)`},50),chrome.runtime.sendMessage({type:`GET_USER_PUBKEY`,identifier:a},e=>{if(e&&e.success&&e.publicKey){let t=s.querySelector(`#uid-modal-pubkey-text`);t&&(t.value=e.publicKey)}});let c=!1,l=s.querySelector(`#uid-modal-toggle-key`),u=s.querySelector(`#uid-modal-pubkey-text`),d=s.querySelector(`#uid-modal-arrow`);l&&u&&l.addEventListener(`click`,()=>{c=!c,u.style.display=c?`block`:`none`,d.style.transform=c?`rotate(180deg)`:`rotate(0deg)`});let f=()=>{o.style.opacity=`0`,s.style.transform=`translateY(20px)`,setTimeout(()=>{o.remove()},300)},p=s.querySelector(`#uid-modal-close-btn`);p&&p.addEventListener(`click`,f),o.addEventListener(`click`,e=>{e.target===o&&f()})}catch(e){console.error(`[uid.one] Failed to show verification modal:`,e)}}scanEmails(){document.querySelectorAll(`.a3s, .rps_code`).forEach(e=>{if(e.querySelector(`.uid-ai-triage-badge`))return;let t=e.querySelector(`#uid-one-signature`),n=e.textContent||``,r=n.match(/🔐 Email này được ký số bởi UID\.one/i);t||r?this.processVerification(e,t):n.trim().length>10&&new $().triage(e,!1,``).catch(console.error)})}async processVerification(e,t){try{let n=``,r=``,i=``;if(t)n=t.getAttribute(`data-sig`)||``,r=t.getAttribute(`data-signer`)||``;else{let t=(e.innerHTML||``).match(/uid\.one\/verify\/#data=([A-Za-z0-9_-]+)/);if(t&&t[1])try{let e=atob(t[1].replace(/-/g,`+`).replace(/_/g,`/`)),a=JSON.parse(e);n=a.sig||``,r=a.signer||``,i=a.hash||``}catch{}}if(!r){this.injectWarning(e,`Chữ ký email không hợp lệ hoặc đã bị giả mạo.`),new $().triage(e,!1,``).catch(console.error);return}console.log(`[uid.one] Verifying signature for ${r} (hash: ${i||`DOM`}, sig: ${n.slice(0,10)}...)`),chrome.runtime.sendMessage({type:`GET_USER_PUBKEY`,identifier:r.replace(`did:uid:`,``)},async t=>{if(!t||!t.success||!t.publicKey){console.error(`[uid.one] Failed to load public key for: ${r}`,t?.error),this.injectWarning(e,`Không thể tải khóa công khai của người gửi: ${r}`),new $().triage(e,!1,``).catch(console.error);return}try{let i=t.publicKey,a=``;if(e.querySelector(`#uid-one-signature`)){let t=e.cloneNode(!0),n=t.querySelector(`#uid-one-signature`);n&&n.remove(),a=t.textContent||``}else a=(e.textContent||``).split(/🔐 (Email này được ký số bởi UID\.one|This email is digitally signed by UID\.one)/i)[0]||``;a=a.trim();let o=new TextEncoder,s=o.encode(a),c=await window.crypto.subtle.digest(`SHA-256`,s),l=Array.from(new Uint8Array(c)).map(e=>e.toString(16).padStart(2,`0`)).join(``),u=i.trim();u.startsWith(`-----BEGIN PUBLIC KEY-----`)&&(u=u.substring(26)),u.endsWith(`-----END PUBLIC KEY-----`)&&(u=u.substring(0,u.length-24)),u=u.replace(/\s/g,``);let d=window.atob(u),f=d.length,p=new Uint8Array(f);for(let e=0;e<f;e++)p[e]=d.charCodeAt(e);let m=await window.crypto.subtle.importKey(`spki`,p.buffer,{name:`RSASSA-PKCS1-v1_5`,hash:{name:`SHA-256`}},!1,[`verify`]),h=window.atob(n),g=h.length,v=new Uint8Array(g);for(let e=0;e<g;e++)v[e]=h.charCodeAt(e);let y=await window.crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,m,v,s);if(!y){let e=o.encode(l);y=await window.crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,m,v,e)}y||=await window.crypto.subtle.verify(`RSASSA-PKCS1-v1_5`,m,v,c),y?(console.log(`[uid.one] Cryptographic signature VERIFIED successfully for ${r}`),this.injectVerifiedBadge(e,r),new $().triage(e,!0,r).catch(console.error)):(console.warn(`[uid.one] Cryptographic signature VERIFICATION FAILED for ${r}`),this.injectWarning(e,`Chữ ký số không khớp với nội dung email (Nội dung đã bị thay đổi).`),new $().triage(e,!1,``).catch(console.error))}catch(t){console.error(`[uid.one] Cryptographic verification error:`,t),this.injectWarning(e,`Lỗi kỹ thuật khi xác minh chữ ký: ${t.message}`),new $().triage(e,!1,``).catch(console.error)}})}catch{this.injectWarning(e,`Lỗi kiểm tra chữ ký số.`)}}injectVerifiedBadge(e,t){let n=document.createElement(`div`);n.className=`uid-email-verified-badge`,n.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 6L9 17l-5-5"></path>
      </svg>
      <span>✓ Verified Email: ${t.replace(`did:uid:`,``)}</span>
    `,e.insertBefore(n,e.firstChild)}injectWarning(e,t){let n=document.createElement(`div`);n.className=`uid-email-warning-banner`,n.innerHTML=`
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" y1="8" x2="12" y2="12"></line>
        <line x1="12" y1="16" x2="12.01" y2="16"></line>
      </svg>
      <span>⚠️ Cảnh báo: ${t}</span>
    `,e.insertBefore(n,e.firstChild)}},Q=class{init(){console.log(`[uid.one] Initializing EmailComposeSigner...`);let e=document.createElement(`style`);e.textContent=`
      .uid-sign-btn {
        display: inline-block !important;
        margin-top: 12px !important;
        padding: 4px 8px !important;
        font-size: 11px !important;
        color: #64748b !important;
        background: transparent !important;
        border: 1px dashed rgba(100, 116, 139, 0.4) !important;
        border-radius: 4px !important;
        text-decoration: none !important;
        font-family: system-ui, -apple-system, sans-serif !important;
        cursor: pointer !important;
        user-select: none !important;
        transition: all 0.2s ease-in-out !important;
      }
      .uid-sign-btn:hover {
        color: #38bdf8 !important;
        border-color: rgba(56, 189, 248, 0.6) !important;
        background: rgba(56, 189, 248, 0.05) !important;
      }
      @keyframes uid-spin {
        to { transform: rotate(360deg); }
      }
      .uid-sign-btn .animate-spin {
        animation: uid-spin 1s linear infinite !important;
      }
    `;let t=document.head||document.documentElement;t&&t.appendChild(e),document.addEventListener(`click`,e=>{let t=e.target.closest(`.uid-sign-btn`);if(t){e.preventDefault(),e.stopPropagation();let n=t.closest(`div[role="textbox"][contenteditable="true"]`);n&&this.handleEmailSigning(n,t)}}),this.scanCompose(),new MutationObserver(()=>{this.scanCompose()}).observe(document.body||document.documentElement,{childList:!0,subtree:!0})}scanCompose(){document.querySelectorAll(`div[role="textbox"][contenteditable="true"]`).forEach(e=>{if(e.querySelector(`.uid-email-signature-block`)||e.querySelector(`.uid-sign-wrapper`))return;let t=document.createElement(`div`);t.className=`uid-sign-wrapper`,t.setAttribute(`contenteditable`,`false`),t.style.cssText=`
        margin-top: 16px;
        display: block;
        user-select: none;
      `;let n=document.createElement(`span`);n.className=`uid-sign-btn`,n.setAttribute(`contenteditable`,`false`),n.innerHTML=`
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="display:inline-block; vertical-align:middle; margin-right: 4px;">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
        ${chrome.i18n.getMessage(`signButton`)||`Sign UID`}
      `,t.appendChild(n),e.appendChild(t)})}handleEmailSigning(e,t){chrome.runtime.sendMessage({type:`GET_PROFILE`},n=>{if(!n||!n.success){alert(chrome.i18n.getMessage(`alertLinkFirst`)||`Please link your UID.one account before performing digital signature.`);return}let r=n.email,i=e.cloneNode(!0),a=i.querySelector(`.uid-sign-wrapper`);a&&a.remove();let o=i.innerText||i.textContent||``;if(o.replace(/\s/g,``).length===0){alert(chrome.i18n.getMessage(`alertEnterContent`)||`Please enter content before signing.`);return}t.innerHTML=`
        <svg class="animate-spin" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="display:inline-block; vertical-align:middle; margin-right: 4px;">
          <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2.5" stroke-opacity="0.25" fill="none"></circle>
          <path d="M12 2v4" stroke="currentColor" stroke-width="2.5"></path>
        </svg>
        ${chrome.i18n.getMessage(`signingButton`)||`Signing...`}
      `,t.style.pointerEvents=`none`;let s=new TextEncoder().encode(o);window.crypto.subtle.digest(`SHA-256`,s).then(n=>{let i=Array.from(new Uint8Array(n)).map(e=>e.toString(16).padStart(2,`0`)).join(``);chrome.runtime.sendMessage({action:`REQUEST_DIGITAL_SIGNATURE`,domain:window.location.hostname,user_agent:navigator.userAgent,identifier:`Email Signature`,metadata:{email_hash:i,email_snippet:o.slice(0,100)}},n=>{if(n&&n.success){let a=n.signature,o=new Date,s=chrome.i18n.getUILanguage()||`en-US`,c=o.toLocaleTimeString(s,{hour:`2-digit`,minute:`2-digit`})+` — `+o.toLocaleDateString(s),l={sig:a,signer:`did:uid:${r}`,hash:i},u=JSON.stringify(l),d=`https://uid.one/verify/#data=${btoa(u).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}`,f=`
              <br><br>
              <div id="uid-one-signature" data-signer="did:uid:${r}" data-sig="${a}" style="display:none;"></div>
              <div class="uid-email-signature-block" style="border-top: 1px dashed rgba(255, 255, 255, 0.15); margin-top: 16px; padding-top: 12px; font-family: system-ui, -apple-system, sans-serif; font-size: 13px; color: #94a3b8; background: #0b1329; padding: 14px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.08); text-align: left; max-width: 500px; display: block;" contenteditable="false">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-weight: 600; color: #38bdf8;">
                  <span style="font-size: 14px;">🔐</span> ${chrome.i18n.getMessage(`signatureTitle`)||`This email is digitally signed by UID.one`}
                </div>
                <div style="font-size: 11px; color: #64748b; line-height: 1.6;">
                  ${chrome.i18n.getMessage(`signatureSigner`)||`Signer`}: <strong>${r}</strong><br>
                  ${chrome.i18n.getMessage(`signatureTime`)||`Signing Time`}: ${c}<br>
                  <a href="${d}" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: 600; display: inline-block; margin-top: 4px;">${chrome.i18n.getMessage(`signatureVerify`)||`Verify Identity →`}</a>
                </div>
              </div>
              <br>
            `,p=e.querySelector(`.uid-email-signature-block`),m=e.querySelector(`.uid-sign-wrapper`);p?p.outerHTML=f:m?m.outerHTML=f:e.innerHTML+=f,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),t.innerHTML=`
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="display:inline-block; vertical-align:middle; margin-right: 4px; color: #10b981;">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
              ${chrome.i18n.getMessage(`signedButton`)||`Signed`}
            `,t.style.pointerEvents=`none`}else this.resetButton(t),alert((chrome.i18n.getMessage(`alertRejected`)||`Signing request was rejected or expired.`)+(n?.error?` (`+n.error+`)`:``))})})})}resetButton(e){e.innerHTML=`
      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="display:inline-block; vertical-align:middle; margin-right: 4px;">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
      ${chrome.i18n.getMessage(`signButton`)||`Sign UID`}
    `,e.style.pointerEvents=`auto`}},$=class{static getStyles(){return`
      .uid-ai-triage-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 8px;
        border-radius: 6px;
        font-family: system-ui, sans-serif;
        font-size: 12px;
        font-weight: 600;
        margin: 8px 4px;
      }
      .uid-ai-priority {
        background: #fef3c7;
        border: 1px solid #d97706;
        color: #92400e;
      }
      .uid-ai-safe {
        background: #eff6ff;
        border: 1px solid #3b82f6;
        color: #1e40af;
      }
      .uid-ai-unverified {
        background: #fff1f2;
        border: 1px solid #f43f5e;
        color: #9f1239;
        animation: uid-pulse 2s infinite;
      }
      @keyframes uid-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
      }
    `}async triage(e,t,n){if(e.querySelector(`.uid-ai-triage-badge`))return;let r=e.textContent||``,i=`SAFE`,a=``;try{if(typeof window<`u`&&window.ai&&window.ai.assistant){let e=await window.ai.assistant.create(),o=`
          Analyze this email.
          - Signed state: ${t?`SIGNED & VERIFIED BY `+n:`UNSIGNED / UNVERIFIED SENDER`}
          - Content: "${r.slice(0,1e3)}"
          
          Respond in exactly this JSON format:
          {
            "category": "PRIORITY" (if verified urgent action), "SAFE" (if normal trusted message), or "UNVERIFIED_SUSPICIOUS" (if unsigned or looks like BEC/phishing),
            "reason": "short 1 sentence explanation in Vietnamese"
          }
        `,s=await e.prompt(o),c=JSON.parse(s);i=c.category||`SAFE`,a=c.reason||``}else{let e=r.toLowerCase();if(t){let t=/hợp đồng|phê duyệt|ký kết|deadline|thanh toán|approve|sign|contract/i.test(e);i=t?`PRIORITY`:`SAFE`,a=t?`Thư từ đối tác tin cậy có yêu cầu xử lý quan trọng.`:`Email an toàn từ đối tác.`}else{let t=/chuyển tiền|mật khẩu|nhấp vào|ngân hàng|khẩn cấp|urgent|wire transfer|payment|bank/i.test(e);i=t?`UNVERIFIED_SUSPICIOUS`:`SAFE`,a=t?`Thư chưa ký chứa từ khóa tài chính nhạy cảm.`:`Thư chưa ký số.`}}}catch{i=t?`SAFE`:`UNVERIFIED_SUSPICIOUS`,a=t?`Nguồn gửi tin cậy đã xác minh.`:`Người gửi chưa ký số.`}this.injectBadge(e,i,a)}injectBadge(e,t,n){let r=document.createElement(`div`);r.className=`uid-ai-triage-badge`,t===`PRIORITY`?(r.classList.add(`uid-ai-priority`),r.innerHTML=`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <polygon points="12 2 2 22 22 22"></polygon>
          <line x1="12" y1="9" x2="12" y2="13"></line>
          <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
        <span>AI Trust Filter: Trọng tâm (${n})</span>
      `):t===`UNVERIFIED_SUSPICIOUS`?(r.classList.add(`uid-ai-unverified`),r.innerHTML=`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <span>AI Trust Filter: Cảnh báo (${n})</span>
      `):(r.classList.add(`uid-ai-safe`),r.innerHTML=`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
        <span>AI Trust Filter: Tin cậy (${n})</span>
      `);let i=e.querySelector(`.uid-email-verified-badge, .uid-email-warning-banner`);i&&i.nextSibling?e.insertBefore(r,i.nextSibling):e.insertBefore(r,e.firstChild)}};return document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,G):G(),e.ClipboardInterceptor=R,e.CookieGuard=Z,e.EmailAITrustFilter=$,e.EmailComposeSigner=Q,e.EmailSignatureGuard=_e,e.FileUploadInterceptor=L,e.FormInterceptor=z,e.GPCEnforcer=he,e.NotificationBlocker=me,e.OriginVerifier=V,e.SENSITIVE_PATTERNS=N,e.ScreenshotProtector=B,e.TextDLPShield=ge,e.ViewportCleaner=X,e.scanContent=P,e.showDLPWarning=F,e})({});